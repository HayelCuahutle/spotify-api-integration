<?php
$conn = new mysqli("localhost", "hayel", "Terminus10***", "tlaxcalitabeach");
if ($conn->connect_error) {
    die("ERROR: " . $conn->connect_error);
}
echo "OK DB";
