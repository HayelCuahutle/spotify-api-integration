<?php
// test_dj_final.php - Verificar que el modo DJ funciona
require_once 'config/database.php';

echo "<h2>🧪 TEST FINAL MODO DJ</h2><pre>";

try {
    $pdo = new PDO("mysql:host=localhost;dbname=tlaxcalitabeach;charset=utf8", "hayel", "Terminus10***");
    
    echo "=== 1. CONFIGURACIÓN ===\n";
    $stmt = $pdo->query("SELECT config_key, config_value FROM sistema_config WHERE config_key = 'dj_activo'");
    $config = $stmt->fetch(PDO::FETCH_ASSOC);
    echo "dj_activo: " . ($config['config_value'] ?? '0') . "\n";
    
    echo "\n=== 2. ESTRUCTURA TABLA ===\n";
    $stmt = $pdo->query("DESCRIBE canciones_dj");
    $columnas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "Columnas: " . count($columnas) . "\n";
    
    echo "\n=== 3. DATOS ACTUALES ===\n";
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM canciones_dj");
    $total = $stmt->fetch()['total'];
    echo "Total canciones: $total\n";
    
    if ($total > 0) {
        $stmt = $pdo->query("SELECT * FROM canciones_dj ORDER BY id DESC LIMIT 3");
        $canciones = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($canciones as $i => $c) {
            echo ($i+1) . ". {$c['nombre']} - {$c['artista']} ({$c['estado']})\n";
            echo "   Email: {$c['email_usuario']}, Fecha: {$c['fecha']} {$c['hora']}\n";
        }
    }
    
    echo "\n=== 4. INSERT DE PRUEBA ===\n";
    $sql = "INSERT INTO canciones_dj 
            (nombre, artista, uri, email_usuario, ip_usuario, hora, fecha, estado, dj_id, fecha_solicitud, admin_agregada) 
            VALUES ('TEST FINAL', 'ARTISTA TEST', 'spotify:track:test999', 'test@final.com', '192.168.1.1', 
                    '" . date('H:i:s') . "', '" . date('Y-m-d') . "', 'pendiente', 1, NOW(), 0)";
    
    if ($pdo->exec($sql)) {
        echo "✅ INSERT manual exitoso\n";
        
        // Verificar nuevo total
        $stmt = $pdo->query("SELECT COUNT(*) as total FROM canciones_dj");
        $nuevo_total = $stmt->fetch()['total'];
        echo "Nuevo total: $nuevo_total canciones\n";
    } else {
        echo "❌ INSERT manual falló\n";
    }
    
    echo "\n=== 5. VERIFICAR CONSULTA DJ ===\n";
    // Probar la misma consulta que usa dj_canciones.php
    try {
        $canciones = $pdo->query("SELECT * FROM canciones_dj ORDER BY fecha_solicitud DESC, id DESC")->fetchAll();
        echo "Consulta con fecha_solicitud: OK (" . count($canciones) . " resultados)\n";
    } catch (Exception $e) {
        echo "Consulta con fecha_solicitud FALLÓ: " . $e->getMessage() . "\n";
        
        // Probar alternativa
        try {
            $canciones = $pdo->query("SELECT * FROM canciones_dj ORDER BY fecha DESC, hora DESC, id DESC")->fetchAll();
            echo "Consulta alternativa: OK (" . count($canciones) . " resultados)\n";
        } catch (Exception $e2) {
            echo "Consulta alternativa TAMBIÉN FALLÓ: " . $e2->getMessage() . "\n";
        }
    }
    
    echo "\n🎉 TEST COMPLETADO\n";
    
} catch (Exception $e) {
    echo "❌ ERROR: " . $e->getMessage() . "\n";
}

echo "</pre>";
?>