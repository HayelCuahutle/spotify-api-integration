<?php
require_once 'config/database.php';
require_once 'includes/functions.php';
checkAdminAuth();

// Verificar que el DJ esté activo
$stmt_dj = $pdo->query("SELECT config_value FROM sistema_config WHERE config_key = 'dj_activo'");
$config_dj = $stmt_dj->fetch();
$dj_activo = $config_dj['config_value'] ?? '0';

// Procesar acciones del DJ
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['marcar_reproducida'])) {
        $id = (int)$_POST['id'];
        $stmt = $pdo->prepare("UPDATE canciones_dj SET estado = 'reproducida' WHERE id = ?");
        $stmt->execute([$id]);
        $_SESSION['mensaje'] = "✅ Canción marcada como reproducida";
    } elseif (isset($_POST['eliminar_cancion'])) {
        $id = (int)$_POST['id'];
        $stmt = $pdo->prepare("DELETE FROM canciones_dj WHERE id = ?");
        $stmt->execute([$id]);
        $_SESSION['mensaje'] = "✅ Canción eliminada de la cola";
    }
    
    header("Location: dj_canciones.php");
    exit;
}

// Obtener canciones del DJ - CORREGIDO: usar ORDER BY fecha DESC, hora DESC
$canciones = $pdo->query("SELECT * FROM canciones_dj ORDER BY fecha DESC, hora DESC")->fetchAll();
?>

<?php include 'includes/header.php'; ?>

<div class="container-fluid p-4">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0">
            <i class="fas fa-headphones me-2"></i>Cola de Canciones - DJ
        </h1>
        <div class="text-muted">
            Modo DJ: 
            <span class="badge <?php echo $dj_activo == '1' ? 'bg-success' : 'bg-danger'; ?>">
                <?php echo $dj_activo == '1' ? 'ACTIVO' : 'INACTIVO'; ?>
            </span>
        </div>
    </div>

    <?php if (isset($_SESSION['mensaje'])): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php echo $_SESSION['mensaje']; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php unset($_SESSION['mensaje']); ?>
    <?php endif; ?>

    <!-- Estadísticas Rápidas -->
    <div class="row mb-4">
        <?php
        $stats = getDJStats($pdo);
        ?>
        <div class="col-md-3">
            <div class="card bg-warning text-white">
                <div class="card-body text-center py-3">
                    <h3><?php echo $stats['pendientes']; ?></h3>
                    <p class="mb-0">Pendientes</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-success text-white">
                <div class="card-body text-center py-3">
                    <h3><?php echo $stats['reproducidas']; ?></h3>
                    <p class="mb-0">Reproducidas Hoy</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-info text-white">
                <div class="card-body text-center py-3">
                    <h3><?php echo $stats['total_hoy']; ?></h3>
                    <p class="mb-0">Solicitudes Hoy</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-primary text-white">
                <div class="card-body text-center py-3">
                    <h3><?php echo $stats['total_dj']; ?></h3>
                    <p class="mb-0">Total en Cola</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Tabla de Canciones DJ -->
    <div class="card">
        <div class="card-header bg-warning text-dark">
            <h5 class="mb-0">Canciones en Cola (Más recientes primero)</h5>
        </div>
        <div class="card-body p-0">
            <?php if (empty($canciones)): ?>
                <div class="text-center py-5">
                    <i class="fas fa-music fa-3x text-muted mb-3"></i>
                    <h5>No hay canciones en la cola del DJ</h5>
                    <p class="text-muted">Cuando el modo DJ esté activo, las canciones aparecerán aquí.</p>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-warning">
                            <tr>
                                <th>#</th>
                                <th>Canción</th>
                                <th>Artista</th>
                                <th>Solicitante</th>
                                <th>Fecha/Hora</th>
                                <th>Estado</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($canciones as $index => $cancion): ?>
                                <tr class="<?php echo $cancion['estado'] == 'pendiente' ? 'table-light' : ''; ?>">
                                    <td><?php echo $index + 1; ?></td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($cancion['nombre']); ?></strong>
                                    </td>
                                    <td><?php echo htmlspecialchars($cancion['artista']); ?></td>
                                    <td>
                                        <?php echo !empty($cancion['email_usuario']) 
                                            ? htmlspecialchars($cancion['email_usuario'])
                                            : '<span class="text-muted">Anónimo</span>'; ?>
                                    </td>
                                    <td>
                                        <small>
                                            <?php echo date('d/m/Y', strtotime($cancion['fecha'])); ?><br>
                                            <span class="text-muted"><?php echo $cancion['hora']; ?></span>
                                        </small>
                                    </td>
                                    <td>
                                        <span class="badge 
                                            <?php 
                                                if($cancion['estado'] == 'pendiente') echo 'bg-warning';
                                                elseif($cancion['estado'] == 'reproducida') echo 'bg-success';
                                                else echo 'bg-danger';
                                            ?>">
                                            <?php echo ucfirst($cancion['estado']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($cancion['estado'] == 'pendiente'): ?>
                                            <form method="POST" class="d-inline">
                                                <input type="hidden" name="id" value="<?php echo $cancion['id']; ?>">
                                                <button type="submit" name="marcar_reproducida" class="btn btn-sm btn-success" title="Marcar como reproducida">
                                                    <i class="fas fa-check"></i>
                                                </button>
                                            </form>
                                            <!-- CORREGIDO: Usar 'uri' en lugar de 'url' -->
                                            <?php if (!empty($cancion['uri'])): ?>
                                                <button class="btn btn-sm btn-info" 
                                                        onclick="abrirSpotify('<?php echo htmlspecialchars($cancion['uri']); ?>')"
                                                        title="Abrir en Spotify">
                                                    <i class="fab fa-spotify"></i>
                                                </button>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <form method="POST" class="d-inline" onsubmit="return confirm('¿Eliminar esta canción de la cola?')">
                                            <input type="hidden" name="id" value="<?php echo $cancion['id']; ?>">
                                            <button type="submit" name="eliminar_cancion" class="btn btn-sm btn-danger" title="Eliminar">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
// Función para abrir canción en Spotify
function abrirSpotify(uri) {
    // Verificar que el URI tenga el formato correcto
    if (uri && uri.includes('spotify:track:')) {
        const spotifyId = uri.replace('spotify:track:', '');
        window.open(`https://open.spotify.com/track/${spotifyId}`, '_blank');
    } else {
        alert('URI de Spotify no válida');
    }
}
</script>

<?php include 'includes/footer.php'; ?>