<?php
require_once 'config/database.php';
require_once 'includes/functions.php';
checkAdminAuth();

error_reporting(E_ALL);
ini_set('display_errors', 1);

// ========== OBTENER CONFIGURACIÓN DE TIEMPO ==========
$minutos_limite = 5; // Valor por defecto
try {
    $stmt_config = $pdo->prepare("SELECT config_value FROM sistema_config WHERE config_key = 'minutos_limite'");
    $stmt_config->execute();
    $config = $stmt_config->fetch();
    $minutos_limite = $config['config_value'] ?? 5;
} catch (Exception $e) {
    $minutos_limite = 5;
}

// ========== CREDENCIALES SPOTIFY ==========
define('SPOTIFY_CLIENT_ID', 'a2b747acdbab4083b0a89ded7d546a77');
define('SPOTIFY_CLIENT_SECRET', 'c60af17e44c34c258bb08adf6e37e3b7');
define('SPOTIFY_REFRESH_TOKEN', 'AQBmXX4v5xwhvvUh0zbTQ3cQe3aVXdnWRf5nV_P6fKd3x5K143CQbzkT1paH1__62V_0WpO7_Ztt3tWexC3_-uiKacUL3-qVBwmIhOjLzEOdvAw3NImp-UsCLkUD5lT8jlM');
define('SPOTIFY_PLAYLIST_ID', '4DsQj6WXGKDpmX9oY3bKVz');

// ========== FUNCIÓN PARA ELIMINAR DE SPOTIFY ==========
function eliminarDeSpotify($uri) {
    try {
        // 1. Obtener Access Token
        $ch = curl_init("https://accounts.spotify.com/api/token");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
            "grant_type" => "refresh_token",
            "refresh_token" => SPOTIFY_REFRESH_TOKEN
        ]));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Authorization: Basic " . base64_encode(SPOTIFY_CLIENT_ID . ":" . SPOTIFY_CLIENT_SECRET)
        ]);
        
        $response = json_decode(curl_exec($ch), true);
        curl_close($ch);
        
        if (!isset($response["access_token"])) {
            throw new Exception("No se pudo obtener access token de Spotify");
        }
        
        $access_token = $response["access_token"];
        
        // 2. Eliminar canción del playlist
        $ch = curl_init("https://api.spotify.com/v1/playlists/" . SPOTIFY_PLAYLIST_ID . "/tracks");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
            "tracks" => [["uri" => $uri]]
        ]));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Authorization: Bearer " . $access_token,
            "Content-Type: application/json"
        ]);
        
        $result = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($http_code === 200) {
            return ["success" => true, "message" => "Canción eliminada de Spotify"];
        } else {
            $error_data = json_decode($result, true);
            $error_msg = $error_data['error']['message'] ?? "Código HTTP: $http_code";
            return ["success" => false, "message" => "Error Spotify: " . $error_msg];
        }
        
    } catch (Exception $e) {
        return ["success" => false, "message" => "Excepción: " . $e->getMessage()];
    }
}

// ========== FUNCIÓN PARA ELIMINAR MUCHAS CANCIONES ==========
function eliminarTodasDeSpotify($pdo) {
    try {
        // 1. Obtener todas las URIs
        $stmt = $pdo->query("SELECT uri FROM canciones_diarias WHERE uri IS NOT NULL AND uri != ''");
        $canciones = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (empty($canciones)) {
            return ["success" => true, "message" => "No hay canciones para eliminar", "eliminadas" => 0];
        }
        
        // 2. Obtener Access Token
        $ch = curl_init("https://accounts.spotify.com/api/token");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
            "grant_type" => "refresh_token",
            "refresh_token" => SPOTIFY_REFRESH_TOKEN
        ]));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Authorization: Basic " . base64_encode(SPOTIFY_CLIENT_ID . ":" . SPOTIFY_CLIENT_SECRET)
        ]);
        
        $response = json_decode(curl_exec($ch), true);
        curl_close($ch);
        
        if (!isset($response["access_token"])) {
            throw new Exception("No se pudo obtener access token de Spotify");
        }
        
        $access_token = $response["access_token"];
        
        // 3. Preparar URIs para eliminar
        $uris = [];
        foreach ($canciones as $cancion) {
            if (!empty($cancion['uri'])) {
                $uris[] = ["uri" => $cancion['uri']];
            }
        }
        
        // 4. Eliminar en chunks de 100
        $chunks = array_chunk($uris, 100);
        $total_eliminadas = 0;
        
        foreach ($chunks as $chunk) {
            $ch = curl_init("https://api.spotify.com/v1/playlists/" . SPOTIFY_PLAYLIST_ID . "/tracks");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(["tracks" => $chunk]));
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                "Authorization: Bearer " . $access_token,
                "Content-Type: application/json"
            ]);
            
            $result = curl_exec($ch);
            $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            if ($http_code === 200) {
                $total_eliminadas += count($chunk);
            }
        }
        
        return [
            "success" => true,
            "message" => "Se eliminaron $total_eliminadas canciones de Spotify",
            "eliminadas" => $total_eliminadas
        ];
        
    } catch (Exception $e) {
        return ["success" => false, "message" => "Excepción: " . $e->getMessage(), "eliminadas" => 0];
    }
}

// ========== PROCESAR ELIMINACIONES ==========

// Eliminar canción individual
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['eliminar_cancion'])) {
        $id = (int)$_POST['id'];
        
        try {
            // 1. Obtener URI de la canción
            $stmt = $pdo->prepare("SELECT uri, nombre FROM canciones_diarias WHERE id = ?");
            $stmt->execute([$id]);
            $cancion = $stmt->fetch();
            
            if ($cancion) {
                $uri = $cancion['uri'];
                $nombre = $cancion['nombre'];
                
                // 2. Intentar eliminar de Spotify
                $spotify_result = ["success" => false, "message" => "No hay URI para eliminar"];
                if (!empty($uri) && strpos($uri, 'spotify:track:') === 0) {
                    $spotify_result = eliminarDeSpotify($uri);
                }
                
                // 3. Eliminar de la base de datos
                $stmt = $pdo->prepare("DELETE FROM canciones_diarias WHERE id = ?");
                $stmt->execute([$id]);
                $bd_eliminada = $stmt->rowCount() > 0;
                
                // 4. Preparar mensaje
                if ($bd_eliminada) {
                    if ($spotify_result['success']) {
                        $_SESSION['mensaje'] = "✅ Canción '$nombre' eliminada:<br>" .
                                              "- ✅ Base de datos<br>" .
                                              "- ✅ Spotify";
                        $_SESSION['tipo_mensaje'] = "success";
                    } else {
                        $_SESSION['mensaje'] = "⚠️ Canción '$nombre' eliminada:<br>" .
                                              "- ✅ Base de datos<br>" .
                                              "- ❌ Spotify: " . $spotify_result['message'];
                        $_SESSION['tipo_mensaje'] = "warning";
                    }
                }
            }
            
        } catch (Exception $e) {
            $_SESSION['mensaje'] = "❌ Error: " . $e->getMessage();
            $_SESSION['tipo_mensaje'] = "danger";
        }
        
        header("Location: canciones.php");
        exit;
        
    } elseif (isset($_POST['borrar_lista_completa'])) {
        // Eliminar todas las canciones
        try {
            // 1. Contar canciones antes de eliminar
            $stmt = $pdo->query("SELECT COUNT(*) as total FROM canciones_diarias");
            $total_canciones = $stmt->fetch()['total'];
            
            // 2. Intentar eliminar de Spotify
            $spotify_result = eliminarTodasDeSpotify($pdo);
            
            // 3. Eliminar de la base de datos
            $stmt = $pdo->prepare("DELETE FROM canciones_diarias");
            $stmt->execute();
            $bd_eliminadas = $stmt->rowCount();
            
            // 4. Preparar mensaje
            if ($spotify_result['success']) {
                $_SESSION['mensaje'] = "✅ Lista eliminada:<br>" .
                                      "- ✅ Base de datos: $bd_eliminadas canciones<br>" .
                                      "- ✅ Spotify: {$spotify_result['eliminadas']} canciones";
                $_SESSION['tipo_mensaje'] = "success";
            } else {
                $_SESSION['mensaje'] = "⚠️ Resultado mixto:<br>" .
                                      "- ✅ Base de datos: $bd_eliminadas canciones eliminadas<br>" .
                                      "- ❌ Spotify: " . $spotify_result['message'];
                $_SESSION['tipo_mensaje'] = "warning";
            }
            
        } catch (Exception $e) {
            $_SESSION['mensaje'] = "❌ Error: " . $e->getMessage();
            $_SESSION['tipo_mensaje'] = "danger";
        }
        
        header("Location: canciones.php");
        exit;
    }
}

// ========== CONSULTA DE CANCIONES ==========

// Paginación
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;

$limit = 15;
$offset = ($page - 1) * $limit;

// Búsqueda
$busqueda = $_GET['busqueda'] ?? '';

// Consulta principal
try {
    if (!empty($busqueda)) {
        $sql = "SELECT * FROM canciones_diarias 
                WHERE nombre LIKE ? OR artista LIKE ? OR email_usuario LIKE ? 
                ORDER BY fecha DESC, hora DESC 
                LIMIT $limit OFFSET $offset";
        $stmt = $pdo->prepare($sql);
        $search_term = "%" . $busqueda . "%";
        $stmt->execute([$search_term, $search_term, $search_term]);
    } else {
        $sql = "SELECT * FROM canciones_diarias 
                ORDER BY fecha DESC, hora DESC 
                LIMIT $limit OFFSET $offset";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
    }
    
    $canciones = $stmt->fetchAll();
    
} catch (Exception $e) {
    $canciones = [];
    $error_mensaje = "Error en consulta: " . $e->getMessage();
    error_log($error_mensaje);
}

// Contar total
try {
    if (!empty($busqueda)) {
        $sql_count = "SELECT COUNT(*) as total FROM canciones_diarias 
                     WHERE nombre LIKE ? OR artista LIKE ? OR email_usuario LIKE ?";
        $stmt_count = $pdo->prepare($sql_count);
        $search_term = "%" . $busqueda . "%";
        $stmt_count->execute([$search_term, $search_term, $search_term]);
    } else {
        $stmt_count = $pdo->query("SELECT COUNT(*) as total FROM canciones_diarias");
    }
    
    $total_canciones = $stmt_count->fetch()['total'] ?? 0;
    
} catch (Exception $e) {
    $total_canciones = 0;
    error_log("Error contando canciones: " . $e->getMessage());
}

$total_paginas = ceil($total_canciones / $limit);
if ($total_paginas < 1) $total_paginas = 1;
?>

<?php include 'includes/header.php'; ?>

<div class="container-fluid p-4">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0">
            <i class="fas fa-music me-2"></i>Gestión de Canciones
        </h1>
        <div class="text-muted">
            Total: <strong><?php echo $total_canciones; ?></strong> canciones
        </div>
    </div>

    <?php if (isset($_SESSION['mensaje'])): ?>
        <div class="alert alert-<?php echo $_SESSION['tipo_mensaje'] ?? 'success'; ?> alert-dismissible fade show">
            <?php echo $_SESSION['mensaje']; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php 
        unset($_SESSION['mensaje']);
        unset($_SESSION['tipo_mensaje']);
        ?>
    <?php endif; ?>

    <?php if (isset($error_mensaje)): ?>
        <div class="alert alert-danger">
            <?php echo $error_mensaje; ?>
            <br><small>Si el problema persiste, verifica la conexión a la base de datos.</small>
        </div>
    <?php endif; ?>

    <!-- Búsqueda -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-8">
                    <input type="text" name="busqueda" class="form-control" 
                           placeholder="Buscar por nombre, artista o email..." 
                           value="<?php echo htmlspecialchars($busqueda); ?>">
                </div>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-primary">Buscar</button>
                    <a href="canciones.php" class="btn btn-secondary">Limpiar</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Botón borrar todo -->
    <?php if ($total_canciones > 0): ?>
    <div class="mb-4">
        <form method="POST" onsubmit="return confirm('¿Eliminar TODAS las canciones de Spotify y la base de datos?')">
            <button type="submit" name="borrar_lista_completa" class="btn btn-danger w-100 py-3">
                <i class="fas fa-trash-alt me-2"></i> ELIMINAR TODAS LAS CANCIONES (<?php echo $total_canciones; ?> canciones)
            </button>
        </form>
    </div>
    <?php endif; ?>

    <!-- Tabla de Canciones -->
    <div class="card">
        <div class="card-header bg-info text-white">
            <h5 class="mb-0">Canciones Solicitadas</h5>
        </div>
        <div class="card-body p-0">
            <?php if (empty($canciones)): ?>
                <div class="text-center py-5">
                    <i class="fas fa-music fa-3x text-muted mb-3"></i>
                    <h5>No se encontraron canciones</h5>
                    <?php if (!empty($busqueda)): ?>
                        <p>No hay resultados para "<?php echo htmlspecialchars($busqueda); ?>"</p>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover table-striped mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th>Canción</th>
                                <th>Artista</th>
                                <th>Usuario</th>
                                <th>Fecha y Hora</th>
                                <th>URI Spotify</th>
                                <!-- NUEVA COLUMNA: BANDERITA DEL TIEMPO -->
                                <th> 🚩</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $numero = $offset + 1;
                            foreach ($canciones as $cancion): 
                                $tiene_uri = !empty($cancion['uri']) && strpos($cancion['uri'], 'spotify:track:') === 0;
                            ?>
                                <tr>
                                    <td><?php echo $numero++; ?></td>
                                    <td><strong><?php echo htmlspecialchars($cancion['nombre']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($cancion['artista']); ?></td>
                                    <td>
                                        <?php echo !empty($cancion['email_usuario']) 
                                            ? htmlspecialchars($cancion['email_usuario']) 
                                            : '<span class="text-muted">Anónimo</span>'; ?>
                                    </td>
                                    <td>
                                        <small>
                                            <?php echo date('d/m/Y', strtotime($cancion['fecha'])); ?><br>
                                            <span class="text-muted">
    <?php
    // Convertir hora de UTC a América/Merida (UTC-6)
    $hora_utc = $cancion['hora'];
    $timestamp = strtotime($hora_utc);
    $hora_merida = date('H:i:s', $timestamp - (6 * 3600));
    echo $hora_merida;
    ?>
</span>
                                        </small>
                                    </td>
                                    <td>
                                        <?php if ($tiene_uri): ?>
                                            <span class="badge bg-success" title="<?php echo htmlspecialchars($cancion['uri']); ?>">
                                                ✅ URI Válida
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">
                                                ❌ Sin URI
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <!-- BANDERITA AMARILLA DEL TIEMPO -->
                                    <td>
                                        <div class="badge bg-warning text-dark px-3 py-2" 
                                             style="font-size: 0.9rem; border-left: 4px solid #ff9900;">
                                            <i class="fas fa-clock me-1"></i>
                                            <strong><?php echo $minutos_limite; ?> min</strong>
                                        </div>
                                        <small class="d-block text-muted mt-1">
                                            
                                        </small>
                                    </td>
                                    <td>
                                        <?php if ($tiene_uri): ?>
                                            <button class="btn btn-sm btn-outline-primary" 
                                                    onclick="abrirSpotify('<?php echo $cancion['uri']; ?>')"
                                                    title="Abrir en Spotify">
                                                <i class="fab fa-spotify"></i>
                                            </button>
                                        <?php endif; ?>
                                        <form method="POST" class="d-inline" onsubmit="return confirm('¿Estás seguro de eliminar esta canción?')">
                                            <input type="hidden" name="id" value="<?php echo $cancion['id']; ?>">
                                            <button type="submit" name="eliminar_cancion" class="btn btn-sm btn-outline-danger"
                                                    title="Eliminar">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>

        <!-- Paginación -->
        <?php if ($total_paginas > 1): ?>
        <div class="card-footer">
            <nav aria-label="Paginación">
                <ul class="pagination justify-content-center mb-0">
                    <?php if ($page > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?php echo $page-1; ?>&busqueda=<?php echo urlencode($busqueda); ?>">
                                Anterior
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php 
                    $inicio = max(1, $page - 2);
                    $fin = min($total_paginas, $page + 2);
                    
                    for ($i = $inicio; $i <= $fin; $i++): 
                    ?>
                        <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                            <a class="page-link" href="?page=<?php echo $i; ?>&busqueda=<?php echo urlencode($busqueda); ?>">
                                <?php echo $i; ?>
                            </a>
                        </li>
                    <?php endfor; ?>

                    <?php if ($page < $total_paginas): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?php echo $page+1; ?>&busqueda=<?php echo urlencode($busqueda); ?>">
                                Siguiente
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
        <?php endif; ?>
    </div>
</div>

<script>
function abrirSpotify(uri) {
    const spotifyId = uri.replace('spotify:track:', '');
    window.open(`https://open.spotify.com/track/${spotifyId}`, '_blank');
}
</script>

<?php include 'includes/footer.php'; ?>