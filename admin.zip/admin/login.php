<?php
// Activar reporte de errores (pon esto AL PRINCIPIO del archivo)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once 'config/database.php';

require_once 'config/database.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        $error = "Por favor ingresa usuario y contraseña";
    } else {
        try {
            // Buscar usuario en la nueva tabla
            $stmt = $pdo->prepare("SELECT * FROM sistema_usuarios WHERE username = ? AND activo = 1");
            $stmt->execute([$username]);
            
            if ($stmt->rowCount() === 1) {
                $user = $stmt->fetch();
                
                // Verificar contraseña
                if (password_verify($password, $user['password_hash'])) {
                    // Iniciar sesión
                    $_SESSION['admin_logged_in'] = true;
                    $_SESSION['admin_username'] = $user['username'];
                    $_SESSION['admin_email'] = $user['email'];
                    $_SESSION['admin_rol'] = $user['rol'];
                    $_SESSION['admin_id'] = $user['id'];
                    $_SESSION['admin_nombre'] = $user['nombre_completo'];
                    
                   
                    
                    // Redirigir según rol
                    if ($user['rol'] === 'dj') {
                        header('Location: dashboard_dj.php');
                    } else {
                        header('Location: dashboard.php');
                    }
                    exit;
                } else {
                    $error = "Usuario o contraseña incorrectos";
                }
            } else {
                $error = "Usuario o contraseña incorrectos";
            }
        } catch (Exception $e) {
            $error = "Error en el sistema. Intenta más tarde.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Tlaxcalita Beach Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #1a1a1a, #2d2d2d);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .login-card {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.5);
            border: 1px solid rgba(255,255,255,0.2);
            backdrop-filter: blur(10px);
            max-width: 400px;
            width: 100%;
        }
        .logo-container {
            text-align: center;
            margin-bottom: 30px;
        }
        .logo-container img {
            max-width: 150px;
        }
    </style>
</head>
<body>
    <div class="login-card">
        <div class="logo-container">
            <img src="../tlaxcala.png" alt="Logo Tlaxcalita Beach">
            <h3 class="text-white mt-3">Panel Administrativo</h3>
        </div>
        
        <?php if ($error): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <?php echo $error; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="mb-3">
                <label class="form-label text-white">Usuario</label>
                <input type="text" name="username" class="form-control" required autofocus>
            </div>
            
            <div class="mb-4">
                <label class="form-label text-white">Contraseña</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            
            <button type="submit" class="btn btn-primary w-100 py-2">
                <i class="fas fa-sign-in-alt me-2"></i>Iniciar Sesión
            </button>
        </form>
        
        <div class="mt-4 text-center">
            <small class="text-muted">
                Acceso solo para personal autorizado<br>
                Tlaxcalita Beach © <?php echo date('Y'); ?>
            </small>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
