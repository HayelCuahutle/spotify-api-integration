<?php
// Archivo temporal para generar contraseñas - BORRAR después de usar

// Contraseñas que quieres usar
$admin_password = 'Terminus2410*';
$dj_password = 'TBeach*'; // Puedes usar la misma o diferente

// Generar hashes
$admin_hash = password_hash($admin_password, PASSWORD_DEFAULT);
$dj_hash = password_hash($dj_password, PASSWORD_DEFAULT);

echo "<h3>✅ Credenciales Generadas</h3>";
echo "<h4>Administrador:</h4>";
echo "<strong>Usuario:</strong> admin<br>";
echo "<strong>Contraseña:</strong> " . $admin_password . "<br>";
echo "<strong>Hash para auth.php:</strong> " . $admin_hash . "<br><br>";

echo "<h4>DJ:</h4>";
echo "<strong>Usuario:</strong> dj<br>";
echo "<strong>Contraseña:</strong> " . $dj_password . "<br>";
echo "<strong>Hash para auth.php:</strong> " . $dj_hash . "<br><br>";

echo "📋 <strong>Instrucciones:</strong><br>";
echo "1. Copia los hashes de arriba<br>";
echo "2. Pégalos en auth.php en el array \$users<br>";
echo "3. Borra este archivo generar_password.php<br>";
echo "4. Accede con:<br>";
echo "   - Admin: usuario: admin, contraseña: " . $admin_password . "<br>";
echo "   - DJ: usuario: dj, contraseña: " . $dj_password;
?>