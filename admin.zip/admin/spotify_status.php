<?php
// spotify_status.php - Verifica el estado de Spotify (versión simple y corregida)
require_once 'config/database.php';
require_once 'includes/functions.php';
checkAdminAuth();

// Credenciales de Spotify
$client_id = "a2b747acdbab4083b0a89ded7d546a77";
$client_secret = "c60af17e44c34c258bb08adf6e37e3b7";
$refresh_token = "AQBmXX4v5xwhvvUh0zbTQ3cQe3aVXdnWRf5nV_P6fKd3x5K143CQbzkT1paH1__62V_0WpO7_Ztt3tWexC3_-uiKacUL3-qVBwmIhOjLzEOdvAw3NImp-UsCLkUD5lT8jlM";

$status = [
    'online' => false,
    'playing' => false,
    'simple_status' => 'desconectado'
];

try {
    // Obtener Access Token
    $ch = curl_init("https://accounts.spotify.com/api/token");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        "grant_type" => "refresh_token",
        "refresh_token" => $refresh_token
    ]));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Basic " . base64_encode($client_id . ":" . $client_secret)
    ]);
    
    $response = json_decode(curl_exec($ch), true);
    curl_close($ch);
    
    if (isset($response["access_token"])) {
        $access_token = $response["access_token"];
        $status['online'] = true;
        
        // Obtener estado de reproducción
        $ch = curl_init("https://api.spotify.com/v1/me/player");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Authorization: Bearer $access_token"
        ]);
        
        $playback_state = json_decode(curl_exec($ch), true);
        curl_close($ch);
        
        if (isset($playback_state['is_playing'])) {
            $status['playing'] = $playback_state['is_playing'];
            $status['simple_status'] = $playback_state['is_playing'] ? 'reproduciendo' : 'pausado';
        } else {
            // Spotify está conectado pero no hay información de reproducción
            $status['simple_status'] = 'conectado';
        }
    } else {
        // No se pudo obtener el token
        $status['simple_status'] = 'desconectado';
    }
} catch (Exception $e) {
    // Error en la conexión
    $status['simple_status'] = 'desconectado';
}

// Devolver como JSON
header('Content-Type: application/json');
echo json_encode($status);
?>
