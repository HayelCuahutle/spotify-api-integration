<?php
session_start();

// CONFIGURACIÓN DE USUARIOS - USA ESTAS CREDENCIALES
$users = [
    'admin' => [
        'password_hash' => '$2y$10$GqK06KDt6IKsL5SzY.CMtOwobmUpMi1HMA4ui7VnraeXu8ThJhtzi', // AdminTlaxcalita2024!
        'rol' => 'admin'
    ],
    'dj' => [
        'password_hash' => '$2y$10$x.dhFY3wafklOI3U/UJo8eB.hRFEAfO57quraRkfTpAFVWlSCiNei', // Misma contraseña por ahora
        'rol' => 'dj'
    ]
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    
    // Verificar credenciales
    if (isset($users[$username]) && password_verify($password, $users[$username]['password_hash'])) {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_username'] = $username;
        $_SESSION['admin_rol'] = $users[$username]['rol'];
        $_SESSION['login_time'] = time();
        
        session_regenerate_id(true);
        
        // Redirigir al dashboard correspondiente según el rol
        if ($users[$username]['rol'] === 'dj') {
            header('Location: dashboard_dj.php');
        } else {
            header('Location: dashboard.php');
        }
        exit;
    } else {
        header('Location: login.php?error=1');
        exit;
    }
}

header('Location: login.php');
exit;
?>