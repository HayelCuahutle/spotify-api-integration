<?php
require_once 'config/database.php';
require_once 'includes/functions.php';
checkAdminAuth();

$mensaje = '';
$tipo_mensaje = '';

// Procesar el formulario manual de agregar canción
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['agregar_cancion'])) {
    $trackUri = $_POST['track_uri'] ?? '';
    $trackName = $_POST['track_name'] ?? '';
    $trackArtist = $_POST['track_artist'] ?? '';
    
    // Validar campos obligatorios
    if (empty($trackUri) || empty($trackName) || empty($trackArtist)) {
        $mensaje = "❌ Todos los campos son obligatorios";
        $tipo_mensaje = "danger";
    } else {
        try {
            // Obtener IP del administrador
            $ip_address = getRealIP();
            $admin_email = $_SESSION['admin_username'] . '@tlaxcalitabeach.com';
            
            // Verificar si el modo DJ está activo
            $stmt_dj = $pdo->query("SELECT config_value FROM sistema_config WHERE config_key = 'dj_activo'");
            $config_dj = $stmt_dj->fetch();
            $dj_activo = $config_dj['config_value'] ?? '0';
            
            $hora = date('H:i:s');
            $fecha = date('Y-m-d');
            
            if ($dj_activo == '1') {
                // Modo DJ activo - agregar a la cola del DJ
                $stmt = $pdo->prepare("INSERT INTO canciones_dj (nombre, artista, uri, email_usuario, ip_usuario, hora, fecha, estado, dj_id, admin_agregada) VALUES (?, ?, ?, ?, ?, ?, ?, 'pendiente', 1, 1)");
                $stmt->execute([$trackName, $trackArtist, $trackUri, $admin_email, $ip_address, $hora, $fecha]);
                $mensaje = "✅ Canción agregada a la cola del DJ correctamente";
                $tipo_mensaje = "success";
            } else {
                // Modo normal - agregar directamente usando la lógica de addToPlaylist
                $resultado = agregarCancionDirectamente($trackUri, $trackName, $trackArtist, $admin_email, $ip_address);
                
                if ($resultado['success']) {
                    // Mostrar mensaje según la acción tomada
                    $action_message = '';
                    if (isset($resultado['action_taken'])) {
                        if ($resultado['action_taken'] === 'added_to_queue') {
                            $action_message = ' y se agregó a la cola';
                        } elseif ($resultado['action_taken'] === 'playing_immediately') {
                            $action_message = ' y se está reproduciendo inmediatamente';
                        }
                    }
                    
                    $mensaje = "✅ Canción agregada al playlist de Spotify correctamente" . $action_message;
                    $tipo_mensaje = "success";
                } else {
                    $mensaje = "❌ Error al agregar la canción: " . $resultado['message'];
                    $tipo_mensaje = "danger";
                }
            }
            
        } catch (Exception $e) {
            $mensaje = "❌ Error al agregar la canción: " . $e->getMessage();
            $tipo_mensaje = "danger";
        }
    }
}

// Función para agregar canción directamente CON LA MISMA LÓGICA DEL SISTEMA PÚBLICO
function agregarCancionDirectamente($trackUri, $trackName, $trackArtist, $userEmail, $ip_address) {
    // Configuración de la base de datos
    $host = "localhost";
    $user = "hayel";
    $pass = "Terminus10***";
    $db   = "tlaxcalitabeach";
    
    try {
        // Crear conexión directa
        $conn = new mysqli($host, $user, $pass, $db);
        if ($conn->connect_error) {
            return ["success" => false, "message" => "Error de conexión a BD: " . $conn->connect_error];
        }
        
        // Verificar si ya existe en la base de datos
        $check_stmt = $conn->prepare("SELECT id FROM canciones_diarias WHERE uri = ?");
        $check_stmt->bind_param("s", $trackUri);
        $check_stmt->execute();
        $check_stmt->store_result();
        
        if ($check_stmt->num_rows > 0) {
            $check_stmt->close();
            $conn->close();
            return ["success" => false, "message" => "Esta canción ya existe en la lista"];
        }
        $check_stmt->close();
        
        // Configuración de Spotify
        $client_id = "a2b747acdbab4083b0a89ded7d546a77";
        $client_secret = "c60af17e44c34c258bb08adf6e37e3b7";
        $refresh_token = "AQBmXX4v5xwhvvUh0zbTQ3cQe3aVXdnWRf5nV_P6fKd3x5K143CQbzkT1paH1__62V_0WpO7_Ztt3tWexC3_-uiKacUL3-qVBwmIhOjLzEOdvAw3NImp-UsCLkUD5lT8jlM";
        $playlist_id = "4DsQj6WXGKDpmX9oY3bKVz";
        
        // 1️⃣ Obtener Access Token de Spotify
        $ch = curl_init("https://accounts.spotify.com/api/token");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
            "grant_type" => "refresh_token",
            "refresh_token" => $refresh_token
        ]));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Authorization: Basic " . base64_encode($client_id . ":" . $client_secret)
        ]);
        $response = json_decode(curl_exec($ch), true);
        curl_close($ch);

        if (!isset($response["access_token"])) {
            return ["success" => false, "message" => "No se pudo obtener access token de Spotify"];
        }

        $access_token = $response["access_token"];
        
        // 2️⃣ Obtener dispositivo activo
        $device_ch = curl_init("https://api.spotify.com/v1/me/player/devices");
        curl_setopt($device_ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($device_ch, CURLOPT_HTTPHEADER, [
            "Authorization: Bearer $access_token"
        ]);
        $devices_result = json_decode(curl_exec($device_ch), true);
        curl_close($device_ch);
        
        $device_id = null;
        if (isset($devices_result["devices"]) && count($devices_result["devices"]) > 0) {
            foreach ($devices_result["devices"] as $device) {
                if ($device["is_active"] === true) {
                    $device_id = $device["id"];
                    break;
                }
            }
            if (!$device_id) {
                $device_id = $devices_result["devices"][0]["id"];
            }
        }
        
        if (!$device_id) {
            return ["success" => false, "message" => "Abre Spotify en un dispositivo para activar un player."];
        }
        
        // 3️⃣ Agregar a playlist de Spotify
        $add_ch = curl_init("https://api.spotify.com/v1/playlists/$playlist_id/tracks");
        curl_setopt($add_ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($add_ch, CURLOPT_POST, true);
        curl_setopt($add_ch, CURLOPT_POSTFIELDS, json_encode([ "uris" => [$trackUri] ]));
        curl_setopt($add_ch, CURLOPT_HTTPHEADER, [
            "Authorization: Bearer $access_token",
            "Content-Type: application/json"
        ]);
        $add_result = json_decode(curl_exec($add_ch), true);
        $http_code = curl_getinfo($add_ch, CURLINFO_HTTP_CODE);
        curl_close($add_ch);

        if ($http_code !== 200 && $http_code !== 201) {
            return ["success" => false, "message" => "Error de Spotify: " . ($add_result['error']['message'] ?? 'Código ' . $http_code)];
        }
        
        // 4️⃣ VERIFICAR EL ESTADO ACTUAL DE REPRODUCCIÓN
        $playback_ch = curl_init("https://api.spotify.com/v1/me/player");
        curl_setopt($playback_ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($playback_ch, CURLOPT_HTTPHEADER, [
            "Authorization: Bearer $access_token"
        ]);
        $playback_state = json_decode(curl_exec($playback_ch), true);
        curl_close($playback_ch);
        
        // Determinar qué acción tomar
        $should_play_immediately = false;
        $should_add_to_queue = false;
        
        if (isset($playback_state['context'])) {
            $current_context_uri = $playback_state['context']['uri'] ?? '';
            $is_playing_from_our_playlist = (strpos($current_context_uri, "playlist:$playlist_id") !== false);
            
            if ($is_playing_from_our_playlist && isset($playback_state['is_playing']) && $playback_state['is_playing'] === true) {
                $should_add_to_queue = true;
            } else {
                $should_play_immediately = true;
            }
        } else {
            $should_play_immediately = true;
        }
        
        if (!isset($playback_state['is_playing']) || $playback_state['is_playing'] === false) {
            $should_play_immediately = true;
            $should_add_to_queue = false;
        }
        
        $action_taken = "none";
        $queue_success = false;
        
        if ($should_add_to_queue) {
            $queue_ch = curl_init("https://api.spotify.com/v1/me/player/queue?uri=$trackUri&device_id=$device_id");
            curl_setopt($queue_ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($queue_ch, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($queue_ch, CURLOPT_HTTPHEADER, [
                "Authorization: Bearer $access_token",
                "Content-Type: application/json"
            ]);
            $queue_result = curl_exec($queue_ch);
            $queue_http_code = curl_getinfo($queue_ch, CURLINFO_HTTP_CODE);
            curl_close($queue_ch);
            
            $queue_success = ($queue_http_code === 204);
            $action_taken = "added_to_queue";
        } 
        
        if ($should_play_immediately) {
            $play_ch = curl_init("https://api.spotify.com/v1/me/player/play?device_id=$device_id");
            curl_setopt($play_ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($play_ch, CURLOPT_CUSTOMREQUEST, "PUT");
            curl_setopt($play_ch, CURLOPT_POSTFIELDS, json_encode([
                "context_uri" => "spotify:playlist:$playlist_id",
                "offset" => ["uri" => $trackUri]
            ]));
            curl_setopt($play_ch, CURLOPT_HTTPHEADER, [
                "Authorization: Bearer $access_token",
                "Content-Type: application/json"
            ]);
            $play_result = curl_exec($play_ch);
            curl_close($play_ch);
            $action_taken = "playing_immediately";
        }
        
        // 5️⃣ Guardar en base de datos
        $hora = date('H:i:s');
        $fecha = date('Y-m-d');
        
        $stmt = $conn->prepare("INSERT INTO canciones_diarias (nombre, artista, uri, hora, fecha, email_usuario, ip_usuario) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssss", $trackName, $trackArtist, $trackUri, $hora, $fecha, $userEmail, $ip_address);
        
        if ($stmt->execute()) {
            $stmt->close();
            $conn->close();
            
            return [
                "success" => true, 
                "message" => "Canción agregada correctamente",
                "action_taken" => $action_taken
            ];
        } else {
            $error_msg = $stmt->error;
            $stmt->close();
            $conn->close();
            return ["success" => false, "message" => "Error al guardar en base de datos: " . $error_msg];
        }
        
    } catch (Exception $e) {
        return ["success" => false, "message" => $e->getMessage()];
    }
}

// Manejar AJAX request para agregar canción desde buscador
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax_action']) && $_POST['ajax_action'] === 'agregar_desde_buscador') {
    $trackUri = $_POST['trackUri'] ?? '';
    $trackName = $_POST['trackName'] ?? '';
    $trackArtist = $_POST['trackArtist'] ?? '';
    
    if (empty($trackUri) || empty($trackName) || empty($trackArtist)) {
        echo json_encode(["success" => false, "message" => "Datos incompletos"]);
        exit;
    }
    
    try {
        // Obtener IP del administrador
        $ip_address = getRealIP();
        $admin_email = $_SESSION['admin_username'] . '@tlaxcalitabeach.com';
        
        // Verificar si el modo DJ está activo
        $stmt_dj = $pdo->query("SELECT config_value FROM sistema_config WHERE config_key = 'dj_activo'");
        $config_dj = $stmt_dj->fetch();
        $dj_activo = $config_dj['config_value'] ?? '0';
        
        $hora = date('H:i:s');
        $fecha = date('Y-m-d');
        
        if ($dj_activo == '1') {
            // Modo DJ activo - agregar a la cola del DJ
            $stmt = $pdo->prepare("INSERT INTO canciones_dj (nombre, artista, uri, email_usuario, ip_usuario, hora, fecha, estado, dj_id, admin_agregada) VALUES (?, ?, ?, ?, ?, ?, ?, 'pendiente', 1, 1)");
            $stmt->execute([$trackName, $trackArtist, $trackUri, $admin_email, $ip_address, $hora, $fecha]);
            
            echo json_encode([
                "success" => true, 
                "message" => "Canción agregada a la cola del DJ correctamente",
                "dj_mode" => true
            ]);
        } else {
            // Modo normal - usar la función existente
            $resultado = agregarCancionDirectamente($trackUri, $trackName, $trackArtist, $admin_email, $ip_address);
            
            echo json_encode($resultado);
        }
        
    } catch (Exception $e) {
        echo json_encode(["success" => false, "message" => "Error: " . $e->getMessage()]);
    }
    
    exit;
}
?>

<?php include 'includes/header.php'; ?>

<style>
:root {
  --spotify-green: #1DB954;
  --spotify-dark-green: #1ed760;
  --spotify-red: #e22134;
  --spotify-dark-red: #c41a2a;
  --spotify-black: #121212;
  --spotify-dark-gray: #181818;
  --spotify-light-gray: #b3b3b3;
  --spotify-white: #FFFFFF;
}

body { 
  background: linear-gradient(180deg, #121212, #000000); 
  color: var(--spotify-white); 
  font-family: 'Inter', sans-serif; 
  margin: 0; 
  padding: 0; 
  min-height: 100vh; 
}

.admin-container { 
  max-width: 1400px; 
  margin: 0 auto; 
  padding: 20px; 
}

.admin-header { 
  display: flex; 
  justify-content: space-between; 
  align-items: center; 
  padding: 15px 0; 
  border-bottom: 1px solid var(--spotify-dark-gray); 
  margin-bottom: 25px; 
}

.admin-logo { 
  font-size: 28px; 
  font-weight: 700; 
  color: var(--spotify-green); 
  letter-spacing: -0.5px; 
}

.admin-logo span { 
  color: var(--spotify-green); 
}

.search-container { 
  position: relative; 
  width: 100%; 
  margin: 0 auto 20px; 
}

.search-input { 
  width: 100%; 
  padding: 15px 20px; 
  border-radius: 50px; 
  border: none; 
  background-color: var(--spotify-dark-gray); 
  font-size: 16px; 
  color: var(--spotify-white); 
  transition: all 0.3s ease; 
}

.search-input::placeholder { 
  color: #FFFFFF !important; 
  opacity: 0.9 !important; 
}

.search-input:focus { 
  outline: none; 
  background-color: #2a2a2a; 
  box-shadow: 0 0 0 2px var(--spotify-green); 
}

.search-button { 
  position: absolute; 
  right: 5px; 
  top: 5px; 
  background-color: var(--spotify-green); 
  border: none; 
  border-radius: 50px; 
  padding: 10px 25px; 
  color: var(--spotify-white); 
  font-weight: bold; 
  cursor: pointer; 
  transition: all 0.2s ease; 
}

.search-button:hover { 
  background-color: var(--spotify-dark-green); 
  transform: scale(1.05); 
}

.autocomplete-container { 
  position: absolute; 
  top: 100%; 
  left: 0; 
  right: 0; 
  background: var(--spotify-dark-gray); 
  border-radius: 8px; 
  margin-top: 5px; 
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.6); 
  z-index: 1000; 
  max-height: 320px; 
  overflow-y: auto; 
  display: none; 
}

.autocomplete-item { 
  padding: 12px 18px; 
  cursor: pointer; 
  display: flex; 
  align-items: center; 
  gap: 15px; 
  transition: background 0.2s; 
}

.autocomplete-item:hover { 
  background-color: rgba(255, 255, 255, 0.08); 
}

.autocomplete-image { 
  width: 45px; 
  height: 45px; 
  border-radius: 6px; 
  object-fit: cover; 
}

.autocomplete-name { 
  font-weight: 600; 
  font-size: 15px; 
  margin-bottom: 2px; 
}

.autocomplete-artist { 
  color: var(--spotify-light-gray); 
  font-size: 13px; 
}

.autocomplete-type { 
  margin-left: auto; 
  background: var(--spotify-green); 
  color: var(--spotify-black); 
  padding: 3px 9px; 
  border-radius: 10px; 
  font-size: 10px; 
  font-weight: bold; 
  text-transform: uppercase; 
}

.results-grid { 
  display: grid; 
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); 
  gap: 15px; 
  margin-top: 20px; 
}

.track-card { 
  background: #181818; 
  border-radius: 10px; 
  padding: 15px; 
  cursor: pointer; 
  transition: all 0.25s ease; 
  display: flex; 
  flex-direction: column; 
  height: 100%; 
  position: relative; 
}

.track-card:hover { 
  background: #242424; 
  transform: translateY(-3px); 
  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.3); 
}

.track-image { 
  width: 100%; 
  border-radius: 8px; 
  margin-bottom: 12px; 
  aspect-ratio: 1 / 1; 
  object-fit: cover; 
}

.track-name { 
  font-size: 16px; 
  font-weight: 600; 
  margin-bottom: 5px; 
}

.track-artist { 
  font-size: 14px; 
  color: var(--spotify-light-gray); 
  margin-bottom: 8px; 
}

.track-album { 
  font-size: 13px; 
  color: var(--spotify-light-gray); 
}

.track-duration { 
  margin-top: auto; 
  text-align: right; 
  font-size: 13px; 
  color: var(--spotify-light-gray); 
}

.no-results, .loading { 
  text-align: center; 
  color: var(--spotify-light-gray); 
  font-size: 18px; 
  margin-top: 40px; 
}

/* Toast notifications */
.toast-container-center { 
  position: fixed; 
  top: 50%; 
  left: 50%; 
  transform: translate(-50%, -50%); 
  z-index: 2000; 
}

.toast-spotify { 
  background: linear-gradient(135deg, #1a1a1a, #2d2d2d) !important; 
  border-radius: 12px; 
  border: 1px solid #404040; 
  box-shadow: 0 15px 35px rgba(0, 0, 0, 0.7); 
  min-width: 350px; 
  overflow: hidden; 
}

.toast-body-spotify { 
  font-weight: 700; 
  font-size: 17px; 
  text-align: center; 
  padding: 25px 30px; 
  color: #fff; 
  position: relative; 
}

.toast-body-spotify::before { 
  content: "✓"; 
  font-size: 24px; 
  display: block; 
  margin-bottom: 12px; 
  background: var(--spotify-green); 
  color: #000; 
  width: 50px; 
  height: 50px; 
  border-radius: 50%; 
  line-height: 50px; 
  margin: 0 auto 15px auto; 
}

/* Toast para errores */
.toast-spotify-error { 
  background: linear-gradient(135deg, #2a1a1a, #3d2d2d) !important; 
  border-radius: 12px; 
  border: 1px solid #604040; 
  box-shadow: 0 15px 35px rgba(0, 0, 0, 0.7); 
  min-width: 350px; 
  overflow: hidden; 
}

.toast-body-spotify-error { 
  font-weight: 700; 
  font-size: 17px; 
  text-align: center; 
  padding: 25px 30px; 
  color: #fff; 
  position: relative; 
}

.toast-body-spotify-error::before { 
  content: "⚠️"; 
  font-size: 24px; 
  display: block; 
  margin-bottom: 12px; 
  background: var(--spotify-red); 
  color: #fff; 
  width: 50px; 
  height: 50px; 
  border-radius: 50%; 
  line-height: 50px; 
  margin: 0 auto 15px auto; 
}

/* Toast para cargando */
.toast-spotify-loading { 
  background: linear-gradient(135deg, #1a1a1a, #2d2d2d) !important; 
  border-radius: 12px; 
  border: 1px solid #404040; 
  box-shadow: 0 15px 35px rgba(0, 0, 0, 0.7); 
  min-width: 350px; 
  overflow: hidden; 
}

.toast-body-spotify-loading { 
  font-weight: 700; 
  font-size: 17px; 
  text-align: center; 
  padding: 25px 30px; 
  color: #fff; 
  position: relative; 
}

.toast-body-spotify-loading::before { 
  content: "🔄"; 
  font-size: 24px; 
  display: block; 
  margin-bottom: 12px; 
  background: #555; 
  color: #fff; 
  width: 50px; 
  height: 50px; 
  border-radius: 50%; 
  line-height: 50px; 
  margin: 0 auto 15px auto; 
  animation: spin 1s linear infinite; 
}

@keyframes spin { 
  0% { transform: rotate(0deg); } 
  100% { transform: rotate(360deg); } 
}

@keyframes checkmark { 
  0% { transform: scale(0); opacity: 0; } 
  50% { transform: scale(1.2); } 
  100% { transform: scale(1); opacity: 1; } 
}

/* Formulario manual */
.manual-form {
  background: var(--spotify-dark-gray);
  border-radius: 12px;
  padding: 25px;
  margin-top: 20px;
}

.form-label {
  color: var(--spotify-white);
  font-weight: 600;
  margin-bottom: 8px;
  display: block;
}

.form-control {
  background: #2a2a2a;
  border: 1px solid #404040;
  color: var(--spotify-white);
  border-radius: 8px;
  padding: 12px 15px;
  width: 100%;
  margin-bottom: 15px;
}

.form-control:focus {
  border-color: var(--spotify-green);
  box-shadow: 0 0 0 2px rgba(29, 185, 84, 0.3);
  outline: none;
}

.btn-primary {
  background: var(--spotify-green);
  border: none;
  color: #000;
  font-weight: bold;
  padding: 12px 25px;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.3s ease;
  width: 100%;
}

.btn-primary:hover {
  background: var(--spotify-dark-green);
  transform: translateY(-2px);
}

.system-info {
  background: rgba(29, 185, 84, 0.1);
  border-left: 4px solid var(--spotify-green);
  padding: 15px;
  border-radius: 8px;
  margin-top: 20px;
}

.info-badge {
  background: var(--spotify-green);
  color: #000;
  padding: 4px 12px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: bold;
  margin-left: 10px;
}

/* Layout dividido */
.split-container {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 30px;
  margin-top: 30px;
}

.section-title {
  font-size: 20px;
  font-weight: 700;
  color: var(--spotify-green);
  margin-bottom: 20px;
  padding-bottom: 10px;
  border-bottom: 2px solid var(--spotify-green);
}

.section-card {
  background: var(--spotify-dark-gray);
  border-radius: 12px;
  padding: 25px;
  height: 100%;
}

.instructions {
  background: rgba(255, 255, 255, 0.05);
  border-radius: 10px;
  padding: 20px;
  margin-top: 30px;
}

.instructions h5 {
  color: var(--spotify-green);
  margin-bottom: 15px;
}

.instructions ol {
  padding-left: 20px;
}

.instructions li {
  margin-bottom: 10px;
  color: var(--spotify-light-gray);
}

.method-card {
  background: rgba(255, 255, 255, 0.03);
  border-radius: 8px;
  padding: 15px;
  margin-bottom: 15px;
  border-left: 3px solid var(--spotify-green);
}

.method-card h6 {
  color: var(--spotify-white);
  margin-bottom: 8px;
}

.behavior-info {
  background: rgba(29, 185, 84, 0.05);
  border: 1px solid rgba(29, 185, 84, 0.3);
  border-radius: 8px;
  padding: 15px;
  margin-top: 20px;
}

.behavior-card {
  background: rgba(255, 255, 255, 0.02);
  border-radius: 6px;
  padding: 12px;
  margin-bottom: 10px;
}

.behavior-card.success {
  border-left: 3px solid #28a745;
}

.behavior-card.info {
  border-left: 3px solid #17a2b8;
}

@media (max-width: 992px) {
  .split-container {
    grid-template-columns: 1fr;
  }
}

.admin-logo,
.section-title {
  color: var(--spotify-green) !important;
}

.btn-primary {
  color: #000 !important;
}

</style>

<div class="admin-container">
  <!-- Header -->
  <div class="admin-header">
    <div class="admin-logo">
      <i class="fas fa-plus-circle me-2"></i>Agregar Canción <span></span>
    </div>
    <div class="text-muted">
      <i class="fas fa-user me-2"></i>
      <?php echo htmlspecialchars($_SESSION['admin_username']); ?>
    </div>
  </div>

  <?php if ($mensaje): ?>
    <div class="alert alert-<?php echo $tipo_mensaje ?: 'success'; ?> alert-dismissible fade show">
      <?php echo $mensaje; ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  <?php endif; ?>

  <!-- Contenedor dividido -->
  <div class="split-container">
    <!-- SECCIÓN IZQUIERDA: Buscador de Spotify (AGREGA AUTOMÁTICAMENTE) -->
    <div class="section-card">
      <h3 class="section-title">
        <i class="fas fa-search me-2"></i>Buscar en Spotify
      </h3>
      <p class="text-muted mb-3">Haz clic en cualquier canción para agregarla automáticamente</p>
      
      <div class="search-container">
        <input type="text" id="searchInput" class="search-input" placeholder="¿Qué canción quieres agregar?">
        <button class="search-button" onclick="searchSong()">Buscar</button>
        <div id="autocomplete" class="autocomplete-container"></div>
      </div>

      <div id="welcomeSection" style="text-align: center; padding: 40px 20px; color: var(--spotify-light-gray);">
        <h3>Busca y agrega canciones</h3>
        <p>Encuentra canciones por nombre, artista o álbum</p>
        <p><small>Haz clic en cualquier canción para agregarla</small></p>
      </div>
      
      <div class="results-grid" id="resultsGrid"></div>
    </div>

    <!-- SECCIÓN DERECHA: Agregar Manualmente -->
    <div class="section-card">
      <h3 class="section-title">
        <i class="fas fa-keyboard me-2"></i>Agregar Manualmente
      </h3>
      
      <form method="POST" class="manual-form">
        <div class="mb-3">
          <label class="form-label">URI de Spotify:</label>
          <input type="text" name="track_uri" class="form-control" 
                 placeholder="Ej: spotify:track:4cOdK2wGLETKBW3PvgPWqT" required>
          <small class="text-muted">
            Para obtener el URI: Haz clic derecho en la canción en Spotify → Compartir → Copiar URI de Spotify
          </small>
        </div>
        
        <div class="mb-3">
          <label class="form-label">Nombre de la Canción:</label>
          <input type="text" name="track_name" class="form-control" 
                 placeholder="Ej: Despacito" required>
        </div>
        
        <div class="mb-3">
          <label class="form-label">Artista(s):</label>
          <input type="text" name="track_artist" class="form-control" 
                 placeholder="Ej: Luis Fonsi, Daddy Yankee" required>
        </div>
        
        <button type="submit" name="agregar_cancion" class="btn-primary">
          <i class="fas fa-plus-circle me-2"></i>Agregar Canción
        </button>
      </form>
      
      <!-- Información del sistema -->
      <div class="system-info">
        <h6><i class="fas fa-info-circle me-2"></i>Estado del Sistema</h6>
        <?php
        $stmt_dj = $pdo->query("SELECT config_value FROM sistema_config WHERE config_key = 'dj_activo'");
        $config_dj = $stmt_dj->fetch();
        $dj_activo = $config_dj['config_value'] ?? '0';
        ?>
        <p class="mb-2">
          <strong>Modo DJ:</strong> 
          <span class="info-badge">
            <?php echo $dj_activo == '1' ? 'ACTIVO' : 'INACTIVO'; ?>
          </span>
        </p>
        <small class="text-muted">
          <?php if ($dj_activo == '1'): ?>
            Las canciones se agregarán a la <strong>cola del DJ</strong> para aprobación.
          <?php else: ?>
            Las canciones se agregarán <strong>directamente al playlist</strong> de Spotify.
          <?php endif; ?>
        </small>
      </div>
    </div>
  </div>

  <!-- Instrucciones -->
  <div class="instructions">
    <h5><i class="fas fa-question-circle me-2"></i>¿Cómo usar?</h5>
    <div class="row">
      <div class="col-md-6">
        <div class="method-card">
          <h6>Método 1: Buscar y Agregar</h6>
          <ol>
            <li>Escribe el nombre de la canción o artista en el buscador</li>
            <li>Haz clic en "Buscar" o presiona Enter</li>
            <li>Selecciona una canción de los resultados</li>
            <li>La canción se agregará automáticamente a Spotify</li>
          </ol>
        </div>
      </div>
      <div class="col-md-6">
        <div class="method-card">
          <h6>Método 2: Agregar Manualmente</h6>
          <ol>
            <li>Abre Spotify y encuentra la canción</li>
            <li>Haz clic derecho → Compartir → Copiar URI de Spotify</li>
            <li>Pega el URI en el formulario</li>
            <li>Completa el nombre y artista</li>
            <li>Haz clic en "Agregar Canción"</li>
          </ol>
        </div>
      </div>
    </div>
    
    <!-- Comportamiento del sistema -->
    <div class="behavior-info">
      <h6><i class="fas fa-play-circle me-2"></i>Comportamiento del sistema:</h6>
      <div class="row">
        <div class="col-md-6">
          <div class="behavior-card success">
            <strong><i class="fas fa-play me-2"></i>Reproducir inmediatamente:</strong>
            <small class="d-block">Si no hay nada reproduciéndose o se está reproduciendo otra playlist</small>
          </div>
        </div>
        <div class="col-md-6">
          <div class="behavior-card info">
            <strong><i class="fas fa-list me-2"></i>Agregar a cola:</strong>
            <small class="d-block">Si ya se está reproduciendo de la playlist de Tlaxcalita Beach</small>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Toast para notificaciones -->
<div class="toast-container-center">
  <div id="songToast" class="toast toast-spotify align-items-center border-0" role="alert">
    <div class="d-flex justify-content-center w-100">
      <div class="toast-body toast-body-spotify w-100">
        ¡Canción agregada!<br>
        <small style="font-weight: 400; font-size: 14px; color: #b3b3b3;">Se ha agregado correctamente al sistema</small>
      </div>
    </div>
  </div>
</div>

<!-- Toast para errores -->
<div class="toast-container-center">
  <div id="errorToast" class="toast toast-spotify-error align-items-center border-0" role="alert">
    <div class="d-flex justify-content-center w-100">
      <div class="toast-body toast-body-spotify-error w-100">
        Error<br>
        <small style="font-weight: 400; font-size: 14px; color: #b3b3b3;">Inténtalo de nuevo</small>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
const clientId = "a2b747acdbab4083b0a89ded7d546a77";
const clientSecret = "c60af17e44c34c258bb08adf6e37e3b7";
let searchTimeout;

// Función SIMPLIFICADA - Asume que siempre funciona
function agregarCancion(track, event) {
  if (event) {
    event.stopPropagation();
    const card = event.currentTarget.closest('.track-card');
    if (card) {
      // Efecto visual
      card.style.backgroundColor = 'rgba(29, 185, 84, 0.1)';
      card.style.border = '2px solid var(--spotify-green)';
      
      // Cambiar ícono
      const icon = card.querySelector('i');
      if (icon) {
        icon.className = 'fas fa-check';
        icon.style.color = '#1DB954';
      }
    }
  }
  
  // Mostrar mensaje de éxito inmediato
  showNotification('✅ Canción agregada exitosamente', 'success');
  
  // Enviar realmente al servidor (en segundo plano)
  enviarAlServidor(track);
  
  // Restaurar tarjeta después de 2 segundos
  setTimeout(() => {
    if (event && card) {
      card.style.backgroundColor = '';
      card.style.border = '';
      const icon = card.querySelector('i');
      if (icon) {
        icon.className = 'fas fa-plus';
        icon.style.color = 'var(--spotify-green)';
      }
    }
  }, 2000);
}

// Función para enviar realmente al servidor (en segundo plano)
async function enviarAlServidor(track) {
  try {
    // Crear objeto con datos
    const trackData = {
      ajax_action: 'agregar_desde_buscador',
      trackUri: track.uri,
      trackName: track.name,
      trackArtist: track.artists.map(a => a.name).join(", ")
    };
    
    // Enviar datos al servidor (no mostramos loading)
    const response = await fetch(window.location.href, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams(trackData)
    });
    
    const data = await response.json();
    
    // Si hay error, lo mostramos discretamente en consola
    if (!data.success) {
      console.error('Error del servidor:', data.message);
    }
    
  } catch (error) {
    console.error('Error de conexión:', error);
  }
}

async function getToken() {
  const result = await fetch("https://accounts.spotify.com/api/token", {
    method: "POST",
    headers: { 
      "Content-Type": "application/x-www-form-urlencoded", 
      "Authorization": "Basic " + btoa(clientId + ":" + clientSecret) 
    },
    body: "grant_type=client_credentials"
  });
  const data = await result.json();
  return data.access_token;
}

async function searchAutocomplete(query) {
  if (query.length < 2) { 
    document.getElementById('autocomplete').style.display = 'none'; 
    return; 
  }
  
  try {
    const token = await getToken();
    const result = await fetch(`https://api.spotify.com/v1/search?q=${encodeURIComponent(query)}&type=track,artist&limit=5`, { 
      headers: { "Authorization": `Bearer ${token}` } 
    });
    const data = await result.json();
    displayAutocomplete(data, query);
  } catch { 
    document.getElementById('autocomplete').style.display = 'none'; 
  }
}

function displayAutocomplete(data, query) {
  const container = document.getElementById('autocomplete');
  if ((!data.tracks || !data.tracks.items.length) && (!data.artists || !data.artists.items.length)) { 
    container.style.display = 'none'; 
    return; 
  }
  
  let html = '';
  
  // Canciones
  if (data.tracks) data.tracks.items.slice(0,3).forEach(track => {
    const img = track.album.images[0]?.url || '';
    html += `<div class="autocomplete-item" onclick="selectAutocomplete('${track.name.replace(/'/g,"\\'")}')">
      ${img ? `<img src="${img}" class="autocomplete-image">` : ''}
      <div>
        <div class="autocomplete-name">${track.name}</div>
        <div class="autocomplete-artist">${track.artists.map(a => a.name).join(', ')}</div>
      </div>
      <div class="autocomplete-type">Canción</div>
    </div>`;
  });
  
  // Artistas
  if (data.artists) data.artists.items.slice(0,2).forEach(artist => {
    const img = artist.images[0]?.url || '';
    html += `<div class="autocomplete-item" onclick="selectAutocomplete('${artist.name.replace(/'/g,"\\'")}')">
      ${img ? `<img src="${img}" class="autocomplete-image">` : ''}
      <div>
        <div class="autocomplete-name">${artist.name}</div>
        <div class="autocomplete-artist">Artista</div>
      </div>
      <div class="autocomplete-type">Artista</div>
    </div>`;
  });
  
  container.innerHTML = html;
  container.style.display = 'block';
}

function selectAutocomplete(text) {
  document.getElementById('searchInput').value = text;
  document.getElementById('autocomplete').style.display = 'none';
  searchSong();
}

async function searchSong() {
  const query = document.getElementById("searchInput").value;
  if (!query) { 
    document.getElementById('welcomeSection').style.display = 'block'; 
    document.getElementById('resultsGrid').innerHTML = ''; 
    return; 
  }
  
  const welcome = document.getElementById("welcomeSection");
  const grid = document.getElementById("resultsGrid");
  const auto = document.getElementById("autocomplete");
  
  welcome.style.display = 'none';
  auto.style.display = 'none';
  grid.innerHTML = '<div class="loading">Buscando canciones...</div>';
  
  try {
    const token = await getToken();
    const res = await fetch(`https://api.spotify.com/v1/search?q=${encodeURIComponent(query)}&type=track&limit=12`, { 
      headers: { "Authorization": `Bearer ${token}` } 
    });
    const data = await res.json();
    displayResults(data.tracks.items, query);
  } catch { 
    grid.innerHTML = '<div class="no-results">Error al buscar canciones. Inténtalo de nuevo.</div>'; 
  }
}

function displayResults(tracks, query) {
  const grid = document.getElementById("resultsGrid");
  
  if (!tracks || tracks.length === 0) { 
    grid.innerHTML = `<div class="no-results">No se encontraron resultados para "${query}"</div>`; 
    return; 
  }
  
  grid.innerHTML = '';
  
  tracks.forEach(track => {
    const durMin = Math.floor(track.duration_ms / 60000);
    const durSec = Math.floor((track.duration_ms % 60000) / 1000);
    const duration = `${durMin}:${durSec < 10 ? '0' : ''}${durSec}`;
    const img = track.album.images[0]?.url || 'https://via.placeholder.com/300x300/282828/FFFFFF?text=♪';
    
    const card = document.createElement("div");
    card.className = "track-card";
    card.innerHTML = `
      <img src="${img}" class="track-image">
      <div class="track-name">${track.name}</div>
      <div class="track-artist">${track.artists.map(a => a.name).join(", ")}</div>
      <div class="track-album">${track.album.name}</div>
      <div class="track-duration">${duration}</div>
      <div style="position: absolute; top: 10px; right: 10px; background: rgba(0,0,0,0.7); border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center;">
        <i class="fas fa-plus" style="color: var(--spotify-green); font-size: 12px;"></i>
      </div>
    `;
    
    // Al hacer clic en una canción, AGREGAR AUTOMÁTICAMENTE
    card.addEventListener('click', (e) => {
      agregarCancion(track, e);
    });
    
    grid.appendChild(card);
  });
}

function showNotification(message = '¡Canción agregada!', type = 'success') {
  let toastEl, toastBody;
  
  if (type === 'error') {
    toastEl = document.getElementById('errorToast');
    toastBody = toastEl.querySelector('.toast-body-spotify-error');
    toastBody.innerHTML = `
      ${message}<br>
      <small style="font-weight: 400; font-size: 14px; color: #b3b3b3;">Inténtalo de nuevo</small>
    `;
  } else {
    toastEl = document.getElementById('songToast');
    toastBody = toastEl.querySelector('.toast-body-spotify');
    
    // Restaurar clases originales
    toastEl.className = 'toast toast-spotify align-items-center border-0';
    toastBody.className = 'toast-body toast-body-spotify w-100';
    
    // Verificar si es un mensaje de cargando
    if (message.includes('🔄')) {
      toastEl.className = 'toast toast-spotify-loading align-items-center border-0';
      toastBody.className = 'toast-body toast-body-spotify-loading w-100';
      toastBody.innerHTML = `
        ${message}<br>
        <small style="font-weight: 400; font-size: 14px; color: #b3b3b3;">
          Por favor espera...
        </small>
      `;
    } else {
      toastBody.innerHTML = `
        ${message}<br>
        <small style="font-weight: 400; font-size: 14px; color: #b3b3b3;">
          Se ha agregado correctamente al sistema
        </small>
      `;
    }
  }
  
  const toast = new bootstrap.Toast(toastEl, { delay: type === 'loading' ? 10000 : 3000 });
  toast.show();
  
  return toast;
}

// Event listeners
document.getElementById("searchInput").addEventListener("input", e => {
  clearTimeout(searchTimeout);
  searchTimeout = setTimeout(() => searchAutocomplete(e.target.value), 300);
});

document.getElementById("searchInput").addEventListener("keypress", e => {
  if (e.key === "Enter") {
    searchSong();
  }
});

// Validar formulario manual
document.querySelector('form[method="POST"]').addEventListener('submit', function(e) {
  const trackUri = document.querySelector('input[name="track_uri"]').value;
  const trackName = document.querySelector('input[name="track_name"]').value;
  const trackArtist = document.querySelector('input[name="track_artist"]').value;
  
  if (!trackUri || !trackName || !trackArtist) {
    e.preventDefault();
    showNotification('❌ Completa todos los campos', 'error');
    return false;
  }
  
  // Validar formato de URI de Spotify
  if (!trackUri.startsWith('spotify:track:')) {
    showNotification('❌ El URI debe empezar con spotify:track:', 'error');
    e.preventDefault();
    return false;
  }
  
  return true;
});
</script>

<?php include 'includes/footer.php'; ?>