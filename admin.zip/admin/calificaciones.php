<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config/database.php';
require_once 'includes/functions.php';
checkAdminAuth();

// Paginación
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

// Filtros
$filtro_estrellas = $_GET['estrellas'] ?? '';
$filtro_busqueda = $_GET['busqueda'] ?? '';

// Procesar eliminaciones
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['eliminar_calificacion'])) {
        $id = (int)$_POST['id'];
        
        try {
            $stmt = $pdo->prepare("DELETE FROM calificaciones_servicio WHERE id = ?");
            $stmt->execute([$id]);
            
            $_SESSION['mensaje'] = "✅ Calificación eliminada correctamente";
            $_SESSION['tipo_mensaje'] = "success";
            
        } catch (Exception $e) {
            $_SESSION['mensaje'] = "❌ Error al eliminar: " . $e->getMessage();
            $_SESSION['tipo_mensaje'] = "danger";
        }
        
    } elseif (isset($_POST['eliminar_comentario'])) {
        $id = (int)$_POST['id'];
        
        try {
            $stmt = $pdo->prepare("UPDATE calificaciones_servicio SET comentarios = '' WHERE id = ?");
            $stmt->execute([$id]);
            
            $_SESSION['mensaje'] = "✅ Comentario eliminado correctamente (calificación mantenida)";
            $_SESSION['tipo_mensaje'] = "success";
            
        } catch (Exception $e) {
            $_SESSION['mensaje'] = "❌ Error al eliminar comentario: " . $e->getMessage();
            $_SESSION['tipo_mensaje'] = "danger";
        }
    }
    
    header("Location: calificaciones.php");
    exit;
}

// Construir consulta
$sql = "SELECT * FROM calificaciones_servicio WHERE 1=1";
$params = [];

if (!empty($filtro_estrellas)) {
    $sql .= " AND calificacion = ?";
    $params[] = $filtro_estrellas;
}

if (!empty($filtro_busqueda)) {
    $sql .= " AND (nombre LIKE ? OR correo LIKE ? OR comentarios LIKE ?)";
    $search_term = "%$filtro_busqueda%";
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
}

// Orden y paginación CORREGIDA - usando intval para asegurar integers
$sql .= " ORDER BY fecha_registro DESC LIMIT " . intval($limit) . " OFFSET " . intval($offset);

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$calificaciones = $stmt->fetchAll();

// Total para paginación
$sql_count = "SELECT COUNT(*) as total FROM calificaciones_servicio WHERE 1=1";
$count_params = [];

if (!empty($filtro_estrellas)) {
    $sql_count .= " AND calificacion = ?";
    $count_params[] = $filtro_estrellas;
}

if (!empty($filtro_busqueda)) {
    $sql_count .= " AND (nombre LIKE ? OR correo LIKE ? OR comentarios LIKE ?)";
    $search_term_count = "%$filtro_busqueda%";
    $count_params[] = $search_term_count;
    $count_params[] = $search_term_count;
    $count_params[] = $search_term_count;
}

$stmt_count = $pdo->prepare($sql_count);
$stmt_count->execute($count_params);
$total_calificaciones = $stmt_count->fetch()['total'];
$total_paginas = ceil($total_calificaciones / $limit);

// Estadísticas de estrellas
$stmt_stats = $pdo->query("SELECT calificacion, COUNT(*) as cantidad FROM calificaciones_servicio GROUP BY calificacion ORDER BY calificacion DESC");
$stats_estrellas = $stmt_stats->fetchAll();
?>

<?php include 'includes/header.php'; ?>

<div class="container-fluid p-4">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0">
            <i class="fas fa-star me-2"></i>Gestión de Calificaciones
        </h1>
        <div class="text-muted">
            Total: <strong><?php echo $total_calificaciones; ?></strong> calificaciones
        </div>
    </div>

    <!-- Mostrar mensajes -->
    <?php if (isset($_SESSION['mensaje'])): ?>
        <div class="alert alert-<?php echo $_SESSION['tipo_mensaje'] ?? 'success'; ?> alert-dismissible fade show">
            <?php echo $_SESSION['mensaje']; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php 
        unset($_SESSION['mensaje']);
        unset($_SESSION['tipo_mensaje']);
        ?>
    <?php endif; ?>

    <!-- Filtros -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Filtrar por estrellas:</label>
                    <select name="estrellas" class="form-select">
                        <option value="">Todas las calificaciones</option>
                        <?php for($i = 1; $i <= 5; $i++): ?>
                            <option value="<?php echo $i; ?>" <?php echo $filtro_estrellas == $i ? 'selected' : ''; ?>>
                                <?php echo str_repeat('⭐', $i) . str_repeat('☆', 5-$i); ?>
                                (<?php echo $i; ?>)
                            </option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="col-md-5">
                    <label class="form-label">Buscar:</label>
                    <input type="text" name="busqueda" class="form-control" placeholder="Nombre, email o comentario..." value="<?php echo htmlspecialchars($filtro_busqueda); ?>">
                </div>
                <div class="col-md-3 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary me-2">
                        <i class="fas fa-search"></i> Filtrar
                    </button>
                    <a href="calificaciones.php" class="btn btn-outline-secondary">
                        <i class="fas fa-refresh"></i>
                    </a>
                </div>
            </form>
        </div>
    </div>

    <!-- Estadísticas Rápidas -->
    <div class="row mb-4">
        <?php foreach($stats_estrellas as $stat): ?>
            <div class="col-md-2 col-6">
                <div class="card text-center">
                    <div class="card-body py-3">
                        <div class="rating-stars mb-1">
                            <?php echo str_repeat('⭐', $stat['calificacion']); ?>
                        </div>
                        <h5 class="mb-0"><?php echo $stat['cantidad']; ?></h5>
                        <small class="text-muted">calificaciones</small>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- Tabla de Calificaciones -->
    <div class="card">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Lista de Calificaciones</h5>
            <span class="badge bg-light text-dark">
                Página <?php echo $page; ?> de <?php echo $total_paginas; ?>
            </span>
        </div>
        <div class="card-body p-0">
            <?php if (empty($calificaciones)): ?>
                <div class="text-center py-5">
                    <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                    <h5>No se encontraron calificaciones</h5>
                    <p class="text-muted">No hay calificaciones que coincidan con los filtros aplicados.</p>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover table-striped mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th>Usuario</th>
                                <th>Contacto</th>
                                <th>Calificación</th>
                                <th>Comentarios</th>
                                <th>Fecha</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($calificaciones as $index => $calif): ?>
                                <tr>
                                    <td><?php echo $offset + $index + 1; ?></td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($calif['nombre']); ?></strong>
                                        <?php if (isset($calif['desea_llamada']) && $calif['desea_llamada']): ?>
                                            <span class="badge bg-success ms-1" title="Desea llamada">📞</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div><?php echo htmlspecialchars($calif['correo']); ?></div>
                                        <?php if (!empty($calif['telefono'])): ?>
                                            <small class="text-muted"><?php echo htmlspecialchars($calif['telefono']); ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="rating-stars">
                                            <?php echo str_repeat('⭐', $calif['calificacion']); ?>
                                        </span>
                                        <span class="badge bg-primary badge-rating">
                                            <?php echo $calif['calificacion']; ?>/5
                                        </span>
                                    </td>
                                    <td>
                                        <?php if (!empty($calif['comentarios'])): ?>
                                            <span class="comentario-truncado" title="<?php echo htmlspecialchars($calif['comentarios']); ?>">
                                                <?php echo htmlspecialchars($calif['comentarios']); ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="text-muted">Sin comentarios</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <small>
                                            <?php echo date('d/m/Y', strtotime($calif['fecha_registro'])); ?><br>
                                            <span class="text-muted"><?php echo date('H:i', strtotime($calif['fecha_registro'])); ?></span>
                                        </small>
                                    </td>
                                    <td>
                                        <!-- Botón Eliminar Solo Comentario (solo si hay comentario) -->
                                        <?php if (!empty($calif['comentarios'])): ?>
                                            <form method="POST" class="d-inline" onsubmit="return confirm('¿Estás seguro de que deseas eliminar SOLO el comentario? La calificación se mantendrá.')">
                                                <input type="hidden" name="id" value="<?php echo $calif['id']; ?>">
                                                <button type="submit" name="eliminar_comentario" class="btn btn-sm btn-warning" title="Eliminar solo comentario">
                                                    <i class="fas fa-comment-slash"></i>
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                        
                                        <!-- Botón Eliminar Calificación Completa -->
                                        <form method="POST" class="d-inline" onsubmit="return confirm('¿Estás seguro de que deseas ELIMINAR esta calificación completa? Esta acción no se puede deshacer.')">
                                            <input type="hidden" name="id" value="<?php echo $calif['id']; ?>">
                                            <button type="submit" name="eliminar_calificacion" class="btn btn-sm btn-danger" title="Eliminar calificación completa">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>

        <!-- Paginación -->
        <?php if ($total_paginas > 1): ?>
            <div class="card-footer">
                <nav aria-label="Paginación">
                    <ul class="pagination justify-content-center mb-0">
                        <?php if ($page > 1): ?>
                            <li class="page-item">
                                <a class="page-link" href="?page=<?php echo $page-1; ?>&estrellas=<?php echo $filtro_estrellas; ?>&busqueda=<?php echo urlencode($filtro_busqueda); ?>">
                                    Anterior
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php for($i = 1; $i <= $total_paginas; $i++): ?>
                            <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $i; ?>&estrellas=<?php echo $filtro_estrellas; ?>&busqueda=<?php echo urlencode($filtro_busqueda); ?>">
                                    <?php echo $i; ?>
                                </a>
                            </li>
                        <?php endfor; ?>

                        <?php if ($page < $total_paginas): ?>
                            <li class="page-item">
                                <a class="page-link" href="?page=<?php echo $page+1; ?>&estrellas=<?php echo $filtro_estrellas; ?>&busqueda=<?php echo urlencode($filtro_busqueda); ?>">
                                    Siguiente
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </nav>
            </div>
        <?php endif; ?>
    </div>
</div>
</div> <!-- Cierra main-content -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
