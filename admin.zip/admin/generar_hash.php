<?php
echo "Hash para admin123:<br>" . password_hash('admin123', PASSWORD_DEFAULT);
echo "<br><br>";
echo "Hash para dj123:<br>" . password_hash('dj123', PASSWORD_DEFAULT);
?>
