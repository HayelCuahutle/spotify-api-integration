<?php
require_once 'config/database.php';
require_once 'includes/functions.php';
checkAdminAuth();
checkRole('dj');

// Procesar activar/desactivar modo DJ
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['accion'])) {
    if ($_POST['accion'] === 'activar_dj') {
        $stmt = $pdo->prepare("UPDATE sistema_config SET config_value = '1' WHERE config_key = 'dj_activo'");
        $stmt->execute();
        $mensaje = "✅ Modo DJ ACTIVADO - Las canciones se guardarán en tu cola";
    } elseif ($_POST['accion'] === 'desactivar_dj') {
        $stmt = $pdo->prepare("UPDATE sistema_config SET config_value = '0' WHERE config_key = 'dj_activo'");
        $stmt->execute();
        $mensaje = "✅ Modo DJ DESACTIVADO - Las canciones se agregan directamente al playlist";
    }
}

// Obtener estado actual del DJ
$stmt_dj = $pdo->query("SELECT config_value FROM sistema_config WHERE config_key = 'dj_activo'");
$config_dj = $stmt_dj->fetch();
$dj_activo = $config_dj['config_value'] ?? '0';

// Obtener estadísticas del DJ
$stats_dj = getDJStats($pdo);

// Obtener canciones pendientes recientes
$canciones_pendientes = $pdo->query("SELECT * FROM canciones_dj WHERE estado = 'pendiente' ORDER BY fecha_solicitud DESC LIMIT 5")->fetchAll();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard DJ - Tlaxcalita Beach</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --dj-primary: #FF6B35;
            --dj-secondary: #2EC4B6;
            --dj-dark: #1A1A1A;
            --dj-light: #F8F9FA;
        }
        
        body {
            margin: 0;
            padding: 0;
            background: linear-gradient(135deg, #1A1A1A 0%, #2D2D2D 100%);
            color: white;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
        }
        
        .sidebar {
            background: var(--dj-dark);
            color: white;
            min-height: 100vh;
            position: fixed;
            width: 250px;
            z-index: 1000;
            border-right: 2px solid var(--dj-primary);
        }
        
        .main-content {
            margin-left: 250px;
            background: transparent;
            min-height: 100vh;
            padding: 20px;
        }
        
        .stat-card {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 15px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 8px 32px rgba(0,0,0,0.3);
            backdrop-filter: blur(10px);
            transition: transform 0.3s ease;
            color: white !important;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            border-color: var(--dj-primary);
        }
        
        .stat-card .card-title {
            color: #b0b0b0 !important;
        }
        
        .stat-card h2, .stat-card h3, .stat-card h4, .stat-card h5, .stat-card h6 {
            color: white !important;
        }
        
        .stat-card .text-muted {
            color: #888 !important;
        }
        
        .nav-link {
            color: #b0b0b0 !important;
            padding: 12px 20px;
            margin: 5px 10px;
            border-radius: 10px;
            transition: all 0.3s ease;
            text-decoration: none;
            display: block;
        }
        
        .nav-link:hover, .nav-link.active {
            background: var(--dj-primary);
            color: white !important;
        }
        
        .nav-link i {
            width: 20px;
            margin-right: 10px;
        }
        
        .logo-container {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid #333;
            background: rgba(255, 107, 53, 0.1);
        }
        
        .logo-container img {
            max-width: 150px;
        }
        
        .user-info {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            padding: 15px;
            border-top: 1px solid #333;
            background: rgba(0,0,0,0.3);
        }
        
        .btn-dj {
            background: linear-gradient(135deg, var(--dj-primary), #FF8C42);
            border: none;
            color: white;
            font-weight: bold;
            padding: 12px 25px;
            border-radius: 10px;
            transition: all 0.3s ease;
        }
        
        .btn-dj:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(255, 107, 53, 0.4);
            color: white;
        }
        
        .song-item {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 10px;
            border-left: 4px solid var(--dj-primary);
            transition: all 0.3s ease;
            color: white;
        }
        
        .song-item:hover {
            background: rgba(255, 255, 255, 0.1);
            transform: translateX(5px);
        }
        
        .card-header {
            background: rgba(255, 255, 255, 0.1) !important;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .alert {
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: white;
        }
        
        .alert-success {
            background: rgba(40, 167, 69, 0.2);
            border-color: rgba(40, 167, 69, 0.5);
        }
        
        .btn-outline-danger {
            border-color: #dc3545;
            color: #dc3545;
        }
        
        .btn-outline-danger:hover {
            background-color: #dc3545;
            color: white;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                position: relative;
                min-height: auto;
            }
            
            .main-content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar DJ -->
    <div class="sidebar">
        <div class="logo-container">
            <img src="../tlaxcala.png" alt="Logo Tlaxcalita Beach">
            <h6 class="mt-2 mb-0">Panel DJ</h6>
            <small class="text-muted">Tlaxcalita Beach</small>
        </div>
        
        <!-- Menú de Navegación DJ -->
        <nav class="nav flex-column mt-3">
            <?php
            $current_page = basename($_SERVER['PHP_SELF']);
            ?>
            <a class="nav-link <?php echo $current_page == 'dashboard_dj.php' ? 'active' : ''; ?>" 
               href="dashboard_dj.php">
                <i class="fas fa-tachometer-alt"></i> Dashboard DJ
            </a>
            
            <a class="nav-link <?php echo $current_page == 'dj_canciones.php' ? 'active' : ''; ?>" 
               href="dj_canciones.php">
                <i class="fas fa-headphones"></i> Cola DJ
            </a>
            
            <a class="nav-link" href="logout.php">
                <i class="fas fa-sign-out-alt"></i> Cerrar Sesión
            </a>
        </nav>

        <!-- Información de Usuario DJ -->
        <div class="user-info">
            <div class="d-flex align-items-center">
                <div class="flex-grow-1">
                    <small class="d-block text-muted">Conectado como:</small>
                    <strong class="text-white">
                        <?php echo htmlspecialchars($_SESSION['admin_username'] ?? 'DJ'); ?>
                    </strong>
                    <br>
                    <span class="badge bg-warning text-dark">
                        <i class="fas fa-headphones"></i> DJ
                    </span>
                </div>
                <div class="text-warning">
                    <i class="fas fa-music"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content DJ -->
    <div class="main-content">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3 mb-0 text-white">
                <i class="fas fa-headphones me-2"></i>Dashboard DJ
            </h1>
            <div class="text-muted">
                <i class="fas fa-user me-2"></i>
                <?php echo htmlspecialchars($_SESSION['admin_username']); ?> - Rol: DJ
            </div>
        </div>

        <?php if (isset($mensaje)): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?php echo $mensaje; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Stats Cards DJ -->
        <div class="row g-4">
            <!-- Canciones Pendientes -->
            <div class="col-md-3">
                <div class="card stat-card border-warning">
                    <div class="card-body text-center">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="card-title text-warning">Pendientes</h6>
                                <h2 class="text-warning"><?php echo $stats_dj['pendientes']; ?></h2>
                            </div>
                            <div class="align-self-center">
                                <i class="fas fa-clock fa-2x text-warning"></i>
                            </div>
                        </div>
                        <small class="text-muted">Canciones en espera</small>
                    </div>
                </div>
            </div>

            <!-- Reproducidas Hoy -->
            <div class="col-md-3">
                <div class="card stat-card border-success">
                    <div class="card-body text-center">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="card-title text-success">Reproducidas Hoy</h6>
                                <h2 class="text-success"><?php echo $stats_dj['reproducidas']; ?></h2>
                            </div>
                            <div class="align-self-center">
                                <i class="fas fa-check-circle fa-2x text-success"></i>
                            </div>
                        </div>
                        <small class="text-muted">Canciones reproducidas</small>
                    </div>
                </div>
            </div>

            <!-- Solicitudes Hoy -->
            <div class="col-md-3">
                <div class="card stat-card border-info">
                    <div class="card-body text-center">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="card-title text-info">Solicitudes Hoy</h6>
                                <h2 class="text-info"><?php echo $stats_dj['total_hoy']; ?></h2>
                            </div>
                            <div class="align-self-center">
                                <i class="fas fa-music fa-2x text-info"></i>
                            </div>
                        </div>
                        <small class="text-muted">Total solicitudes hoy</small>
                    </div>
                </div>
            </div>

            <!-- Total en Cola -->
            <div class="col-md-3">
                <div class="card stat-card border-primary">
                    <div class="card-body text-center">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="card-title text-primary">Total en Cola</h6>
                                <h2 class="text-primary"><?php echo $stats_dj['total_dj']; ?></h2>
                            </div>
                            <div class="align-self-center">
                                <i class="fas fa-list fa-2x text-primary"></i>
                            </div>
                        </div>
                        <small class="text-muted">Canciones en cola</small>
                    </div>
                </div>
            </div>
        </div>

        <!-- Control del Modo DJ -->
        <div class="row mt-4">
            <div class="col-12">
                <div class="card stat-card border-warning">
                    <div class="card-header bg-warning text-dark">
                        <h5 class="mb-0">
                            <i class="fas fa-headphones me-2"></i>Control del Modo DJ
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-md-8">
                                <h6 class="mb-1 text-white">Sistema de Cola DJ</h6>
                                <p class="text-muted mb-0">
                                    Cuando el modo DJ está activo, las canciones solicitadas por usuarios 
                                    se guardan en tu cola del DJ en lugar de agregarse directamente al playlist.
                                    Puedes revisar y gestionar las solicitudes desde el panel de Cola DJ.
                                </p>
                            </div>
                            <div class="col-md-4 text-end">
                                <form method="POST" class="d-inline">
                                    <?php if ($dj_activo == '1'): ?>
                                        <input type="hidden" name="accion" value="desactivar_dj">
                                        <button type="submit" class="btn btn-dj btn-danger">
                                            <i class="fas fa-toggle-on me-2"></i>DESACTIVAR MODO DJ
                                        </button>
                                        <small class="d-block text-success mt-2">
                                            <i class="fas fa-check-circle me-1"></i>MODO DJ ACTIVO
                                        </small>
                                    <?php else: ?>
                                        <input type="hidden" name="accion" value="activar_dj">
                                        <button type="submit" class="btn btn-dj btn-success">
                                            <i class="fas fa-toggle-off me-2"></i>ACTIVAR MODO DJ
                                        </button>
                                        <small class="d-block text-danger mt-2">
                                            <i class="fas fa-times-circle me-1"></i>MODO DJ INACTIVO
                                        </small>
                                    <?php endif; ?>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Canciones Pendientes Recientes -->
        <div class="row mt-4">
            <div class="col-12">
                <div class="card stat-card">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">
                            <i class="fas fa-clock me-2"></i>Últimas Canciones Pendientes
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($canciones_pendientes)): ?>
                            <div class="text-center py-4">
                                <i class="fas fa-music fa-3x text-muted mb-3"></i>
                                <h5 class="text-white">No hay canciones pendientes</h5>
                                <p class="text-muted">Cuando los usuarios soliciten canciones, aparecerán aquí.</p>
                            </div>
                        <?php else: ?>
                            <div class="row">
                                <?php foreach($canciones_pendientes as $cancion): ?>
                                    <div class="col-md-6 mb-3">
                                        <div class="song-item">
                                            <div class="d-flex justify-content-between align-items-start">
                                                <div class="flex-grow-1">
                                                    <h6 class="mb-1 text-white"><?php echo htmlspecialchars($cancion['nombre']); ?></h6>
                                                    <p class="mb-1 text-muted"><?php echo htmlspecialchars($cancion['artista']); ?></p>
                                                    <small class="text-muted">
                                                        <i class="fas fa-user me-1"></i>
                                                        <?php echo !empty($cancion['email_usuario']) 
                                                            ? htmlspecialchars($cancion['email_usuario'])
                                                            : 'Anónimo'; ?>
                                                    </small>
                                                </div>
                                                <div class="text-end">
                                                    <small class="text-muted d-block">
                                                        <?php echo date('H:i', strtotime($cancion['hora'])); ?>
                                                    </small>
                                                    <span class="badge bg-warning text-dark">Pendiente</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <div class="text-center mt-3">
                                <a href="dj_canciones.php" class="btn btn-dj">
                                    <i class="fas fa-headphones me-2"></i>Ver Todas las Canciones
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Acciones Rápidas DJ -->
        <div class="row mt-4">
            <div class="col-12">
                <div class="card stat-card">
                    <div class="card-header bg-dark text-white">
                        <h5 class="mb-0">Acciones Rápidas</h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <a href="dj_canciones.php" class="btn btn-dj w-100 py-3">
                                    <i class="fas fa-headphones me-2"></i>Gestionar Cola DJ
                                </a>
                            </div>
                            <div class="col-md-6">
                                <a href="logout.php" class="btn btn-outline-danger w-100 py-3">
                                    <i class="fas fa-sign-out-alt me-2"></i>Cerrar Sesión
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>