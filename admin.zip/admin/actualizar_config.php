<?php
// admin/actualizar_config.php
session_start();

// Configuración de errores
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Conexión a BD
$host = 'localhost';
$dbname = 'tlaxcalitabeach';
$username = 'hayel';
$password = 'Terminus10***';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Error de conexión");
}

// Verificar autenticación admin
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['accion'])) {
    header('Location: dashboard.php');
    exit();
}

$accion = $_POST['accion'];
$mensaje = '';
$tipo_mensaje = 'success';

try {
    if ($accion === 'toggle_ubicacion' && isset($_POST['nuevo_estado'])) {
        $nuevo_estado = $_POST['nuevo_estado'] == '1' ? '1' : '0';
        
        // Actualizar configuración
        $stmt = $pdo->prepare("
            INSERT INTO sistema_config (config_key, config_value) 
            VALUES ('ubicacion_activa', ?)
            ON DUPLICATE KEY UPDATE config_value = ?
        ");
        $stmt->execute([$nuevo_estado, $nuevo_estado]);
        
        $estado_texto = $nuevo_estado == '1' ? 'ACTIVADA' : 'DESACTIVADA';
        $mensaje = "✅ Geolocalización {$estado_texto} correctamente";
        
        // Registrar en log
        error_log("Admin cambió ubicación a: {$estado_texto}");
    }
    
} catch (Exception $e) {
    $mensaje = "❌ Error: " . $e->getMessage();
    $tipo_mensaje = 'danger';
}

// Redirigir de vuelta al dashboard
header("Location: dashboard.php?mensaje=" . urlencode($mensaje) . "&tipo=" . $tipo_mensaje);
exit();
?>