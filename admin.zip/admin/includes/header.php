<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Tlaxcalita Beach</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary: #007bff;
            --success: #28a745;
            --warning: #ffc107;
            --danger: #dc3545;
            --dark: #121212;
            --light: #f8f9fa;
        }
        
        body {
            margin: 0;
            padding: 0;
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            overflow-x: hidden;
        }
        
        /* Sidebar responsive */
        .sidebar {
            background: var(--dark);
            color: white;
            min-height: 100vh;
            position: fixed;
            width: 250px;
            z-index: 1000;
            transition: all 0.3s ease;
            overflow-y: auto;
            height: 100vh;
        }
        
        .main-content {
            margin-left: 250px;
            background: #f8f9fa;
            min-height: 100vh;
            transition: all 0.3s ease;
        }
        
        .stat-card {
            border-radius: 15px;
            border: none;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .nav-link {
            color: #b0b0b0 !important;
            padding: 12px 20px;
            margin: 5px 10px;
            border-radius: 10px;
            transition: all 0.3s ease;
            text-decoration: none;
            display: block;
        }
        
        .nav-link:hover, .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white !important;
        }
        
        .nav-link i {
            width: 20px;
            margin-right: 10px;
        }
        
        .logo-container {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid #333;
        }
        
        .logo-container img {
            max-width: 150px;
            height: auto;
        }
        
        .user-info {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            padding: 15px;
            border-top: 1px solid #333;
            background: rgba(0,0,0,0.3);
        }
        
        .rating-stars { 
            color: #ffc107; 
        }
        
        .badge-rating { 
            font-size: 0.9em; 
        }
        
        .comentario-truncado { 
            max-width: 300px; 
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .table-hover tbody tr:hover { 
            background-color: rgba(0,123,255,0.05); 
        }
        
        /* Menú hamburguesa para móviles */
        .mobile-menu-toggle {
            display: none;
            position: fixed;
            top: 15px;
            left: 15px;
            z-index: 1001;
            background: var(--dark);
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px 15px;
            font-size: 1.2em;
            cursor: pointer;
        }
        
        /* Monitor de Spotify mejorado y responsivo */
        .spotify-monitor {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 999;
            background: rgba(0, 0, 0, 0.95);
            border-radius: 10px;
            padding: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.3);
            border: 2px solid #1DB954;
            min-width: 300px;
            max-width: 90vw;
            backdrop-filter: blur(10px);
            color: white;
            transition: all 0.3s ease;
        }
        
        .spotify-monitor:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(29, 185, 84, 0.4);
        }
        
        .spotify-status {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 10px;
            flex-wrap: wrap;
        }
        
        .status-indicator {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 8px;
            flex-shrink: 0;
        }
        
        .status-online {
            background-color: #1DB954;
            box-shadow: 0 0 10px #1DB954;
            animation: pulse 2s infinite;
        }
        
        .status-offline {
            background-color: #dc3545;
        }
        
        .status-playing {
            background-color: #1DB954;
        }
        
        .status-paused {
            background-color: #ffc107;
        }
        
        .spotify-track-info {
            font-size: 0.9em;
            color: #b0b0b0;
            margin-top: 5px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            max-width: 100%;
        }
        
        .spotify-action-indicator {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 0.8em;
            font-weight: bold;
            margin-left: 10px;
            flex-shrink: 0;
        }
        
        .action-queue {
            background-color: #007bff;
            color: white;
        }
        
        .action-play {
            background-color: #28a745;
            color: white;
        }
        
        .spotify-refresh-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            background: transparent;
            border: none;
            color: #1DB954;
            cursor: pointer;
            font-size: 0.8em;
            padding: 2px 6px;
            border-radius: 4px;
            z-index: 1;
        }
        
        .spotify-refresh-btn:hover {
            background: rgba(29, 185, 84, 0.2);
        }
        
        @keyframes pulse {
            0% { opacity: 1; }
            50% { opacity: 0.5; }
            100% { opacity: 1; }
        }
        
        /* Responsive para tablets */
        @media (max-width: 992px) {
            .sidebar {
                width: 220px;
            }
            
            .main-content {
                margin-left: 220px;
            }
            
            .spotify-monitor {
                min-width: 280px;
                top: 15px;
                right: 15px;
            }
        }
        
        /* Responsive para móviles */
        @media (max-width: 768px) {
            .mobile-menu-toggle {
                display: block;
            }
            
            .sidebar {
                width: 100%;
                position: fixed;
                left: -100%;
                top: 0;
                z-index: 1000;
            }
            
            .sidebar.active {
                left: 0;
            }
            
            .main-content {
                margin-left: 0;
                width: 100%;
            }
            
            .spotify-monitor {
                position: relative;
                top: 0;
                right: 0;
                margin: 15px;
                width: calc(100% - 30px);
                min-width: unset;
                max-width: unset;
            }
            
            .spotify-status {
                flex-direction: column;
                align-items: flex-start;
                gap: 5px;
            }
            
            .spotify-track-info {
                white-space: normal;
                word-break: break-word;
            }
            
            .user-info {
                position: relative;
                margin-top: 20px;
            }
            
            .logo-container img {
                max-width: 120px;
            }
        }
        
        /* Responsive para móviles pequeños */
        @media (max-width: 480px) {
            .spotify-monitor {
                margin: 10px;
                width: calc(100% - 20px);
                padding: 12px;
            }
            
            .mobile-menu-toggle {
                top: 10px;
                left: 10px;
                padding: 8px 12px;
                font-size: 1em;
            }
            
            .nav-link {
                padding: 10px 15px;
                margin: 3px 8px;
            }
            
            .logo-container {
                padding: 15px;
            }
        }
        
        /* Overlay para móviles cuando el menú está abierto */
        .sidebar-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            z-index: 999;
        }
        
        .sidebar-overlay.active {
            display: block;
        }
    </style>
</head>
<body>
    <?php
    // Verificar rol y redirigir según corresponda
    require_once 'includes/functions.php';
    $current_user_role = getCurrentUserRole();
    
    // Redirigir según el rol
    if ($current_user_role === 'dj' && basename($_SERVER['PHP_SELF']) === 'dashboard.php') {
        header('Location: dashboard_dj.php');
        exit;
    }
    
    if ($current_user_role === 'admin' && basename($_SERVER['PHP_SELF']) === 'dashboard_dj.php') {
        header('Location: dashboard.php');
        exit;
    }
    ?>
    
    <!-- Botón de menú hamburguesa para móviles -->
    <button class="mobile-menu-toggle" id="mobileMenuToggle">
        <i class="fas fa-bars"></i>
    </button>
    
    <!-- Overlay para móviles -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>
    
    <!-- Monitor de Spotify -->
    <div id="spotifyMonitor" class="spotify-monitor" style="display: none;">
        <button class="spotify-refresh-btn" onclick="refreshSpotifyStatus()" title="Actualizar estado">
            <i class="fas fa-sync-alt"></i>
        </button>
        <div class="spotify-status">
            <span class="status-indicator status-offline" id="statusIndicator"></span>
            <strong>Spotify:</strong>
            <span id="spotifyStatusText">Verificando...</span>
            <span id="actionIndicator" class="spotify-action-indicator"></span>
        </div>
        <div class="spotify-track-info">
            <span id="deviceInfo"></span>
            <br>
            <span id="trackInfo"></span>
        </div>
        <div class="spotify-track-info" id="actionInfo" style="color: #1DB954; font-weight: bold;"></div>
    </div>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <div class="logo-container">
            <img src="../tlaxcala.png" alt="Logo Tlaxcalita Beach" class="img-fluid">
            <h6 class="mt-2 mb-0">Panel Administrativo</h6>
            <small class="text-muted">Tlaxcalita Beach</small>
        </div>
        
        <!-- Menú de Navegación -->
        <nav class="nav flex-column mt-3">
            <?php
            $current_page = basename($_SERVER['PHP_SELF']);
            $current_user_role = getCurrentUserRole();
            ?>
            
            <?php if ($current_user_role === 'admin'): ?>
                <!-- ========== MENÚ COMPLETO PARA ADMINISTRADOR ========== -->
                <a class="nav-link <?php echo $current_page == 'dashboard.php' ? 'active' : ''; ?>" 
                   href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
                
                <a class="nav-link <?php echo $current_page == 'canciones.php' ? 'active' : ''; ?>" 
                   href="canciones.php">
                    <i class="fas fa-music"></i> Canciones
                </a>
                
                <!-- Gestión de Usuarios del Sistema (SOLO ADMIN) -->
                <a class="nav-link <?php echo $current_page == 'gestion_usuarios.php' ? 'active' : ''; ?>" 
                   href="gestion_usuarios.php">
                    <i class="fas fa-users-cog"></i> Usuarios Sistema
                </a>
                
                <!-- Agregar Canción (SOLO ADMIN) -->
                <a class="nav-link <?php echo $current_page == 'agregar_cancion.php' ? 'active' : ''; ?>" 
                   href="agregar_cancion.php">
                    <i class="fas fa-plus-circle"></i> Agregar Canción
                </a>
                
                <!-- Cola DJ (Admin también puede verlo) -->
                <a class="nav-link <?php echo $current_page == 'dj_canciones.php' ? 'active' : ''; ?>" 
                   href="dj_canciones.php">
                    <i class="fas fa-headphones"></i> Cola DJ
                </a>
                
            <?php else: ?>
                <!-- ========== MENÚ SIMPLIFICADO PARA DJ ========== -->
                <a class="nav-link <?php echo $current_page == 'dashboard_dj.php' ? 'active' : ''; ?>" 
                   href="dashboard_dj.php">
                    <i class="fas fa-tachometer-alt"></i> Dashboard DJ
                </a>
                
                <a class="nav-link <?php echo $current_page == 'dj_canciones.php' ? 'active' : ''; ?>" 
                   href="dj_canciones.php">
                    <i class="fas fa-headphones"></i> Cola DJ
                </a>
            <?php endif; ?>
            
            <!-- Cerrar Sesión (para todos) -->
            <a class="nav-link" href="logout.php">
                <i class="fas fa-sign-out-alt"></i> Cerrar Sesión
            </a>
        </nav>

        <!-- Información de Usuario -->
        <div class="user-info">
            <div class="d-flex align-items-center">
                <div class="flex-grow-1">
                    <small class="d-block text-muted">Conectado como:</small>
                    <strong class="text-white">
                        <?php echo htmlspecialchars($_SESSION['admin_username'] ?? 'Usuario'); ?>
                    </strong>
                    <br>
                    <span class="badge <?php echo $current_user_role === 'admin' ? 'bg-primary' : 'bg-warning text-dark'; ?>">
                        <i class="fas <?php echo $current_user_role === 'admin' ? 'fa-shield-alt' : 'fa-headphones'; ?>"></i>
                        <?php echo strtoupper($current_user_role); ?>
                    </span>
                </div>
                <div class="text-warning">
                    <i class="fas fa-shield-alt"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content" id="mainContent">

    <!-- Scripts mejorados -->
    <script>
    // Función para actualizar el estado de Spotify
    async function updateSpotifyStatus() {
        try {
            const response = await fetch('spotify_status.php');
            const data = await response.json();
            
            const monitor = document.getElementById('spotifyMonitor');
            const statusIndicator = document.getElementById('statusIndicator');
            const statusText = document.getElementById('spotifyStatusText');
            const deviceInfo = document.getElementById('deviceInfo');
            const trackInfo = document.getElementById('trackInfo');
            const actionIndicator = document.getElementById('actionIndicator');
            const actionInfo = document.getElementById('actionInfo');
            
            // Mostrar el monitor
            monitor.style.display = 'block';
            
            if (data.online) {
                // Spotify CONECTADO
                statusIndicator.className = 'status-indicator ' + 
                    (data.playing ? 'status-playing' : 'status-paused');
                
                statusText.textContent = data.playing ? 'REPRODUCIENDO' : 'PAUSADO';
                deviceInfo.textContent = `📱 ${data.device_name}`;
                
                if (data.track_name) {
                    trackInfo.textContent = `🎵 ${data.track_name} - ${data.artist_name}`;
                } else {
                    trackInfo.textContent = '🎵 No hay canción en reproducción';
                }
                
                // Indicador de acción
                if (data.action_if_add === 'queue') {
                    actionIndicator.textContent = 'AGREGARÁ A COLA';
                    actionIndicator.className = 'spotify-action-indicator action-queue';
                    actionInfo.textContent = '✅ Si agregas una canción ahora, se añadirá a la cola';
                } else if (data.action_if_add === 'play_immediately') {
                    actionIndicator.textContent = 'REPRODUCIRÁ';
                    actionIndicator.className = 'spotify-action-indicator action-play';
                    actionInfo.textContent = '🎵 Si agregas una canción ahora, se reproducirá inmediatamente';
                } else {
                    actionIndicator.textContent = '';
                    actionInfo.textContent = '';
                }
                
            } else {
                // Spotify DESCONECTADO
                statusIndicator.className = 'status-indicator status-offline';
                statusText.textContent = 'DESCONECTADO';
                deviceInfo.textContent = '❌ Spotify no está conectado';
                trackInfo.textContent = 'Abre Spotify en un dispositivo para comenzar';
                actionIndicator.textContent = '';
                actionInfo.textContent = '⚠️ Conecta Spotify antes de agregar canciones';
                actionIndicator.className = 'spotify-action-indicator';
            }
            
        } catch (error) {
            console.error('Error actualizando estado de Spotify:', error);
            document.getElementById('spotifyMonitor').style.display = 'block';
            document.getElementById('spotifyStatusText').textContent = 'ERROR';
            document.getElementById('deviceInfo').textContent = 'Error al conectar con Spotify';
        }
    }
    
    // Función para refrescar manualmente
    function refreshSpotifyStatus() {
        const btn = document.querySelector('.spotify-refresh-btn i');
        btn.classList.add('fa-spin');
        
        updateSpotifyStatus().finally(() => {
            setTimeout(() => {
                btn.classList.remove('fa-spin');
            }, 500);
        });
    }
    
    // Control del menú móvil
    function setupMobileMenu() {
        const toggleBtn = document.getElementById('mobileMenuToggle');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        const mainContent = document.getElementById('mainContent');
        
        function toggleSidebar() {
            sidebar.classList.toggle('active');
            overlay.classList.toggle('active');
            document.body.style.overflow = sidebar.classList.contains('active') ? 'hidden' : '';
        }
        
        toggleBtn.addEventListener('click', toggleSidebar);
        overlay.addEventListener('click', toggleSidebar);
        
        // Cerrar menú al hacer clic en un enlace (en móviles)
        const navLinks = document.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            link.addEventListener('click', function() {
                if (window.innerWidth <= 768) {
                    toggleSidebar();
                }
            });
        });
        
        // Actualizar icono del botón según estado del menú
        const observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (mutation.attributeName === 'class') {
                    const icon = toggleBtn.querySelector('i');
                    if (sidebar.classList.contains('active')) {
                        icon.className = 'fas fa-times';
                    } else {
                        icon.className = 'fas fa-bars';
                    }
                }
            });
        });
        
        observer.observe(sidebar, { attributes: true });
    }
    
    // Inicializar cuando el DOM esté listo
    document.addEventListener('DOMContentLoaded', function() {
        // Configurar menú móvil
        setupMobileMenu();
        
        // Primera actualización de Spotify
        updateSpotifyStatus();
        
        // Actualizar periódicamente
        setInterval(updateSpotifyStatus, 30000);
        
        // Actualizar cuando la ventana gana foco
        window.addEventListener('focus', updateSpotifyStatus);
        
        // Ajustar contenido al cambiar tamaño de ventana
        window.addEventListener('resize', function() {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('sidebarOverlay');
            
            // En pantallas grandes, asegurar que el menú esté visible
            if (window.innerWidth > 768) {
                sidebar.classList.remove('active');
                overlay.classList.remove('active');
                document.body.style.overflow = '';
            }
        });
    });
    </script>