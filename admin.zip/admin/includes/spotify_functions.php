<?php
/**
 * Funciones para manejo de configuración de Spotify
 */

/**
 * Obtener configuración de Spotify desde la base de datos
 */
function getSpotifyConfig($pdo, $key, $default = '') {
    try {
        // Primero intentar con la nueva tabla spotify_config
        $stmt = $pdo->prepare("SELECT config_value FROM spotify_config WHERE config_key = ?");
        $stmt->execute([$key]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($result) {
            return $result['config_value'];
        }
        
        // Si no existe, usar valores hardcodeados como respaldo
        $hardcoded = [
            'client_id' => 'a2b747acdbab4083b0a89ded7d546a77',
            'client_secret' => 'c60af17e44c34c258bb08adf6e37e3b7',
            'refresh_token' => 'AQBmXX4v5xwhvvUh0zbTQ3cQe3aVXdnWRf5nV_P6fKd3x5K143CQbzkT1paH1__62V_0WpO7_Ztt3tWexC3_-uiKacUL3-qVBwmIhOjLzEOdvAw3NImp-UsCLkUD5lT8jlM',
            'playlist_id' => '4DsQj6WXGKDpmX9oY3bKVz',
            'device_name' => 'Dispositivo Principal'
        ];
        
        return $hardcoded[$key] ?? $default;
        
    } catch (Exception $e) {
        error_log("Error obteniendo configuración Spotify [$key]: " . $e->getMessage());
        return $default;
    }
}

/**
 * Guardar configuración de Spotify en la base de datos
 */
function saveSpotifyConfig($pdo, $key, $value) {
    try {
        // Verificar si la tabla existe, si no crearla
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS spotify_config (
                id INT AUTO_INCREMENT PRIMARY KEY,
                config_key VARCHAR(50) NOT NULL UNIQUE,
                config_value TEXT,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ");
        
        $stmt = $pdo->prepare("
            INSERT INTO spotify_config (config_key, config_value) 
            VALUES (?, ?) 
            ON DUPLICATE KEY UPDATE config_value = ?, updated_at = NOW()
        ");
        $stmt->execute([$key, $value, $value]);
        
        return true;
    } catch (Exception $e) {
        error_log("Error guardando configuración Spotify [$key]: " . $e->getMessage());
        return false;
    }
}

/**
 * Probar conexión con Spotify usando las credenciales actuales
 */
function testSpotifyConnection($pdo) {
    try {
        $client_id = getSpotifyConfig($pdo, 'client_id');
        $client_secret = getSpotifyConfig($pdo, 'client_secret');
        $refresh_token = getSpotifyConfig($pdo, 'refresh_token');
        
        if (empty($client_id) || empty($client_secret) || empty($refresh_token)) {
            return [
                'success' => false,
                'message' => 'Credenciales incompletas'
            ];
        }
        
        // Intentar obtener access token
        $url = "https://accounts.spotify.com/api/token";
        $data = [
            'grant_type' => 'refresh_token',
            'refresh_token' => $refresh_token
        ];
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Basic ' . base64_encode($client_id . ':' . $client_secret),
            'Content-Type: application/x-www-form-urlencoded'
        ]);
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        $data = json_decode($response, true);
        
        if ($http_code === 200 && isset($data['access_token'])) {
            return [
                'success' => true,
                'message' => '✅ Conexión exitosa. Token válido.',
                'access_token' => substr($data['access_token'], 0, 20) . '...',
                'expires_in' => $data['expires_in'] ?? 'Desconocido',
                'http_code' => $http_code
            ];
        } else {
            $error_msg = $data['error_description'] ?? 'Error desconocido';
            return [
                'success' => false,
                'message' => '❌ Error: ' . $error_msg,
                'http_code' => $http_code
            ];
        }
    } catch (Exception $e) {
        return [
            'success' => false,
            'message' => '❌ Excepción: ' . $e->getMessage()
        ];
    }
}

/**
 * Obtener todas las configuraciones de Spotify
 */
function getAllSpotifyConfig($pdo) {
    try {
        // Asegurar que la tabla existe
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS spotify_config (
                id INT AUTO_INCREMENT PRIMARY KEY,
                config_key VARCHAR(50) NOT NULL UNIQUE,
                config_value TEXT,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ");
        
        $stmt = $pdo->query("SELECT config_key, config_value FROM spotify_config");
        $results = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
        
        // Valores por defecto
        $defaults = [
            'client_id' => 'a2b747acdbab4083b0a89ded7d546a77',
            'client_secret' => 'c60af17e44c34c258bb08adf6e37e3b7',
            'refresh_token' => 'AQBmXX4v5xwhvvUh0zbTQ3cQe3aVXdnWRf5nV_P6fKd3x5K143CQbzkT1paH1__62V_0WpO7_Ztt3tWexC3_-uiKacUL3-qVBwmIhOjLzEOdvAw3NImp-UsCLkUD5lT8jlM',
            'playlist_id' => '4DsQj6WXGKDpmX9oY3bKVz',
            'device_name' => 'Dispositivo Principal',
            'last_updated' => date('Y-m-d H:i:s'),
            'spotify_activo' => '1'
        ];
        
        return array_merge($defaults, $results);
    } catch (Exception $e) {
        error_log("Error obteniendo todas las configuraciones Spotify: " . $e->getMessage());
        return [];
    }
}

/**
 * Insertar configuraciones iniciales de Spotify
 */
function initializeSpotifyConfig($pdo) {
    try {
        // Asegurar que la tabla existe
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS spotify_config (
                id INT AUTO_INCREMENT PRIMARY KEY,
                config_key VARCHAR(50) NOT NULL UNIQUE,
                config_value TEXT,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ");
        
        // Valores por defecto
        $defaultConfigs = [
            'client_id' => 'a2b747acdbab4083b0a89ded7d546a77',
            'client_secret' => 'c60af17e44c34c258bb08adf6e37e3b7',
            'refresh_token' => 'AQBmXX4v5xwhvvUh0zbTQ3cQe3aVXdnWRf5nV_P6fKd3x5K143CQbzkT1paH1__62V_0WpO7_Ztt3tWexC3_-uiKacUL3-qVBwmIhOjLzEOdvAw3NImp-UsCLkUD5lT8jlM',
            'playlist_id' => '4DsQj6WXGKDpmX9oY3bKVz',
            'device_name' => 'Dispositivo Principal',
            'spotify_activo' => '1'
        ];
        
        foreach ($defaultConfigs as $key => $value) {
            $stmt = $pdo->prepare("
                INSERT IGNORE INTO spotify_config (config_key, config_value) 
                VALUES (?, ?)
            ");
            $stmt->execute([$key, $value]);
        }
        
        return true;
    } catch (Exception $e) {
        error_log("Error inicializando configuración Spotify: " . $e->getMessage());
        return false;
    }
}
?>