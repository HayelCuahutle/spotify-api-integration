<?php
// includes/SpotifyAPI.php
class SpotifyAPI {
    private $access_token;
    
    public function __construct() {
        $this->authenticate();
    }
    
    private function authenticate() {
        $ch = curl_init("https://accounts.spotify.com/api/token");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
            "grant_type" => "refresh_token",
            "refresh_token" => SPOTIFY_REFRESH_TOKEN
        ]));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Authorization: Basic " . base64_encode(SPOTIFY_CLIENT_ID . ":" . SPOTIFY_CLIENT_SECRET)
        ]);
        
        $response = json_decode(curl_exec($ch), true);
        curl_close($ch);
        
        if (isset($response["access_token"])) {
            $this->access_token = $response["access_token"];
            return true;
        }
        return false;
    }
    
    public function search($query, $type = 'track', $limit = 12) {
        $ch = curl_init("https://api.spotify.com/v1/search?q=" . urlencode($query) . "&type=$type&limit=$limit");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Authorization: Bearer " . $this->access_token
        ]);
        
        $response = json_decode(curl_exec($ch), true);
        curl_close($ch);
        
        return $response;
    }
    
    public function addToPlaylist($trackUri, $device_id = null) {
        // Agregar a playlist
        $ch = curl_init("https://api.spotify.com/v1/playlists/" . SPOTIFY_PLAYLIST_ID . "/tracks");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([ "uris" => [$trackUri] ]));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Authorization: Bearer " . $this->access_token,
            "Content-Type: application/json"
        ]);
        
        $result = json_decode(curl_exec($ch), true);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        return ['result' => $result, 'http_code' => $http_code];
    }
    
    public function getDevices() {
        $ch = curl_init("https://api.spotify.com/v1/me/player/devices");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Authorization: Bearer " . $this->access_token
        ]);
        
        $result = json_decode(curl_exec($ch), true);
        curl_close($ch);
        
        return $result;
    }
    
    public function playTrack($trackUri, $device_id) {
        $ch = curl_init("https://api.spotify.com/v1/me/player/play?device_id=$device_id");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
            "context_uri" => "spotify:playlist:" . SPOTIFY_PLAYLIST_ID,
            "offset" => ["uri" => $trackUri]
        ]));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Authorization: Bearer " . $this->access_token,
            "Content-Type: application/json"
        ]);
        
        curl_exec($ch);
        curl_close($ch);
    }
    
    public function addToQueue($trackUri, $device_id) {
        $ch = curl_init("https://api.spotify.com/v1/me/player/queue?uri=$trackUri&device_id=$device_id");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Authorization: Bearer " . $this->access_token,
            "Content-Type: application/json"
        ]);
        
        curl_exec($ch);
        curl_close($ch);
    }
    
    public function getPlaybackState() {
        $ch = curl_init("https://api.spotify.com/v1/me/player");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Authorization: Bearer " . $this->access_token
        ]);
        
        $result = json_decode(curl_exec($ch), true);
        curl_close($ch);
        
        return $result;
    }
    
    public function getAccessToken() {
        return $this->access_token;
    }
}
?>