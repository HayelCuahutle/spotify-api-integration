<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config/database.php';

// ============================================
// FUNCIONES DE IDENTIFICACIÓN MEJORADA
// ============================================

// Función para generar huella digital del navegador
function generarHuellaDigital() {
    $components = [
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
        'accept_language' => $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '',
        'screen_resolution' => isset($_POST['screen_res']) ? $_POST['screen_res'] : '',
        'timezone' => isset($_POST['timezone']) ? $_POST['timezone'] : '',
        'plugins' => isset($_POST['plugins']) ? $_POST['plugins'] : '',
        'cookies_enabled' => isset($_POST['cookies']) ? $_POST['cookies'] : '',
        'session_id' => session_id(),
        'ip' => getRealIP()
    ];
    
    // Si tenemos datos del cliente, usarlos
    if (!empty($components['screen_resolution']) && !empty($components['timezone'])) {
        return md5(json_encode($components));
    }
    
    // Fallback: IP + User-Agent + Session ID
    $fallback = [
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
        'ip' => getRealIP(),
        'session_id' => session_id(),
        'time' => time()
    ];
    
    return md5(json_encode($fallback));
}

// Función para obtener o crear huella del usuario
function obtenerHuellaUsuario($pdo, $email = '') {
    // 1. Intentar obtener de cookie primero
    if (isset($_COOKIE['user_fingerprint'])) {
        $huella_hash = $_COOKIE['user_fingerprint'];
        
        // Verificar si existe en BD
        $stmt = $pdo->prepare("SELECT id, email FROM huellas_usuarios WHERE huella_hash = ?");
        $stmt->execute([$huella_hash]);
        
        if ($stmt->rowCount() > 0) {
            // Actualizar última actividad
            $updateStmt = $pdo->prepare("UPDATE huellas_usuarios SET ultima_actividad = NOW() WHERE huella_hash = ?");
            $updateStmt->execute([$huella_hash]);
            
            return $huella_hash;
        }
    }
    
    // 2. Generar nueva huella
    $huella_hash = generarHuellaDigital();
    
    // 3. Guardar en cookie (dura 30 días)
    setcookie('user_fingerprint', $huella_hash, time() + (30 * 24 * 60 * 60), '/', '', false, true);
    
    // 4. Guardar en BD
    $stmt = $pdo->prepare("
        INSERT INTO huellas_usuarios (huella_hash, email, ip_cliente, user_agent) 
        VALUES (?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE 
            email = COALESCE(VALUES(email), email),
            ultima_actividad = NOW()
    ");
    
    $stmt->execute([
        $huella_hash,
        !empty($email) ? $email : NULL,
        getRealIP(),
        $_SERVER['HTTP_USER_AGENT'] ?? ''
    ]);
    
    return $huella_hash;
}

// NUEVA función principal de verificación (REEMPLAZA la antigua)
function verificarEstadoUsuarioMejorado($pdo) {
    $email = $_SESSION['user_email'] ?? null;
    
    // 1. PRIMERO verificar por email (si existe y está en sesión)
    if ($email) {
        $resultado = verificarPorEmail($pdo, $email);
        if ($resultado['status'] !== 'mostrar_formulario') {
            return $resultado;
        }
    }
    
    // 2. Obtener o crear huella digital
    $huella_hash = obtenerHuellaUsuario($pdo, $email);
    
    // 3. Verificar por huella digital
    return verificarPorHuella($pdo, $huella_hash);
}

// Nueva función de verificación por huella
function verificarPorHuella($pdo, $huella_hash) {
    $minutos_limite = obtenerTiempoLimiteConfigurado($pdo);
    
    // Buscar última canción relacionada con esta huella
    $stmt = $pdo->prepare("
        SELECT 
            COALESCE(
                (SELECT fecha FROM canciones_diarias WHERE email_usuario = hu.email ORDER BY fecha DESC, hora DESC LIMIT 1),
                (SELECT fecha FROM canciones_dj WHERE email_usuario = hu.email ORDER BY fecha DESC, hora DESC LIMIT 1)
            ) as fecha,
            COALESCE(
                (SELECT hora FROM canciones_diarias WHERE email_usuario = hu.email ORDER BY fecha DESC, hora DESC LIMIT 1),
                (SELECT hora FROM canciones_dj WHERE email_usuario = hu.email ORDER BY fecha DESC, hora DESC LIMIT 1)
            ) as hora
        FROM huellas_usuarios hu
        WHERE hu.huella_hash = ? 
        AND hu.email IS NOT NULL
        LIMIT 1
    ");
    $stmt->execute([$huella_hash]);
    
    if ($stmt->rowCount() > 0) {
        $ultima = $stmt->fetch();
        
        if (!empty($ultima['fecha']) && !empty($ultima['hora'])) {
            // Calcular tiempo transcurrido
            $ultimoTimestamp = strtotime($ultima['fecha'] . ' ' . $ultima['hora']);
            $ahora = time();
            $minutosTranscurridos = round(($ahora - $ultimoTimestamp) / 60);
            
            if ($minutosTranscurridos < $minutos_limite) {
                return [
                    'status' => 'en_espera',
                    'minutosTranscurridos' => $minutosTranscurridos,
                    'minutosRestantes' => $minutos_limite - $minutosTranscurridos
                ];
            }
        }
    }
    
    // Si no hay email asociado o ya pasó el tiempo, verificar por IP (solo como respaldo)
    $ip = getRealIP();
    $stmtIp = $pdo->prepare("
        SELECT fecha, hora 
        FROM canciones_diarias 
        WHERE ip_usuario = ? 
        ORDER BY fecha DESC, hora DESC 
        LIMIT 1
    ");
    $stmtIp->execute([$ip]);
    
    if ($stmtIp->rowCount() > 0) {
        $ultimaIp = $stmtIp->fetch();
        $ultimoTimestamp = strtotime($ultimaIp['fecha'] . ' ' . $ultimaIp['hora']);
        $ahora = time();
        $minutosTranscurridos = round(($ahora - $ultimoTimestamp) / 60);
        
        if ($minutosTranscurridos < $minutos_limite) {
            return [
                'status' => 'en_espera',
                'minutosTranscurridos' => $minutosTranscurridos,
                'minutosRestantes' => $minutos_limite - $minutosTranscurridos
            ];
        }
    }
    
    // Usuario nuevo o puede agregar
    return ['status' => 'mostrar_formulario'];
}

// ============================================
// FUNCIONES EXISTENTES (MODIFICADAS)
// ============================================

function checkAdminAuth() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
        header('Location: login.php');
        exit;
    }
}

function checkRole($rol_requerido) {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    if (!isset($_SESSION['admin_rol']) || $_SESSION['admin_rol'] !== $rol_requerido) {
        header('Location: unauthorized.php');
        exit;
    }
}

function getCurrentUserRole() {
    return $_SESSION['admin_rol'] ?? 'admin';
}

// Función para obtener IP real (MEJORADA)
function getRealIP() {
    $ip = '';
    
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        // Puede ser una lista de IPs, tomar la primera
        $ips = explode(',', $ip);
        $ip = trim($ips[0]);
    } else {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }
    
    // Validar que sea una IP válida
    if (!filter_var($ip, FILTER_VALIDATE_IP)) {
        $ip = '0.0.0.0';
    }
    
    return $ip;
}

// Función original verificarPorEmail (sin cambios)
function verificarPorEmail($pdo, $email) {
    // PASO 1: ¿Ya calificó hoy?
    $stmtCalificacion = $pdo->prepare("SELECT COUNT(*) as total FROM calificaciones_servicio WHERE correo = ? AND DATE(fecha_registro) = CURDATE()");
    $stmtCalificacion->execute([$email]);
    $yaCalificoHoy = $stmtCalificacion->fetch()['total'] > 0;
    
    // SI NO HA CALIFICADO HOY → Mostrar formulario
    if (!$yaCalificoHoy) {
        return ['status' => 'mostrar_formulario'];
    }
    
    // SI YA CALIFICÓ HOY → Verificar última canción
    $stmtCancion = $pdo->prepare("SELECT fecha, hora FROM canciones_diarias WHERE email_usuario = ? 
                                 UNION ALL 
                                 SELECT fecha, hora FROM canciones_dj WHERE email_usuario = ? 
                                 ORDER BY fecha DESC, hora DESC LIMIT 1");
    $stmtCancion->execute([$email, $email]);
    
    if ($stmtCancion->rowCount() > 0) {
        $ultimaCancion = $stmtCancion->fetch();
        $ultimoTimestamp = strtotime($ultimaCancion['fecha'] . ' ' . $ultimaCancion['hora']);
        $ahora = time();
        $minutosTranscurridos = round(($ahora - $ultimoTimestamp) / 60);
        
        // DEBUG: Mostrar información para troubleshooting
        error_log("DEBUG - Email: $email, Última canción: " . $ultimaCancion['fecha'] . ' ' . $ultimaCancion['hora']);
        error_log("DEBUG - Timestamp: $ultimoTimestamp, Ahora: $ahora, Minutos: $minutosTranscurridos");
        
        $minutos_limite = obtenerTiempoLimiteConfigurado($pdo);
        
        // [<limite min] → Mensaje espera
        if ($minutosTranscurridos < $minutos_limite) {
            return [
                'status' => 'en_espera',
                'minutosTranscurridos' => $minutosTranscurridos,
                'minutosRestantes' => $minutos_limite - $minutosTranscurridos
            ];
        }
        // [≥limite min] → Buscador directo
        else {
            return ['status' => 'buscar_cancion'];
        }
    }
    
    // Si ya calificó pero NUNCA pidió canción → Buscador directo
    return ['status' => 'buscar_cancion'];
}

// Función para obtener tiempo límite configurado
function obtenerTiempoLimiteConfigurado($pdo) {
    try {
        $stmt = $pdo->query("SELECT config_value FROM sistema_config WHERE config_key = 'minutos_limite'");
        $config = $stmt->fetch();
        
        if ($config && $config['config_value'] !== null) {
            $valor = (int)$config['config_value'];
            if ($valor >= 0 && $valor <= 60) {
                return $valor;
            }
        }
    } catch (Exception $e) {
        error_log("Error obteniendo tiempo límite: " . $e->getMessage());
    }
    
    return 30;
}

// Función para obtener máximo de canciones por día
function obtenerMaxCancionesDia($pdo) {
    try {
        $stmt = $pdo->query("SELECT config_value FROM sistema_config WHERE config_key = 'max_canciones_dia'");
        $config = $stmt->fetch();
        
        if ($config && is_numeric($config['config_value'])) {
            return (int)$config['config_value'];
        }
    } catch (Exception $e) {
        error_log("Error obteniendo máximo canciones por día: " . $e->getMessage());
    }
    
    return 5;
}

// FUNCIONES RESTANTES DEL ARCHIVO ORIGINAL (sin cambios)
function getDashboardStats($pdo) {
    $stats = [
        'total_calificaciones' => 0,
        'promedio_calificacion' => 0,
        'total_estrellas' => 0,
        'total_usuarios' => 0,
        'total_canciones' => 0,
        'calificaciones_hoy' => 0,
        'canciones_hoy' => 0,
        'limite_actual' => 35,
        'distribucion_estrellas' => [5 => 0, 4 => 0, 3 => 0, 2 => 0, 1 => 0],
        'calificaciones_recientes' => []
    ];
    
    try {
        // Total calificaciones
        $stmt = $pdo->query("SELECT COUNT(*) as total FROM calificaciones_servicio");
        $result = $stmt->fetch();
        $stats['total_calificaciones'] = $result['total'] ?? 0;
        
        // Calificaciones hoy
        $stmt = $pdo->query("SELECT COUNT(*) as total FROM calificaciones_servicio WHERE DATE(fecha_registro) = CURDATE()");
        $result = $stmt->fetch();
        $stats['calificaciones_hoy'] = $result['total'] ?? 0;
        
        // Promedio calificación y total estrellas
        $stmt = $pdo->query("SELECT AVG(calificacion) as promedio, SUM(calificacion) as total_estrellas FROM calificaciones_servicio");
        $avg_data = $stmt->fetch();
        $stats['promedio_calificacion'] = round($avg_data['promedio'] ?? 0, 1);
        $stats['total_estrellas'] = $avg_data['total_estrellas'] ?? 0;
        
        // Calificaciones recientes (últimas 5)
        $stmt = $pdo->query("SELECT * FROM calificaciones_servicio 
                            ORDER BY fecha_registro DESC 
                            LIMIT 5");
        $stats['calificaciones_recientes'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Distribución de estrellas
        $stmt = $pdo->query("SELECT calificacion, COUNT(*) as cantidad 
                            FROM calificaciones_servicio 
                            GROUP BY calificacion 
                            ORDER BY calificacion DESC");
        $distribucion = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Reinicializar array de distribución
        $stats['distribucion_estrellas'] = [1 => 0, 2 => 0, 3 => 0, 4 => 0, 5 => 0];
        foreach ($distribucion as $row) {
            $calificacion = (int)$row['calificacion'];
            if ($calificacion >= 1 && $calificacion <= 5) {
                $stats['distribucion_estrellas'][$calificacion] = (int)$row['cantidad'];
            }
        }
        
        // Total usuarios
        $stmt = $pdo->query("SELECT COUNT(*) as total FROM usuarios_registrados");
        $result = $stmt->fetch();
        $stats['total_usuarios'] = $result['total'] ?? 0;
        
        // Total canciones
        $stmt = $pdo->query("SELECT COUNT(*) as total FROM canciones_diarias");
        $result = $stmt->fetch();
        $stats['total_canciones'] = $result['total'] ?? 0;
        
        // Canciones de hoy
        $stmt = $pdo->query("SELECT COUNT(*) as total FROM canciones_diarias WHERE fecha = CURDATE()");
        $result = $stmt->fetch();
        $stats['canciones_hoy'] = $result['total'] ?? 0;
        
        // Límite actual (desde configuración)
        $stmt = $pdo->query("SELECT config_value FROM sistema_config WHERE config_key = 'minutos_limite'");
        $config = $stmt->fetch();
        $stats['limite_actual'] = $config['config_value'] ?? 30;
        
    } catch (PDOException $e) {
        error_log("Error en getDashboardStats: " . $e->getMessage());
    }
    
    return $stats;
}

function getCalificacionesFiltradas($pdo, $filtro_estrellas = '', $filtro_busqueda = '', $limit = 10, $offset = 0) {
    $sql = "SELECT * FROM calificaciones_servicio WHERE 1=1";
    $params = [];
    
    if (!empty($filtro_estrellas) && is_numeric($filtro_estrellas)) {
        $sql .= " AND calificacion = ?";
        $params[] = $filtro_estrellas;
    }
    
    if (!empty($filtro_busqueda)) {
        $sql .= " AND (nombre LIKE ? OR correo LIKE ? OR comentarios LIKE ?)";
        $search_term = "%$filtro_busqueda%";
        $params[] = $search_term;
        $params[] = $search_term;
        $params[] = $search_term;
    }
    
    $sql .= " ORDER BY fecha_registro DESC LIMIT $limit OFFSET $offset";
    
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        error_log("Error en getCalificacionesFiltradas: " . $e->getMessage());
        return [];
    }
}

function contarCalificaciones($pdo, $filtro_estrellas = '', $filtro_busqueda = '') {
    $sql = "SELECT COUNT(*) as total FROM calificaciones_servicio WHERE 1=1";
    $params = [];
    
    if (!empty($filtro_estrellas) && is_numeric($filtro_estrellas)) {
        $sql .= " AND calificacion = ?";
        $params[] = $filtro_estrellas;
    }
    
    if (!empty($filtro_busqueda)) {
        $sql .= " AND (nombre LIKE ? OR correo LIKE ? OR comentarios LIKE ?)";
        $search_term = "%$filtro_busqueda%";
        $params[] = $search_term;
        $params[] = $search_term;
        $params[] = $search_term;
    }
    
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $result = $stmt->fetch();
        return $result['total'] ?? 0;
    } catch (PDOException $e) {
        error_log("Error en contarCalificaciones: " . $e->getMessage());
        return 0;
    }
}

function getDJStats($pdo) {
    $stats = [
        'pendientes' => 0,
        'reproducidas' => 0,
        'total_hoy' => 0,
        'total_dj' => 0
    ];
    
    try {
        // Canciones pendientes
        $stmt = $pdo->query("SELECT COUNT(*) as total FROM canciones_dj WHERE estado = 'pendiente'");
        $result = $stmt->fetch();
        $stats['pendientes'] = $result['total'] ?? 0;
        
        // Canciones reproducidas hoy
        $stmt = $pdo->query("SELECT COUNT(*) as total FROM canciones_dj WHERE estado = 'reproducida' AND fecha = CURDATE()");
        $result = $stmt->fetch();
        $stats['reproducidas'] = $result['total'] ?? 0;
        
        // Total solicitudes hoy
        $stmt = $pdo->query("SELECT COUNT(*) as total FROM canciones_dj WHERE fecha = CURDATE()");
        $result = $stmt->fetch();
        $stats['total_hoy'] = $result['total'] ?? 0;
        
        // Total en cola DJ
        $stmt = $pdo->query("SELECT COUNT(*) as total FROM canciones_dj");
        $result = $stmt->fetch();
        $stats['total_dj'] = $result['total'] ?? 0;
        
    } catch (PDOException $e) {
        error_log("Error en getDJStats: " . $e->getMessage());
    }
    
    return $stats;
}

function esAdministrador() {
    return getCurrentUserRole() === 'admin';
}

function tienePermiso($permiso) {
    $rol = getCurrentUserRole();
    
    // Definir permisos por rol
    $permisos = [
        'admin' => [
            'gestion_usuarios', 'configuracion', 'agregar_cancion', 
            'ver_calificaciones', 'ver_usuarios', 'ver_canciones', 'ver_dj'
        ],
        'dj' => [
            'ver_cola_dj', 'dashboard_dj'
        ]
    ];
    
    return in_array($permiso, $permisos[$rol] ?? []);
}

function getCurrentUserId() {
    return $_SESSION['admin_id'] ?? 0;
}

function registrarLog($accion, $detalles = '') {
    try {
        global $pdo;
        $usuario_id = getCurrentUserId();
        $ip_address = getRealIP();
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        
        $stmt = $pdo->prepare("INSERT INTO sistema_logs 
            (usuario_id, accion, detalles, ip_address, user_agent) 
            VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$usuario_id, $accion, $detalles, $ip_address, $user_agent]);
    } catch (Exception $e) {
        error_log("Error en registrarLog: " . $e->getMessage());
    }
}

// Función original para validación por email (usada en addToPlaylist.php)
function puedeAgregarPorEmailOriginal($conn, $email) {
    if (empty($email)) {
        return ["puede" => true, "mensaje" => ""];
    }
    
    $minutos_limite = obtenerTiempoLimiteConfigurado($conn);
    
    $stmt = $conn->prepare("
        SELECT fecha, hora FROM canciones_diarias WHERE email_usuario = ? 
        UNION ALL 
        SELECT fecha, hora FROM canciones_dj WHERE email_usuario = ? 
        ORDER BY fecha DESC, hora DESC 
        LIMIT 1
    ");
    $stmt->bind_param("ss", $email, $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        $stmt->close();
        return ["puede" => true, "mensaje" => ""];
    }
    
    $ultimaCancion = $result->fetch_assoc();
    $stmt->close();
    
    $ultimoTimestamp = strtotime($ultimaCancion['fecha'] . ' ' . $ultimaCancion['hora']);
    $ahora = time();
    $diferenciaMinutos = ($ahora - $ultimoTimestamp) / 60;
    
    if ($diferenciaMinutos < $minutos_limite) {
        $minutosRestantes = ceil($minutos_limite - $diferenciaMinutos);
        return [
            "puede" => false, 
            "mensaje" => "Límite: 1 canción por {$minutos_limite} minutos. Espera {$minutosRestantes} minutos"
        ];
    }
    
    $max_canciones_dia = obtenerMaxCancionesDia($conn);
    
    $stmt_dia = $conn->prepare("
        SELECT COUNT(*) as total_hoy 
        FROM (
            SELECT id FROM canciones_diarias 
            WHERE email_usuario = ? AND fecha = CURDATE()
            UNION ALL
            SELECT id FROM canciones_dj 
            WHERE email_usuario = ? AND fecha = CURDATE()
        ) AS total_canciones
    ");
    $stmt_dia->bind_param("ss", $email, $email);
    $stmt_dia->execute();
    $result_dia = $stmt_dia->get_result();
    $total_hoy = $result_dia->fetch_assoc()['total_hoy'] ?? 0;
    $stmt_dia->close();
    
    if ($total_hoy >= $max_canciones_dia) {
        return [
            "puede" => false,
            "mensaje" => "Límite alcanzado: máximo {$max_canciones_dia} canciones por día. Intenta mañana."
        ];
    }
    
    return ["puede" => true, "mensaje" => ""];
}

// Función original para validación por IP (usada en addToPlaylist.php)
function puedeAgregarPorIPOriginal($conn, $ip) {
    $minutos_limite = obtenerTiempoLimiteConfigurado($conn);
    
    $stmt = $conn->prepare("
        SELECT fecha, hora FROM canciones_diarias WHERE ip_usuario = ? 
        UNION ALL 
        SELECT fecha, hora FROM canciones_dj WHERE ip_usuario = ? 
        ORDER BY fecha DESC, hora DESC 
        LIMIT 1
    ");
    $stmt->bind_param("ss", $ip, $ip);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        $stmt->close();
        return ["puede" => true, "mensaje" => ""];
    }
    
    $ultimaCancion = $result->fetch_assoc();
    $stmt->close();
    
    $ultimoTimestamp = strtotime($ultimaCancion['fecha'] . ' ' . $ultimaCancion['hora']);
    $ahora = time();
    $diferenciaMinutos = ($ahora - $ultimoTimestamp) / 60;
    
    if ($diferenciaMinutos < $minutos_limite) {
        $minutosRestantes = ceil($minutos_limite - $diferenciaMinutos);
        return [
            "puede" => false, 
            "mensaje" => "Espera {$minutosRestantes} minutos"
        ];
    }
    
    $max_canciones_dia = obtenerMaxCancionesDia($conn);
    
    $stmt_dia = $conn->prepare("
        SELECT COUNT(*) as total_hoy 
        FROM (
            SELECT id FROM canciones_diarias 
            WHERE ip_usuario = ? AND fecha = CURDATE()
            UNION ALL
            SELECT id FROM canciones_dj 
            WHERE ip_usuario = ? AND fecha = CURDATE()
        ) AS total_canciones
    ");
    $stmt_dia->bind_param("ss", $ip, $ip);
    $stmt_dia->execute();
    $result_dia = $stmt_dia->get_result();
    $total_hoy = $result_dia->fetch_assoc()['total_hoy'] ?? 0;
    $stmt_dia->close();
    
    if ($total_hoy >= $max_canciones_dia) {
        return [
            "puede" => false,
            "mensaje" => "Límite diario alcanzado para esta IP. Intenta mañana."
        ];
    }
    
    return ["puede" => true, "mensaje" => ""];
}

function eliminarCancionesDeSpotify($pdo, $ids_canciones = null) {
    try {
        if (!defined('SPOTIFY_CLIENT_ID') || !defined('SPOTIFY_CLIENT_SECRET') || 
            !defined('SPOTIFY_REFRESH_TOKEN') || !defined('SPOTIFY_PLAYLIST_ID')) {
            throw new Exception("Credenciales de Spotify no configuradas");
        }
        
        $ch = curl_init("https://accounts.spotify.com/api/token");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
            "grant_type" => "refresh_token",
            "refresh_token" => SPOTIFY_REFRESH_TOKEN
        ]));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Authorization: Basic " . base64_encode(SPOTIFY_CLIENT_ID . ":" . SPOTIFY_CLIENT_SECRET)
        ]);
        
        $response = json_decode(curl_exec($ch), true);
        curl_close($ch);
        
        if (!isset($response["access_token"])) {
            throw new Exception("No se pudo obtener access token de Spotify");
        }
        
        $access_token = $response["access_token"];
        
        $uris = [];
        if ($ids_canciones === null) {
            $stmt = $pdo->query("SELECT uri FROM canciones_diarias");
            $canciones = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } else {
            if (!is_array($ids_canciones) || empty($ids_canciones)) {
                return ["success" => true, "message" => "No hay IDs de canciones especificados"];
            }
            
            $placeholders = str_repeat('?,', count($ids_canciones) - 1) . '?';
            $stmt = $pdo->prepare("SELECT uri FROM canciones_diarias WHERE id IN ($placeholders)");
            $stmt->execute($ids_canciones);
            $canciones = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
        
        foreach ($canciones as $cancion) {
            if (!empty($cancion['uri'])) {
                $uris[] = ["uri" => $cancion['uri']];
            }
        }
        
        if (empty($uris)) {
            return ["success" => true, "message" => "No hay canciones para eliminar"];
        }
        
        $chunks = array_chunk($uris, 100);
        $results = [];
        $total_eliminadas = 0;
        
        foreach ($chunks as $chunk) {
            $ch = curl_init("https://api.spotify.com/v1/playlists/" . SPOTIFY_PLAYLIST_ID . "/tracks");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(["tracks" => $chunk]));
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                "Authorization: Bearer {$access_token}",
                "Content-Type: application/json"
            ]);
            
            $response = json_decode(curl_exec($ch), true);
            $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            if ($http_code === 200) {
                $total_eliminadas += count($chunk);
            }
            
            $results[] = [
                "http_code" => $http_code,
                "response" => $response,
                "canciones_eliminadas" => count($chunk),
                "success" => $http_code === 200
            ];
        }
        
        return [
            "success" => true,
            "results" => $results,
            "total_eliminadas" => $total_eliminadas,
            "message" => "Se eliminaron {$total_eliminadas} canciones de Spotify"
        ];
        
    } catch (Exception $e) {
        return [
            "success" => false,
            "error" => $e->getMessage(),
            "message" => "Error al eliminar canciones de Spotify: " . $e->getMessage()
        ];
    }
}

function spotifyActivo($pdo) {
    try {
        $stmt = $pdo->query("SELECT config_value FROM sistema_config WHERE config_key = 'spotify_activo'");
        $config = $stmt->fetch();
        
        if ($config && $config['config_value'] == '1') {
            return true;
        }
    } catch (Exception $e) {
        error_log("Error verificando estado de Spotify: " . $e->getMessage());
    }
    
    return true;
}

function obtenerConfiguraciones($pdo) {
    static $config_cache = null;
    
    if ($config_cache === null) {
        $config_cache = [];
        
        try {
            $stmt = $pdo->query("SELECT config_key, config_value FROM sistema_config");
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            foreach ($rows as $row) {
                $config_cache[$row['config_key']] = $row['config_value'];
            }
            
            // Asegurar que las configuraciones de ubicación existan
            $configs_necesarias = [
                'lat_calita' => '19.2062478',
                'lon_calita' => '-98.2332175',
                'distancia_maxima' => '20000'
            ];
            
            foreach ($configs_necesarias as $key => $default) {
                if (!isset($config_cache[$key])) {
                    // Insertar configuración faltante
                    $stmt = $pdo->prepare("
                        INSERT INTO sistema_config (config_key, config_value) 
                        VALUES (?, ?)
                        ON DUPLICATE KEY UPDATE config_value = ?
                    ");
                    $stmt->execute([$key, $default, $default]);
                    $config_cache[$key] = $default;
                }
            }
            
        } catch (Exception $e) {
            error_log("Error obteniendo configuraciones: " . $e->getMessage());
            
            // Valores por defecto
            $config_cache = array_merge($config_cache, [
                'lat_calita' => '19.2062478',
                'lon_calita' => '-98.2332175',
                'distancia_maxima' => '20000',
                'minutos_limite' => '30',
                'max_canciones_dia' => '5',
                'spotify_activo' => '1',
                'notificaciones_activas' => '1',
                'canciones_activas' => '1',
                'dj_activo' => '0'
            ]);
        }
    }
    
    return $config_cache;
}

function obtenerTextoLimite($pdo) {
    $minutos_limite = obtenerTiempoLimiteConfigurado($pdo);
    $max_canciones_dia = obtenerMaxCancionesDia($pdo);
    
    return "Puedes solicitar 1 canción cada {$minutos_limite} minutos, máximo {$max_canciones_dia} canciones por día.";
}

function getUbicacionConfig($pdo) {
    try {
        $stmt = $pdo->query("
            SELECT config_key, config_value 
            FROM sistema_config 
            WHERE config_key IN ('lat_calita', 'lon_calita', 'distancia_maxima')
        ");

        $configs = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

        return [
            'lat' => isset($configs['lat_calita']) ? (float)$configs['lat_calita'] : 19.2062478,
            'lon' => isset($configs['lon_calita']) ? (float)$configs['lon_calita'] : -98.2332175,
            'radio' => isset($configs['distancia_maxima']) ? (int)$configs['distancia_maxima'] : 20000
        ];

    } catch (Exception $e) {
        error_log("Error en getUbicacionConfig: " . $e->getMessage());

        return [
            'lat' => 19.2062478,
            'lon' => -98.2332175,
            'radio' => 20000
        ];
    }
}

function obtenerCoordenadasParaValidacion($pdo) {
    $ubicacion = getUbicacionConfig($pdo);
    
    return [
        'lat_calita' => $ubicacion['lat'],
        'lon_calita' => $ubicacion['lon'],
        'distancia_maxima' => $ubicacion['radio']
    ];
}

function validarUbicacion($lat_usuario, $lon_usuario, $pdo) {
    $config = obtenerCoordenadasParaValidacion($pdo);
    
    $lat_calita = $config['lat_calita'];
    $lon_calita = $config['lon_calita'];
    $distancia_maxima = $config['distancia_maxima'];
    
    // Función de distancia Haversine
    function calcularDistancia($lat1, $lon1, $lat2, $lon2) {
        $radio_tierra = 6371000; // metros
        $lat1 = deg2rad($lat1);
        $lon1 = deg2rad($lon1);
        $lat2 = deg2rad($lat2);
        $lon2 = deg2rad($lon2);

        return $radio_tierra * acos(
            cos($lat1) * cos($lat2) * cos($lon2 - $lon1) +
            sin($lat1) * sin($lat2)
        );
    }
    
    $distancia = calcularDistancia($lat_usuario, $lon_usuario, $lat_calita, $lon_calita);
    
    return [
        'dentro' => $distancia <= $distancia_maxima,
        'distancia' => $distancia,
        'distancia_maxima' => $distancia_maxima,
        'distancia_km' => round($distancia / 1000, 2)
    ];
}
?>