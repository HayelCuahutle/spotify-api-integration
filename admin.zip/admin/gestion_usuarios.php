<?php
require_once 'config/database.php';
require_once 'includes/functions.php';
checkAdminAuth();

// ✅ SOLO ADMINISTRADORES PUEDEN ACCEDER
if (!esAdministrador()) {
    header('Location: dashboard_dj.php');
    exit;
}

$mensaje = '';
$tipo_mensaje = '';

// Procesar acciones
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['agregar_usuario'])) {
        $username = trim($_POST['username']);
        $email = trim($_POST['email']);
        $password = $_POST['password'];
        $confirm_password = $_POST['confirm_password'];
        $rol = $_POST['rol'];
        $nombre_completo = trim($_POST['nombre_completo']);
        $telefono = trim($_POST['telefono']);
        
        // Validaciones
        if (empty($username) || empty($email) || empty($password)) {
            $mensaje = "❌ Usuario, email y contraseña son obligatorios";
            $tipo_mensaje = "danger";
        } elseif ($password !== $confirm_password) {
            $mensaje = "❌ Las contraseñas no coinciden";
            $tipo_mensaje = "danger";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $mensaje = "❌ Email inválido";
            $tipo_mensaje = "danger";
        } else {
            try {
                // Verificar si usuario ya existe
                $stmt_check = $pdo->prepare("SELECT id FROM sistema_usuarios WHERE username = ? OR email = ?");
                $stmt_check->execute([$username, $email]);
                
                if ($stmt_check->rowCount() > 0) {
                    $mensaje = "❌ El usuario o email ya existe";
                    $tipo_mensaje = "danger";
                } else {
                    // Hash de la contraseña
                    $password_hash = password_hash($password, PASSWORD_DEFAULT);
                    $admin_id = getCurrentUserId();
                    
                    $stmt = $pdo->prepare("INSERT INTO sistema_usuarios 
                        (username, email, password_hash, rol, nombre_completo, telefono, creado_por) 
                        VALUES (?, ?, ?, ?, ?, ?, ?)");
                    
                    if ($stmt->execute([$username, $email, $password_hash, $rol, $nombre_completo, $telefono, $admin_id])) {
                        $mensaje = "✅ Usuario agregado correctamente";
                        $tipo_mensaje = "success";
                        registrarLog('agregar_usuario', "Usuario: $username, Rol: $rol");
                    } else {
                        $mensaje = "❌ Error al agregar usuario";
                        $tipo_mensaje = "danger";
                    }
                }
            } catch (Exception $e) {
                $mensaje = "❌ Error: " . $e->getMessage();
                $tipo_mensaje = "danger";
            }
        }
    }
    
    elseif (isset($_POST['editar_usuario'])) {
        $id = (int)$_POST['id'];
        $username = trim($_POST['username']);
        $email = trim($_POST['email']);
        $rol = $_POST['rol'];
        $nombre_completo = trim($_POST['nombre_completo']);
        $telefono = trim($_POST['telefono']);
        $activo = isset($_POST['activo']) ? 1 : 0;
        
        // Si se proporciona nueva contraseña
        $update_password = '';
        if (!empty($_POST['nueva_password'])) {
            if ($_POST['nueva_password'] !== $_POST['confirmar_password']) {
                $mensaje = "❌ Las contraseñas no coinciden";
                $tipo_mensaje = "danger";
            } else {
                $password_hash = password_hash($_POST['nueva_password'], PASSWORD_DEFAULT);
                $update_password = ", password_hash = ?";
            }
        }
        
        try {
            // Verificar si otro usuario tiene el mismo username o email
            $stmt_check = $pdo->prepare("SELECT id FROM sistema_usuarios 
                WHERE (username = ? OR email = ?) AND id != ?");
            $stmt_check->execute([$username, $email, $id]);
            
            if ($stmt_check->rowCount() > 0) {
                $mensaje = "❌ El usuario o email ya está en uso por otro usuario";
                $tipo_mensaje = "danger";
            } else {
                if (!empty($update_password)) {
                    $sql = "UPDATE sistema_usuarios SET 
                        username = ?, email = ?, rol = ?, nombre_completo = ?, 
                        telefono = ?, activo = ? $update_password 
                        WHERE id = ?";
                    $params = [$username, $email, $rol, $nombre_completo, $telefono, $activo, $password_hash, $id];
                } else {
                    $sql = "UPDATE sistema_usuarios SET 
                        username = ?, email = ?, rol = ?, nombre_completo = ?, 
                        telefono = ?, activo = ? 
                        WHERE id = ?";
                    $params = [$username, $email, $rol, $nombre_completo, $telefono, $activo, $id];
                }
                
                $stmt = $pdo->prepare($sql);
                
                if ($stmt->execute($params)) {
                    $mensaje = "✅ Usuario actualizado correctamente";
                    $tipo_mensaje = "success";
                    registrarLog('editar_usuario', "Usuario ID: $id, Rol: $rol");
                } else {
                    $mensaje = "❌ Error al actualizar usuario";
                    $tipo_mensaje = "danger";
                }
            }
        } catch (Exception $e) {
            $mensaje = "❌ Error: " . $e->getMessage();
            $tipo_mensaje = "danger";
        }
    }
    
    elseif (isset($_POST['eliminar_usuario'])) {
        $id = (int)$_POST['id'];
        
        // No permitir eliminar al propio usuario administrador
        if ($id == getCurrentUserId()) {
            $mensaje = "❌ No puedes eliminar tu propio usuario";
            $tipo_mensaje = "danger";
        } else {
            try {
                $stmt = $pdo->prepare("DELETE FROM sistema_usuarios WHERE id = ?");
                
                if ($stmt->execute([$id])) {
                    $mensaje = "✅ Usuario eliminado correctamente";
                    $tipo_mensaje = "success";
                    registrarLog('eliminar_usuario', "Usuario ID: $id");
                } else {
                    $mensaje = "❌ Error al eliminar usuario";
                    $tipo_mensaje = "danger";
                }
            } catch (Exception $e) {
                $mensaje = "❌ Error: " . $e->getMessage();
                $tipo_mensaje = "danger";
            }
        }
    }
}

// Obtener lista de usuarios
$usuarios = [];
$busqueda = $_GET['busqueda'] ?? '';
$filtro_rol = $_GET['rol'] ?? '';

try {
    $sql = "SELECT * FROM sistema_usuarios WHERE 1=1";
    $params = [];
    
    if (!empty($busqueda)) {
        $sql .= " AND (username LIKE ? OR email LIKE ? OR nombre_completo LIKE ?)";
        $search_term = "%$busqueda%";
        $params[] = $search_term;
        $params[] = $search_term;
        $params[] = $search_term;
    }
    
    if (!empty($filtro_rol)) {
        $sql .= " AND rol = ?";
        $params[] = $filtro_rol;
    }
    
    $sql .= " ORDER BY fecha_creacion DESC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $usuarios = $stmt->fetchAll();
} catch (Exception $e) {
    $mensaje = "❌ Error al cargar usuarios: " . $e->getMessage();
    $tipo_mensaje = "danger";
}

// Obtener usuario para editar (si se solicita)
$usuario_editar = null;
if (isset($_GET['editar']) && is_numeric($_GET['editar'])) {
    $id_editar = (int)$_GET['editar'];
    try {
        $stmt = $pdo->prepare("SELECT * FROM sistema_usuarios WHERE id = ?");
        $stmt->execute([$id_editar]);
        $usuario_editar = $stmt->fetch();
    } catch (Exception $e) {
        $mensaje = "❌ Error al cargar usuario: " . $e->getMessage();
        $tipo_mensaje = "danger";
    }
}
?>

<?php include 'includes/header.php'; ?>

<div class="container-fluid p-4">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0">
            <i class="fas fa-users-cog me-2"></i>Gestión de Usuarios del Sistema
        </h1>
        <div class="text-muted">
            Total: <strong><?php echo count($usuarios); ?></strong> usuarios
        </div>
    </div>

    <?php if ($mensaje): ?>
        <div class="alert alert-<?php echo $tipo_mensaje; ?> alert-dismissible fade show">
            <?php echo $mensaje; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row">
        <!-- Formulario para agregar/editar usuario -->
        <div class="col-lg-4 mb-4">
            <div class="card">
                <div class="card-header <?php echo $usuario_editar ? 'bg-warning text-dark' : 'bg-success text-white'; ?>">
                    <h5 class="mb-0">
                        <i class="fas <?php echo $usuario_editar ? 'fa-edit' : 'fa-user-plus'; ?> me-2"></i>
                        <?php echo $usuario_editar ? 'Editar Usuario' : 'Agregar Nuevo Usuario'; ?>
                    </h5>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <?php if ($usuario_editar): ?>
                            <input type="hidden" name="id" value="<?php echo $usuario_editar['id']; ?>">
                        <?php endif; ?>
                        
                        <div class="mb-3">
                            <label class="form-label">Username *</label>
                            <input type="text" name="username" class="form-control" 
                                   value="<?php echo $usuario_editar ? htmlspecialchars($usuario_editar['username']) : ''; ?>" 
                                   required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Email *</label>
                            <input type="email" name="email" class="form-control" 
                                   value="<?php echo $usuario_editar ? htmlspecialchars($usuario_editar['email']) : ''; ?>" 
                                   required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Nombre Completo</label>
                            <input type="text" name="nombre_completo" class="form-control" 
                                   value="<?php echo $usuario_editar ? htmlspecialchars($usuario_editar['nombre_completo']) : ''; ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Teléfono</label>
                            <input type="tel" name="telefono" class="form-control" 
                                   value="<?php echo $usuario_editar ? htmlspecialchars($usuario_editar['telefono']) : ''; ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Rol *</label>
                            <select name="rol" class="form-select" required>
                                <option value="admin" <?php echo ($usuario_editar && $usuario_editar['rol'] == 'admin') ? 'selected' : ''; ?>>Administrador</option>
                                <option value="dj" <?php echo ($usuario_editar && $usuario_editar['rol'] == 'dj') ? 'selected' : ''; ?>>DJ</option>
                            </select>
                        </div>
                        
                        <?php if ($usuario_editar): ?>
                            <!-- Campos para editar -->
                            <div class="mb-3">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" name="activo" id="activo" 
                                           <?php echo ($usuario_editar && $usuario_editar['activo'] == 1) ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="activo">Usuario Activo</label>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Nueva Contraseña (dejar en blanco para mantener la actual)</label>
                                <input type="password" name="nueva_password" class="form-control">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Confirmar Nueva Contraseña</label>
                                <input type="password" name="confirmar_password" class="form-control">
                            </div>
                            
                            <div class="d-grid gap-2">
                                <button type="submit" name="editar_usuario" class="btn btn-warning">
                                    <i class="fas fa-save me-2"></i>Actualizar Usuario
                                </button>
                                <a href="gestion_usuarios.php" class="btn btn-secondary">
                                    <i class="fas fa-times me-2"></i>Cancelar
                                </a>
                            </div>
                        <?php else: ?>
                            <!-- Campos para agregar -->
                            <div class="mb-3">
                                <label class="form-label">Contraseña *</label>
                                <input type="password" name="password" class="form-control" required>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Confirmar Contraseña *</label>
                                <input type="password" name="confirm_password" class="form-control" required>
                            </div>
                            
                            <button type="submit" name="agregar_usuario" class="btn btn-success w-100">
                                <i class="fas fa-plus-circle me-2"></i>Agregar Usuario
                            </button>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>

        <!-- Lista de usuarios -->
        <div class="col-lg-8">
            <!-- Filtros y búsqueda -->
            <div class="card mb-4">
                <div class="card-body">
                    <form method="GET" class="row g-3">
                        <div class="col-md-5">
                            <input type="text" name="busqueda" class="form-control" 
                                   placeholder="Buscar por username, email o nombre..." 
                                   value="<?php echo htmlspecialchars($busqueda); ?>">
                        </div>
                        <div class="col-md-3">
                            <select name="rol" class="form-select">
                                <option value="">Todos los roles</option>
                                <option value="admin" <?php echo $filtro_rol == 'admin' ? 'selected' : ''; ?>>Administrador</option>
                                <option value="dj" <?php echo $filtro_rol == 'dj' ? 'selected' : ''; ?>>DJ</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <button type="submit" class="btn btn-primary me-2">
                                <i class="fas fa-search me-2"></i>Buscar
                            </button>
                            <a href="gestion_usuarios.php" class="btn btn-secondary">
                                <i class="fas fa-refresh me-2"></i>Limpiar
                            </a>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Tabla de usuarios -->
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Usuarios del Sistema</h5>
                </div>
                <div class="card-body p-0">
                    <?php if (empty($usuarios)): ?>
                        <div class="text-center py-5">
                            <i class="fas fa-users-slash fa-3x text-muted mb-3"></i>
                            <h5>No se encontraron usuarios</h5>
                            <p class="text-muted">Agrega un nuevo usuario usando el formulario.</p>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>#</th>
                                        <th>Usuario</th>
                                        <th>Email</th>
                                        <th>Nombre</th>
                                        <th>Rol</th>
                                        <th>Estado</th>
                                        <th>Creado</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($usuarios as $index => $usuario): ?>
                                        <tr>
                                            <td><?php echo $index + 1; ?></td>
                                            <td>
                                                <strong><?php echo htmlspecialchars($usuario['username']); ?></strong>
                                            </td>
                                            <td><?php echo htmlspecialchars($usuario['email']); ?></td>
                                            <td><?php echo htmlspecialchars($usuario['nombre_completo'] ?? '-'); ?></td>
                                            <td>
                                                <span class="badge <?php echo $usuario['rol'] == 'admin' ? 'bg-primary' : 'bg-warning text-dark'; ?>">
                                                    <?php echo strtoupper($usuario['rol']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <span class="badge <?php echo $usuario['activo'] == 1 ? 'bg-success' : 'bg-danger'; ?>">
                                                    <?php echo $usuario['activo'] == 1 ? 'Activo' : 'Inactivo'; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <small class="text-muted">
                                                    <?php echo date('d/m/Y', strtotime($usuario['fecha_creacion'])); ?>
                                                </small>
                                            </td>
                                            <td>
                                                <div class="btn-group" role="group">
                                                    <a href="?editar=<?php echo $usuario['id']; ?>" 
                                                       class="btn btn-sm btn-outline-primary" title="Editar">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <form method="POST" class="d-inline" 
                                                          onsubmit="return confirm('¿Estás seguro de eliminar este usuario?')">
                                                        <input type="hidden" name="id" value="<?php echo $usuario['id']; ?>">
                                                        <button type="submit" name="eliminar_usuario" 
                                                                class="btn btn-sm btn-outline-danger" title="Eliminar"
                                                                <?php echo $usuario['id'] == getCurrentUserId() ? 'disabled' : ''; ?>>
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>