<?php
// admin/dashboard.php
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/spotify_functions.php';
checkAdminAuth();

// ============================================
// OBTENER CONFIGURACIONES DEL SISTEMA
// ============================================

// Obtener estado actual del sistema de canciones
$stmt_config = $pdo->query("SELECT config_value FROM sistema_config WHERE config_key = 'canciones_activas'");
$config = $stmt_config->fetch();
$canciones_activas = $config['config_value'] ?? '1';

// Obtener estado actual del DJ
$stmt_dj = $pdo->query("SELECT config_value FROM sistema_config WHERE config_key = 'dj_activo'");
$config_dj = $stmt_dj->fetch();
$dj_activo = $config_dj['config_value'] ?? '0';

// Obtener estado actual del mantenimiento del buscador
$stmt_mantenimiento = $pdo->query("SELECT config_value FROM sistema_config WHERE config_key = 'buscador_mantenimiento'");
$config_mantenimiento = $stmt_mantenimiento->fetch();
$buscador_mantenimiento = $config_mantenimiento['config_value'] ?? '0';

// ============================================
// NUEVO: OBTENER CONFIGURACIÓN DE UBICACIÓN
// ============================================
$stmt_ubicacion = $pdo->query("SELECT config_value FROM sistema_config WHERE config_key = 'ubicacion_activa'");
$config_ubicacion = $stmt_ubicacion->fetch();
$ubicacion_activa = $config_ubicacion['config_value'] ?? '1';

// Obtener coordenadas
$stmt_coords = $pdo->query("SELECT config_key, config_value FROM sistema_config WHERE config_key IN ('lat_calita', 'lon_calita', 'distancia_maxima')");
$coords = $stmt_coords->fetchAll(PDO::FETCH_KEY_PAIR);
$lat_calita = $coords['lat_calita'] ?? '19.2062478';
$lon_calita = $coords['lon_calita'] ?? '-98.2332175';
$distancia_maxima = $coords['distancia_maxima'] ?? '20000';

// ============================================
// PROCESAR ACCIONES DEL ADMINISTRADOR
// ============================================

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['accion'])) {
    if ($_POST['accion'] === 'desactivar_canciones') {
        $stmt = $pdo->prepare("UPDATE sistema_config SET config_value = '0' WHERE config_key = 'canciones_activas'");
        $stmt->execute();
        $mensaje = "✅ Sistema de canciones DESACTIVADO";
    } elseif ($_POST['accion'] === 'activar_canciones') {
        $stmt = $pdo->prepare("UPDATE sistema_config SET config_value = '1' WHERE config_key = 'canciones_activas'");
        $stmt->execute();
        $mensaje = "✅ Sistema de canciones ACTIVADO";
    } elseif ($_POST['accion'] === 'activar_dj') {
        $stmt = $pdo->prepare("UPDATE sistema_config SET config_value = '1' WHERE config_key = 'dj_activo'");
        $stmt->execute();
        $mensaje = "✅ Modo DJ ACTIVADO - Las canciones se guardarán en cola del DJ";
    } elseif ($_POST['accion'] === 'desactivar_dj') {
        $stmt = $pdo->prepare("UPDATE sistema_config SET config_value = '0' WHERE config_key = 'dj_activo'");
        $stmt->execute();
        $mensaje = "✅ Modo DJ DESACTIVADO - Las canciones se agregan normal al playlist";
    
    // ✅ NUEVA ACCIÓN: Borrar lista DJ
    } elseif ($_POST['accion'] === 'borrar_lista_dj') {
        try {
            // Contar canciones antes de borrar para el mensaje
            $stmt_count = $pdo->query("SELECT COUNT(*) as total FROM canciones_dj");
            $total_canciones = $stmt_count->fetch()['total'];
            
            // Borrar TODAS las canciones de la cola DJ
            $stmt = $pdo->prepare("DELETE FROM canciones_dj");
            $stmt->execute();
            
            $mensaje = "✅ Lista del DJ borrada correctamente - Se eliminaron $total_canciones canción(es)";
            
        } catch (Exception $e) {
            $mensaje = "❌ Error al borrar la lista del DJ: " . $e->getMessage();
        }
    
    // ✅ NUEVA ACCIÓN: Activar/Desactivar Mantenimiento del Buscador
    } elseif ($_POST['accion'] === 'activar_mantenimiento_buscador') {
        $stmt = $pdo->prepare("UPDATE sistema_config SET config_value = '1' WHERE config_key = 'buscador_mantenimiento'");
        $stmt->execute();
        $mensaje = "✅ Mantenimiento del Buscador ACTIVADO - Los usuarios verán pantalla de mantenimiento";
    } elseif ($_POST['accion'] === 'desactivar_mantenimiento_buscador') {
        $stmt = $pdo->prepare("UPDATE sistema_config SET config_value = '0' WHERE config_key = 'buscador_mantenimiento'");
        $stmt->execute();
        $mensaje = "✅ Mantenimiento del Buscador DESACTIVADO - Los usuarios pueden usar el buscador";
    
    // ✅ NUEVA ACCIÓN: Activar/Desactivar Ubicación
    } elseif ($_POST['accion'] === 'activar_ubicacion') {
        $stmt = $pdo->prepare("UPDATE sistema_config SET config_value = '1' WHERE config_key = 'ubicacion_activa'");
        $stmt->execute();
        $mensaje = "✅ Geolocalización ACTIVADA - Los usuarios deben estar en el área permitida";
        $ubicacion_activa = '1';
    } elseif ($_POST['accion'] === 'desactivar_ubicacion') {
        $stmt = $pdo->prepare("UPDATE sistema_config SET config_value = '0' WHERE config_key = 'ubicacion_activa'");
        $stmt->execute();
        $mensaje = "✅ Geolocalización DESACTIVADA - Los usuarios pueden acceder desde cualquier lugar";
        $ubicacion_activa = '0';
    }
}

// Obtener estadísticas
$stats = getDashboardStats($pdo);

// Obtener estadísticas del DJ
$stats_dj = getDJStats($pdo);
?>

<?php include 'includes/header.php'; ?>

<div class="container-fluid p-4">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3 mb-0">Dashboard</h1>
            <div class="text-muted small mt-1">
                <i class="fab fa-spotify me-1"></i>
                Spotify Actual: 
                <?php
                try {
                    // Crear tabla si no existe
                    $pdo->exec("CREATE TABLE IF NOT EXISTS spotify_config (
                        config_key VARCHAR(50) PRIMARY KEY,
                        config_value TEXT
                    )");
                    
                    // Obtener datos
                    $stmt = $pdo->query("SELECT config_key, config_value FROM spotify_config WHERE config_key IN ('client_id', 'playlist_id')");
                    $spotify_config = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
                    
                    $client_id = $spotify_config['client_id'] ?? 'No configurado';
                    $playlist_id = $spotify_config['playlist_id'] ?? 'No configurado';
                    
                    // Mostrar solo ID corto y playlist
                    $client_short = strlen($client_id) > 15 ? substr($client_id, 0, 15) . '...' : $client_id;
                    
                    echo '<span class="ms-2">Client ID: <code class="bg-dark px-1 rounded">' . htmlspecialchars($client_short) . '</code></span>';
                    echo '<span class="ms-3">Token: <code class="bg-dark px-1 rounded">' . htmlspecialchars($playlist_id) . '</code></span>';
                    
                } catch (Exception $e) {
                    echo '<span class="text-danger">Error cargando Spotify</span>';
                }
                ?>
            </div>
        </div>
        <div class="text-muted">
            <i class="fas fa-user me-2"></i>
            <?php echo htmlspecialchars($_SESSION['admin_username']); ?>
        </div>
    </div>

    <?php if (isset($mensaje)): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php echo htmlspecialchars($mensaje); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- ============================================
        NUEVO: CONTROL DE GEOLOCALIZACIÓN
    ============================================ -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card border-primary">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">
                        <i class="fas fa-map-marker-alt me-2"></i>Control de Geolocalización
                    </h5>
                </div>
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h6 class="mb-1">Sistema de Verificación por Ubicación</h6>
                            <p class="text-muted mb-0">
                                Cuando está ACTIVADO, los usuarios deben estar dentro del área permitida 
                                (<?php echo $distancia_maxima/1000; ?> km alrededor de La Calita) para acceder al sistema.<br>
                                Cuando está DESACTIVADO, cualquier usuario puede acceder sin verificar ubicación.
                            </p>
                            
                            <!-- Coordenadas actuales -->
                            <div class="mt-3">
                                <small class="text-muted">
                                    <i class="fas fa-crosshairs me-1"></i>
                                    Coordenadas: <?php echo $lat_calita; ?>, <?php echo $lon_calita; ?>
                                    | Radio: <?php echo $distancia_maxima/1000; ?> km
                                </small>
                                <br>
                                <a href="configuracion.php#ubicacion" class="btn btn-sm btn-outline-primary mt-2">
                                    <i class="fas fa-edit me-1"></i>Configurar Coordenadas
                                </a>
                            </div>
                        </div>
                        <div class="col-md-4 text-end">
                            <form method="POST" class="d-inline">
                                <?php if ($ubicacion_activa == '1'): ?>
                                    <input type="hidden" name="accion" value="desactivar_ubicacion">
                                    <button type="submit" class="btn btn-danger btn-lg" 
                                            onclick="return confirm('¿DESACTIVAR verificación de ubicación?\n\nLos usuarios podrán acceder desde cualquier lugar sin verificar su posición.')">
                                        <i class="fas fa-toggle-on me-2"></i>DESACTIVAR UBICACIÓN
                                    </button>
                                    <small class="d-block text-success mt-1">
                                        <i class="fas fa-check-circle me-1"></i>Ubicación ACTIVA - Se requiere estar en La Calita
                                    </small>
                                <?php else: ?>
                                    <input type="hidden" name="accion" value="activar_ubicacion">
                                    <button type="submit" class="btn btn-success btn-lg"
                                            onclick="return confirm('¿ACTIVAR verificación de ubicación?\n\nLos usuarios deberán estar dentro del área permitida (<?php echo $distancia_maxima/1000; ?> km) para acceder.')">
                                        <i class="fas fa-toggle-off me-2"></i>ACTIVAR UBICACIÓN
                                    </button>
                                    <small class="d-block text-danger mt-1">
                                        <i class="fas fa-times-circle me-1"></i>Ubicación INACTIVA - Acceso desde cualquier lugar
                                    </small>
                                <?php endif; ?>
                            </form>
                        </div>
                    </div>
                    
                    <!-- Estado actual -->
                    <div class="row mt-3">
                        <div class="col-12">
                            <div class="alert <?php echo $ubicacion_activa == '1' ? 'alert-success' : 'alert-warning'; ?>">
                                <strong>Estado actual:</strong> 
                                <?php if ($ubicacion_activa == '1'): ?>
                                    ✅ <strong>GEOLOCALIZACIÓN ACTIVA</strong> - Los usuarios deben estar dentro del radio de <strong><?php echo $distancia_maxima/1000; ?> km</strong> de La Calita.
                                    <br><small>Coordenadas: <?php echo $lat_calita; ?>, <?php echo $lon_calita; ?></small>
                                <?php else: ?>
                                    ⚠️ <strong>GEOLOCALIZACIÓN DESACTIVADA</strong> - Los usuarios pueden acceder desde cualquier ubicación sin verificación.
                                    <br><small>No se solicitará permiso de ubicación al entrar</small>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Vista previa del mapa (opcional) -->
                    <?php if ($ubicacion_activa == '1'): ?>
                    <div class="row mt-3">
                        <div class="col-12">
                            <div class="card bg-light">
                                <div class="card-body">
                                    <h6><i class="fas fa-map-marked-alt me-2"></i>Área permitida:</h6>
                                    <div class="ratio ratio-16x9">
                                        <iframe
                                            frameborder="0"
                                            style="border:0; border-radius: 10px;"
                                            src="https://www.google.com/maps/embed/v1/place?key=AIzaSyBFw0Qbyq9zTFTd-tUY6dZWTgaQzuU17R8&q=<?php echo $lat_calita; ?>,<?php echo $lon_calita; ?>&zoom=12"
                                            allowfullscreen>
                                        </iframe>
                                    </div>
                                    <small class="text-muted d-block mt-2">
                                        <i class="fas fa-info-circle me-1"></i>
                                        El mapa muestra la ubicación de La Calita. Los usuarios deben estar en un radio de <?php echo $distancia_maxima/1000; ?> km.
                                    </small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="row g-4">
      
        <!-- Estado del Buscador -->
        <div class="col-md-3">
            <div class="card stat-card <?php echo $buscador_mantenimiento == '1' ? 'border-danger' : 'border-success'; ?>">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="card-title text-muted">Estado Buscador</h6>
                            <h3 class="<?php echo $buscador_mantenimiento == '1' ? 'text-danger' : 'text-success'; ?>">
                                <?php echo $buscador_mantenimiento == '1' ? 'MANT.' : 'ACTIVO'; ?>
                            </h3>
                        </div>
                        <div class="align-self-center">
                            <i class="fas fa-search fa-2x <?php echo $buscador_mantenimiento == '1' ? 'text-danger' : 'text-success'; ?>"></i>
                        </div>
                    </div>
                    <small class="text-muted">
                        <?php echo $buscador_mantenimiento == '1' ? 'En mantenimiento' : 'Funcionando normal'; ?>
                    </small>
                </div>
            </div>
        </div>

        <!-- Usuarios Registrados -->
        <div class="col-md-3">
            <div class="card stat-card border-warning">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="card-title text-muted">Usuarios Registrados</h6>
                            <h3 class="text-warning"><?php echo $stats['total_usuarios']; ?></h3>
                        </div>
                        <div class="align-self-center">
                            <i class="fas fa-users fa-2x text-warning"></i>
                        </div>
                    </div>
                    <small class="text-muted">En base de datos</small>
                </div>
            </div>
        </div>

        <!-- Canciones Solicitadas -->
        <div class="col-md-3">
            <div class="card stat-card border-info">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="card-title text-muted">Total Canciones</h6>
                            <h3 class="text-info"><?php echo $stats['total_canciones']; ?></h3>
                        </div>
                        <div class="align-self-center">
                            <i class="fas fa-music fa-2x text-info"></i>
                        </div>
                    </div>
                    <small class="text-muted">En playlist</small>
                </div>
            </div>
        </div>

        <!-- Canciones Hoy -->
        <div class="col-md-3">
            <div class="card stat-card border-danger">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="card-title text-muted">Canciones Hoy</h6>
                            <h3 class="text-danger"><?php echo $stats['canciones_hoy']; ?></h3>
                        </div>
                        <div class="align-self-center">
                            <i class="fas fa-music fa-2x text-danger"></i>
                        </div>
                    </div>
                    <small class="text-muted">Solicitadas hoy</small>
                </div>
            </div>
        </div>

        <!-- Canciones Pendientes DJ -->
        <div class="col-md-3">
            <div class="card stat-card border-warning">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="card-title text-muted">Pendientes DJ</h6>
                            <h3 class="text-warning"><?php echo $stats_dj['pendientes']; ?></h3>
                        </div>
                        <div class="align-self-center">
                            <i class="fas fa-headphones fa-2x text-warning"></i>
                        </div>
                    </div>
                    <small class="text-muted">En cola del DJ</small>
                </div>
            </div>
        </div>

        <!-- Total Cola DJ -->
        <div class="col-md-3">
            <div class="card stat-card border-secondary">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="card-title text-muted">Total Cola DJ</h6>
                            <h3 class="text-secondary"><?php echo $stats_dj['total_dj']; ?></h3>
                        </div>
                        <div class="align-self-center">
                            <i class="fas fa-list fa-2x text-secondary"></i>
                        </div>
                    </div>
                    <small class="text-muted">Canciones en cola</small>
                </div>
            </div>
        </div>

    </div>
    
    <!-- Configurar Spotify (tarjeta completa) -->
    <div class="row mt-4">
        <div class="col-12">
            <div class="card">
                <div class="card-header bg-success text-white">
                    <h5 class="mb-0">
                        <i class="fab fa-spotify me-2"></i>Configurar Spotify
                    </h5>
                </div>
                <div class="card-body">
                    <?php
                    // Obtener datos actuales
                    try {
                        $stmt = $pdo->query("SELECT config_key, config_value FROM spotify_config");
                        $current_config = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
                    } catch (Exception $e) {
                        $current_config = [];
                    }
                    ?>
                    
                    <form method="POST" action="actualizar_spotify.php">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">
                                    <i class="fas fa-key me-2"></i>
                                    Client ID
                                </label>
                                <input type="text" 
                                       class="form-control" 
                                       name="client_id" 
                                       value="<?php echo htmlspecialchars($current_config['client_id'] ?? 'a2b747acdbab4083b0a89ded7d546a77'); ?>"
                                       placeholder="Client ID"
                                       required>
                                <div class="form-text">
                                    ID de aplicación de Spotify
                                </div>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">
                                    <i class="fas fa-lock me-2"></i>
                                    Client Secret
                                </label>
                                <div class="input-group">
                                    <input type="password" 
                                           class="form-control" 
                                           name="client_secret" 
                                           value="<?php echo htmlspecialchars($current_config['client_secret'] ?? 'c60af17e44c34c258bb08adf6e37e3b7'); ?>"
                                           placeholder="Client Secret"
                                           required>
                                    <button type="button" class="btn btn-outline-secondary" onclick="togglePassword(this)">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                                <div class="form-text">
                                    Secreto de aplicación de Spotify
                                </div>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">
                                    <i class="fas fa-refresh me-2"></i>
                                    Refresh Token
                                </label>
                                <div class="input-group">
                                    <input type="password" 
                                           class="form-control" 
                                           name="refresh_token" 
                                           value="<?php echo htmlspecialchars($current_config['refresh_token'] ?? 'AQBmXX4v5xwhvvUh0zbTQ3cQe3aVXdnWRf5nV_P6fKd3x5K143CQbzkT1paH1__62V_0WpO7_Ztt3tWexC3_-uiKacUL3-qVBwmIhOjLzEOdvAw3NImp-UsCLkUD5lT8jlM'); ?>"
                                           placeholder="Refresh Token"
                                           required>
                                    <button type="button" class="btn btn-outline-secondary" onclick="togglePassword(this)">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                                <div class="form-text">
                                    Token de refresco de Spotify
                                </div>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">
                                    <i class="fas fa-list-music me-2"></i>
                                    Playlist ID
                                </label>
                                <input type="text" 
                                       class="form-control" 
                                       name="playlist_id" 
                                       value="<?php echo htmlspecialchars($current_config['playlist_id'] ?? '4DsQj6WXGKDpmX9oY3bKVz'); ?>"
                                       placeholder="Playlist ID"
                                       required>
                                <div class="form-text">
                                    ID de la playlist de Spotify
                                </div>
                            </div>
                            
                            <div class="col-md-12 mt-3">
                                <div class="d-flex justify-content-end gap-2">
                                    <button type="button" class="btn btn-outline-info" onclick="probarConexionSpotify()">
                                        <i class="fas fa-plug me-1"></i>Probar Conexión
                                    </button>
                                    <button type="button" class="btn btn-outline-warning" onclick="obtenerNuevoToken()">
                                        <i class="fas fa-sync-alt me-1"></i>Obtener Token
                                    </button>
                                    <button type="submit" class="btn btn-success" name="actualizar_spotify">
                                        <i class="fas fa-save me-1"></i>Guardar Configuración
                                    </button>
                                </div>
                            </div>
                        </div>
                    </form>
                    
                    <!-- Resultado de prueba -->
                    <div id="testResult" class="mt-3"></div>
                </div>
            </div>
        </div>
    </div>
                                         
    <!-- ============================================
    SECCIÓN COMENTADA: Control del Sistema de Calificaciones
    ============================================ -->
    <?php /*
    <div class="row mt-4">
        <div class="col-12">
            <div class="card border-info">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-0">
                        <i class="fas fa-star me-2"></i>Control del Sistema de Calificaciones
                    </h5>
                </div>
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h6 class="mb-1">Sistema de Calificación de Servicio</h6>
                            <p class="text-muted mb-0">
                                Activa o desactiva el formulario de calificación para los usuarios.
                                Cuando está desactivado, los usuarios irán directamente al buscador de canciones
                                sin necesidad de calificar el servicio.
                            </p>
                        </div>
                        <div class="col-md-4 text-end">
                            <form method="POST" class="d-inline">
                                <?php if ($calificaciones_activas == '1'): ?>
                                    <input type="hidden" name="accion" value="desactivar_calificaciones">
                                    <button type="submit" class="btn btn-warning btn-lg">
                                        <i class="fas fa-toggle-on me-2"></i>DESACTIVAR CALIFICACIONES
                                    </button>
                                    <small class="d-block text-success mt-1">
                                        <i class="fas fa-check-circle me-1"></i>Sistema ACTIVO - Usuarios califican antes de buscar canciones
                                    </small>
                                <?php else: ?>
                                    <input type="hidden" name="accion" value="activar_calificaciones">
                                    <button type="submit" class="btn btn-success btn-lg">
                                        <i class="fas fa-toggle-off me-2"></i>ACTIVAR CALIFICACIONES
                                    </button>
                                    <small class="d-block text-danger mt-1">
                                        <i class="fas fa-times-circle me-1"></i>Sistema INACTIVO - Usuarios van directo al buscador
                                    </small>
                                <?php endif; ?>
                            </form>
                        </div>
                    </div>
                    
                    <!-- Estado actual -->
                    <div class="row mt-3">
                        <div class="col-12">
                            <div class="alert <?php echo $calificaciones_activas == '1' ? 'alert-success' : 'alert-warning'; ?>">
                                <strong>Estado actual:</strong> 
                                <?php if ($calificaciones_activas == '1'): ?>
                                    ✅ <strong>CALIFICACIONES ACTIVAS</strong> - Los usuarios <strong>DEBEN</strong> calificar el servicio antes de acceder al buscador de canciones.
                                    <br><small>Flujo: Calificación → (Opcional) Buscador de canciones</small>
                                <?php else: ?>
                                    ⚠️ <strong>CALIFICACIONES DESACTIVADAS</strong> - Los usuarios van <strong>DIRECTO</strong> al buscador de canciones sin calificar.
                                    <br><small>Flujo: Directo al Buscador de canciones</small>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Estadísticas cuando está activo -->
                    <?php if ($calificaciones_activas == '1'): ?>
                    <div class="row mt-3">
                        <div class="col-md-3">
                            <div class="card bg-light">
                                <div class="card-body text-center py-3">
                                    <h4 class="text-primary"><?php echo $stats['calificaciones_hoy']; ?></h4>
                                    <small class="text-muted">Calificaciones Hoy</small>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card bg-light">
                                <div class="card-body text-center py-3">
                                    <h4 class="text-success"><?php echo number_format($stats['promedio_calificacion'], 1); ?>/5</h4>
                                    <small class="text-muted">Promedio Calificación</small>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card bg-light">
                                <div class="card-body text-center py-3">
                                    <h4 class="text-info"><?php echo $stats['total_calificaciones']; ?></h4>
                                    <small class="text-muted">Total Calificaciones</small>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card bg-light">
                                <div class="card-body text-center py-3">
                                    <h4 class="text-warning"><?php echo $stats['total_estrellas']; ?></h4>
                                    <small class="text-muted">Estrellas Totales</small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    */ ?>

    <!-- Control del Mantenimiento del Buscador -->
    <div class="row mt-4">
        <div class="col-12">
            <div class="card border-warning">
                <div class="card-header bg-warning text-dark">
                    <h5 class="mb-0">
                        <i class="fas fa-tools me-2"></i>Control del Mantenimiento del Buscador
                    </h5>
                </div>
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h6 class="mb-1">Sistema de Mantenimiento del Buscador</h6>
                            <p class="text-muted mb-0">
                                Activa o desactiva el modo mantenimiento para el buscador de canciones.
                                Cuando está activado, los usuarios verán una pantalla de mantenimiento personalizable
                                en lugar del buscador normal.
                            </p>
                        </div>
                        <div class="col-md-4 text-end">
                            <form method="POST" class="d-inline">
                                <?php if ($buscador_mantenimiento == '1'): ?>
                                    <input type="hidden" name="accion" value="desactivar_mantenimiento_buscador">
                                    <button type="submit" class="btn btn-danger btn-lg">
                                        <i class="fas fa-toggle-on me-2"></i>DESACTIVAR MANTENIMIENTO
                                    </button>
                                    <small class="d-block text-success mt-1">
                                        <i class="fas fa-check-circle me-1"></i>MODO MANTENIMIENTO ACTIVO
                                    </small>
                                <?php else: ?>
                                    <input type="hidden" name="accion" value="activar_mantenimiento_buscador">
                                    <button type="submit" class="btn btn-success btn-lg">
                                        <i class="fas fa-toggle-off me-2"></i>ACTIVAR MANTENIMIENTO
                                    </button>
                                    <small class="d-block text-danger mt-1">
                                        <i class="fas fa-times-circle me-1"></i>MODO MANTENIMIENTO INACTIVO
                                    </small>
                                <?php endif; ?>
                            </form>
                        </div>
                    </div>
                    
                    <!-- Estado actual -->
                    <div class="row mt-3">
                        <div class="col-12">
                            <div class="alert <?php echo $buscador_mantenimiento == '1' ? 'alert-warning' : 'alert-success'; ?>">
                                <strong>Estado actual:</strong> 
                                <?php if ($buscador_mantenimiento == '1'): ?>
                                    ⚠️ <strong>MANTENIMIENTO ACTIVO</strong> - Los usuarios <strong>NO</strong> pueden acceder al buscador de canciones.
                                    <br><small>Ven: Pantalla de mantenimiento personalizada</small>
                                <?php else: ?>
                                    ✅ <strong>BUSCADOR ACTIVO</strong> - Los usuarios <strong>PUEDEN</strong> usar el buscador de canciones normalmente.
                                    <br><small>Ven: Buscador de canciones completo</small>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Información adicional -->
                    <div class="row mt-3">
                        <div class="col-12">
                            <div class="alert alert-info">
                                <h6><i class="fas fa-info-circle me-2"></i>Información importante:</h6>
                                <ul class="mb-0">
                                    <li>El mantenimiento del buscador es independiente del "Sistema de canciones"</li>
                                    <li>Puedes personalizar completamente la pantalla de mantenimiento en Configuración</li>
                                    <li>Los cambios se aplican inmediatamente a todos los usuarios</li>
                                    <li>Útil para mantenimiento programado, actualizaciones o eventos especiales</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Acciones rápidas -->
                    <div class="row mt-3">
                        <div class="col-md-6">
                            <a href="configuracion.php" class="btn btn-outline-primary w-100 py-3">
                                <i class="fas fa-cog me-2"></i>Personalizar Pantalla
                            </a>
                        </div>
                        <div class="col-md-6">
                            <a href="../buscador.php" target="_blank" class="btn btn-outline-success w-100 py-3">
                                <i class="fas fa-eye me-2"></i>Ver como Usuario
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Control del Modo DJ -->
    <div class="row mt-4">
        <div class="col-12">
            <div class="card border-warning">
                <div class="card-header bg-warning text-dark">
                    <h5 class="mb-0">
                        <i class="fas fa-headphones me-2"></i>Control del Modo DJ
                    </h5>
                </div>
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h6 class="mb-1">Sistema de Cola DJ</h6>
                            <p class="text-muted mb-0">
                                Cuando el modo DJ está activo, las canciones solicitadas por usuarios 
                                se guardan en la cola del DJ en lugar de agregarse directamente al playlist.
                                El DJ puede revisar y gestionar las solicitudes desde su panel.
                            </p>
                        </div>
                        <div class="col-md-4 text-end">
                            <form method="POST" class="d-inline">
                                <?php if ($dj_activo == '1'): ?>
                                    <input type="hidden" name="accion" value="desactivar_dj">
                                    <button type="submit" class="btn btn-danger btn-lg">
                                        <i class="fas fa-toggle-on me-2"></i>DESACTIVAR MODO DJ
                                    </button>
                                    <small class="d-block text-success mt-1">
                                        <i class="fas fa-check-circle me-1"></i>MODO DJ ACTIVO
                                    </small>
                                <?php else: ?>
                                    <input type="hidden" name="accion" value="activar_dj">
                                    <button type="submit" class="btn btn-success btn-lg">
                                        <i class="fas fa-toggle-off me-2"></i>ACTIVAR MODO DJ
                                    </button>
                                    <small class="d-block text-danger mt-1">
                                        <i class="fas fa-times-circle me-1"></i>MODO DJ INACTIVO
                                    </small>
                                <?php endif; ?>
                            </form>
                        </div>
                    </div>
                    
                    <!-- Estadísticas DJ -->
                    <?php if ($dj_activo == '1'): ?>
                    <div class="row mt-3">
                        <div class="col-md-3">
                            <div class="card bg-light">
                                <div class="card-body text-center py-3">
                                    <h4 class="text-warning"><?php echo $stats_dj['pendientes']; ?></h4>
                                    <small class="text-muted">Canciones Pendientes</small>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card bg-light">
                                <div class="card-body text-center py-3">
                                    <h4 class="text-success"><?php echo $stats_dj['reproducidas']; ?></h4>
                                    <small class="text-muted">Reproducidas Hoy</small>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card bg-light">
                                <div class="card-body text-center py-3">
                                    <h4 class="text-info"><?php echo $stats_dj['total_hoy']; ?></h4>
                                    <small class="text-muted">Solicitudes Hoy</small>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card bg-light">
                                <div class="card-body text-center py-3">
                                    <h4 class="text-primary"><?php echo $stats_dj['total_dj']; ?></h4>
                                    <small class="text-muted">Total en Cola DJ</small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Borrar Lista DJ -->
    <div class="row mt-4">
        <div class="col-12">
            <div class="card border-danger">
                <div class="card-header bg-danger text-white">
                    <h5 class="mb-0">
                        <i class="fas fa-trash me-2"></i>Gestión de Lista DJ
                    </h5>
                </div>
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h6 class="mb-1">Borrar Lista Completa del DJ</h6>
                            <p class="text-muted mb-0">
                                Esta acción eliminará <strong>TODAS las canciones pendientes</strong> de la cola del DJ. 
                                <br><strong class="text-danger">⚠️ Esta acción no se puede deshacer.</strong>
                            </p>
                            <div class="mt-2">
                                <span class="badge bg-warning text-dark">
                                    <i class="fas fa-music me-1"></i>
                                    Canciones pendientes: <?php echo $stats_dj['pendientes']; ?>
                                </span>
                                <span class="badge bg-secondary ms-2">
                                    <i class="fas fa-list me-1"></i>
                                    Total en cola: <?php echo $stats_dj['total_dj']; ?>
                                </span>
                            </div>
                        </div>
                        <div class="col-md-4 text-end">
                            <form method="POST" onsubmit="return confirmBorrarListaDJ()">
                                <input type="hidden" name="accion" value="borrar_lista_dj">
                                <button type="submit" class="btn btn-danger btn-lg" 
                                        <?php echo $stats_dj['total_dj'] == 0 ? 'disabled' : ''; ?>>
                                    <i class="fas fa-trash-alt me-2"></i>
                                    BORRAR LISTA DJ
                                </button>
                                <?php if ($stats_dj['total_dj'] == 0): ?>
                                    <small class="d-block text-muted mt-1">
                                        <i class="fas fa-info-circle me-1"></i>La lista del DJ ya está vacía
                                    </small>
                                <?php else: ?>
                                    <small class="d-block text-danger mt-1">
                                        <i class="fas fa-exclamation-triangle me-1"></i>
                                        Eliminará <?php echo $stats_dj['total_dj']; ?> canción(es)
                                    </small>
                                <?php endif; ?>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ============================================
    SECCIÓN COMENTADA: Control del Sistema de Canciones
    ============================================ -->
    <?php /*
    <div class="row mt-4">
        <div class="col-12">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">
                        <i class="fas fa-cog me-2"></i>Control del Sistema de Canciones
                    </h5>
                </div>
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h6 class="mb-1">Sistema de Búsqueda de Canciones</h6>
                            <p class="text-muted mb-0">
                                Activa o desactiva todo el sistema de búsqueda y solicitud de canciones para los usuarios.
                                Cuando está desactivado, los usuarios verán un mensaje de mantenimiento.
                            </p>
                        </div>
                        <div class="col-md-4 text-end">
                            <form method="POST" class="d-inline">
                                <?php if ($canciones_activas == '1'): ?>
                                    <input type="hidden" name="accion" value="desactivar_canciones">
                                    <button type="submit" class="btn btn-danger btn-lg">
                                        <i class="fas fa-toggle-on me-2"></i>DESACTIVAR CANCIONES
                                    </button>
                                    <small class="d-block text-success mt-1">
                                        <i class="fas fa-check-circle me-1"></i>Sistema ACTIVO - Usuarios pueden buscar canciones
                                    </small>
                                <?php else: ?>
                                    <input type="hidden" name="accion" value="activar_canciones">
                                    <button type="submit" class="btn btn-success btn-lg">
                                        <i class="fas fa-toggle-off me-2"></i>ACTIVAR CANCIONES
                                    </button>
                                    <small class="d-block text-danger mt-1">
                                        <i class="fas fa-times-circle me-1"></i>Sistema INACTIVO - Usuarios ven mensaje de mantenimiento
                                    </small>
                                <?php endif; ?>
                            </form>
                        </div>
                    </div>
                    
                    <!-- Estado actual -->
                    <div class="row mt-3">
                        <div class="col-12">
                            <div class="alert <?php echo $canciones_activas == '1' ? 'alert-success' : 'alert-danger'; ?>">
                                <strong>Estado actual:</strong> 
                                <?php if ($canciones_activas == '1'): ?>
                                    ✅ <strong>SISTEMA ACTIVO</strong> - Los usuarios pueden buscar y solicitar canciones normalmente desde el formulario de calificación.
                                <?php else: ?>
                                    ❌ <strong>SISTEMA DESACTIVADO</strong> - Los usuarios verán un mensaje de mantenimiento cuando intenten acceder al buscador de canciones.
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Diferencia con Mantenimiento del Buscador -->
                    <div class="row mt-3">
                        <div class="col-12">
                            <div class="alert alert-secondary">
                                <h6><i class="fas fa-info-circle me-2"></i>Nota importante:</h6>
                                <p class="mb-0">
                                    <strong>Este control es diferente al "Mantenimiento del Buscador".</strong><br>
                                    • <strong>Sistema de Canciones:</strong> Controla TODO el sistema de búsqueda de canciones<br>
                                    • <strong>Mantenimiento del Buscador:</strong> Solo controla si se muestra el buscador o una pantalla de mantenimiento
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    */ ?>

    <!-- Acciones Rápidas -->
    <div class="row mt-4">
        <div class="col-12">
            <div class="card">
                <div class="card-header bg-dark text-white">
                    <h5 class="mb-0">Acciones Rápidas</h5>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <!-- Botón de Usuarios Registrados -->
                        <div class="col-md-3">
                            <a href="usuarios.php" class="btn btn-success w-100 py-3">
                                <i class="fas fa-users me-2"></i>Usuarios Registrados
                            </a>
                        </div>
                        
                        <!-- Botón de Ver Canciones -->
                        <div class="col-md-3">
                            <a href="canciones.php" class="btn btn-info w-100 py-3">
                                <i class="fas fa-music me-2"></i>Ver Canciones
                            </a>
                        </div>
                        
                        <!-- Botón de Cola DJ -->
                        <div class="col-md-3">
                            <a href="dj_canciones.php" class="btn btn-warning w-100 py-3">
                                <i class="fas fa-headphones me-2"></i>Cola DJ
                            </a>
                        </div>
                        
                        <!-- Botón de Configuración -->
                        <div class="col-md-3">
                            <a href="configuracion.php" class="btn btn-primary w-100 py-3">
                                <i class="fas fa-cogs me-2"></i>Configuración
                            </a>
                        </div>
                    </div>
                    
                    <div class="row g-3 mt-2">
                        <!-- SOLO ADMIN VE ESTOS BOTONES -->
                        <?php if (esAdministrador()): ?>
                            <div class="col-md-4">
                                <a href="agregar_cancion.php" class="btn btn-outline-primary w-100 py-3">
                                    <i class="fas fa-plus-circle me-2"></i>Agregar Canción
                                </a>
                            </div>
                            <div class="col-md-4">
                                <a href="gestion_usuarios.php" class="btn btn-outline-info w-100 py-3">
                                    <i class="fas fa-users-cog me-2"></i>Usuarios Sistema
                                </a>
                            </div>
                        <?php endif; ?>
                        
                        <!-- Este botón lo ven todos -->
                        <div class="col-md-<?php echo esAdministrador() ? '4' : '6'; ?>">
                            <a href="logout.php" class="btn btn-outline-danger w-100 py-3">
                                <i class="fas fa-sign-out-alt me-2"></i>Cerrar Sesión
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<script>
// ============================================
// FUNCIONES PARA LA SECCIÓN DE SPOTIFY
// ============================================

function copiarAlPortapapeles(elementId) {
    const element = document.getElementById(elementId);
    const textToCopy = element.value;
    
    // Crear input temporal
    const tempInput = document.createElement('input');
    tempInput.value = textToCopy;
    document.body.appendChild(tempInput);
    tempInput.select();
    document.execCommand('copy');
    document.body.removeChild(tempInput);
    
    // Mostrar notificación
    mostrarToast('Copiado al portapapeles', 'success');
}

function togglePassword(btn) {
    const input = btn.parentElement.querySelector('input');
    const icon = btn.querySelector('i');
    
    if (input.type === 'password') {
        input.type = 'text';
        icon.className = 'fas fa-eye-slash';
    } else {
        input.type = 'password';
        icon.className = 'fas fa-eye';
    }
}

function probarConexionSpotify() {
    const btn = event.target;
    const originalText = btn.innerHTML;
    
    btn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Probando...';
    btn.disabled = true;
    
    fetch('probar_spotify.php')
        .then(response => response.json())
        .then(data => {
            const resultDiv = document.getElementById('testResult');
            if (data.success) {
                resultDiv.innerHTML = `
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle me-2"></i>
                        <strong>✅ Conexión exitosa</strong>
                        <p class="mb-0 mt-1">${data.message}</p>
                        <small class="d-block mt-2">
                            Token: ${data.access_token}<br>
                            Expira en: ${data.expires_in} segundos
                        </small>
                    </div>
                `;
            } else {
                resultDiv.innerHTML = `
                    <div class="alert alert-danger">
                        <i class="fas fa-times-circle me-2"></i>
                        <strong>❌ Error de conexión</strong>
                        <p class="mb-0 mt-1">${data.message}</p>
                        ${data.http_code ? `<small>Código HTTP: ${data.http_code}</small>` : ''}
                    </div>
                `;
            }
        })
        .catch(error => {
            document.getElementById('testResult').innerHTML = `
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    <strong>Error en la solicitud</strong>
                    <p class="mb-0 mt-1">${error}</p>
                </div>
            `;
        })
        .finally(() => {
            btn.innerHTML = originalText;
            btn.disabled = false;
        });
}

function obtenerNuevoToken() {
    window.open('obtener_token.php', '_blank');
}

function mostrarToast(mensaje, tipo = 'success') {
    // Crear toast dinámico
    const toastContainer = document.createElement('div');
    toastContainer.className = 'position-fixed bottom-0 end-0 p-3';
    toastContainer.style.zIndex = '11';
    
    const toastHTML = `
        <div id="liveToast" class="toast align-items-center text-white bg-${tipo} border-0" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
                <div class="toast-body">
                    ${mensaje}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        </div>
    `;
    
    toastContainer.innerHTML = toastHTML;
    document.body.appendChild(toastContainer);
    
    const toast = new bootstrap.Toast(toastContainer.querySelector('.toast'));
    toast.show();
    
    // Remover después de 3 segundos
    setTimeout(() => {
        toastContainer.remove();
    }, 3000);
}

// Validar formulario antes de enviar
document.querySelector('form[action="actualizar_spotify.php"]')?.addEventListener('submit', function(e) {
    const clientId = this.elements['client_id'].value;
    const clientSecret = this.elements['client_secret'].value;
    const refreshToken = this.elements['refresh_token'].value;
    
    if (!clientId || !clientSecret || !refreshToken) {
        e.preventDefault();
        mostrarToast('Por favor completa todos los campos requeridos', 'danger');
        return false;
    }
    
    const confirmacion = confirm(
        '¿Estás seguro de actualizar las credenciales de Spotify?\n\n' +
        '⚠️ Esto afectará a todos los usuarios del sistema.\n' +
        '✅ Asegúrate de que las nuevas credenciales sean válidas.'
    );
    
    if (!confirmacion) {
        e.preventDefault();
        return false;
    }
    
    return true;
});

// ============================================
// FUNCIONES PARA EL CONTROL DEL SISTEMA
// ============================================

function confirmBorrarListaDJ() {
    const totalCanciones = <?php echo $stats_dj['total_dj']; ?>;
    const pendientes = <?php echo $stats_dj['pendientes']; ?>;
    
    if (totalCanciones === 0) {
        alert('La lista del DJ ya está vacía.');
        return false;
    }
    
    const confirmacion = confirm(
        `¿ESTÁS ABSOLUTAMENTE SEGURO?\n\n` +
        `Esta acción eliminará TODAS las canciones de la cola del DJ:\n\n` +
        `🎵 Canciones pendientes: ${pendientes}\n` +
        `📋 Total en cola: ${totalCanciones}\n\n` +
        `⚠️ ESTA ACCIÓN NO SE PUEDE DESHACER\n` +
        `¿Continuar?`
    );
    
    return confirmacion;
}

function confirmAccionSistema(accion, mensaje) {
    return confirm(`¿Estás seguro de ${mensaje}?\n\nEsta acción afectará a todos los usuarios inmediatamente.`);
}

// Confirmaciones para acciones rápidas
document.querySelectorAll('form[method="POST"] button[type="submit"]').forEach(button => {
    button.addEventListener('click', function(e) {
        const form = this.closest('form');
        const accion = form.querySelector('input[name="accion"]')?.value;
        
        if (!accion) return;
        
        let mensajeConfirmacion = '';
        
        switch(accion) {
            case 'activar_mantenimiento_buscador':
                mensajeConfirmacion = 'activar el modo mantenimiento del buscador';
                break;
            case 'desactivar_mantenimiento_buscador':
                mensajeConfirmacion = 'desactivar el modo mantenimiento del buscador';
                break;
            case 'activar_dj':
                mensajeConfirmacion = 'activar el modo DJ';
                break;
            case 'desactivar_dj':
                mensajeConfirmacion = 'desactivar el modo DJ';
                break;
            case 'activar_canciones':
                mensajeConfirmacion = 'activar el sistema de canciones';
                break;
            case 'desactivar_canciones':
                mensajeConfirmacion = 'desactivar el sistema de canciones';
                break;
            case 'activar_ubicacion':
                mensajeConfirmacion = 'activar la verificación de ubicación';
                break;
            case 'desactivar_ubicacion':
                mensajeConfirmacion = 'desactivar la verificación de ubicación';
                break;
        }
        
        if (mensajeConfirmacion && !confirmAccionSistema(accion, mensajeConfirmacion)) {
            e.preventDefault();
        }
    });
});

// ============================================
// FUNCIONES DE INTERFAZ
// ============================================

// Actualizar hora actual
function actualizarHora() {
    const ahora = new Date();
    const horaString = ahora.toLocaleTimeString('es-MX', { 
        hour: '2-digit', 
        minute: '2-digit',
        second: '2-digit'
    });
    const fechaString = ahora.toLocaleDateString('es-MX', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
    
    const elementoHora = document.getElementById('horaActual');
    if (elementoHora) {
        elementoHora.innerHTML = `<i class="fas fa-clock me-1"></i> ${fechaString} - ${horaString}`;
    }
}

// Inicializar actualización de hora
setInterval(actualizarHora, 1000);
actualizarHora();

// Mostrar notificación de estado del sistema
function mostrarEstadoSistema() {
    const estadoBuscador = <?php echo $buscador_mantenimiento == '1' ? "'Mantenimiento'" : "'Normal'"; ?>;
    const estadoCanciones = <?php echo $canciones_activas == '1' ? "'Activo'" : "'Inactivo'"; ?>;
    const estadoDJ = <?php echo $dj_activo == '1' ? "'Activo'" : "'Inactivo'"; ?>;
    const estadoUbicacion = <?php echo $ubicacion_activa == '1' ? "'Activa'" : "'Inactiva'"; ?>;
    
    console.log('Estado del sistema:');
    console.log('- Buscador:', estadoBuscador);
    console.log('- Sistema de canciones:', estadoCanciones);
    console.log('- Modo DJ:', estadoDJ);
    console.log('- Geolocalización:', estadoUbicacion);
}

// Ejecutar al cargar
document.addEventListener('DOMContentLoaded', function() {
    mostrarEstadoSistema();
    
    // Agregar clases de animación a las tarjetas
    document.querySelectorAll('.stat-card').forEach((card, index) => {
        card.style.animationDelay = `${index * 0.1}s`;
        card.classList.add('animate__animated', 'animate__fadeInUp');
    });
    
    // Tooltips para botones
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});

// Función para recargar estadísticas
function recargarEstadisticas() {
    const btnRecargar = document.getElementById('btnRecargar');
    if (btnRecargar) {
        btnRecargar.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Actualizando...';
        btnRecargar.disabled = true;
    }
    
    // Simular recarga
    setTimeout(() => {
        location.reload();
    }, 1000);
}

// Agregar botón de recarga si no existe
if (!document.getElementById('btnRecargar')) {
    const header = document.querySelector('.d-flex.justify-content-between.align-items-center.mb-4');
    if (header) {
        const btnRecargar = document.createElement('button');
        btnRecargar.id = 'btnRecargar';
        btnRecargar.className = 'btn btn-sm btn-outline-info ms-2';
        btnRecargar.innerHTML = '<i class="fas fa-sync-alt me-1"></i>';
        btnRecargar.title = 'Actualizar estadísticas';
        btnRecargar.onclick = recargarEstadisticas;
        
        const divUsuario = header.querySelector('.text-muted');
        if (divUsuario) {
            divUsuario.appendChild(btnRecargar);
        }
    }
}
</script>

<style>
/* Estilos adicionales para el dashboard */
.stat-card {
    transition: all 0.3s ease;
    border-width: 2px !important;
}

.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.1);
}

.card-header {
    font-weight: 600;
}

.alert {
    border-radius: 10px;
    border-width: 2px;
}

.btn-lg {
    font-weight: 600;
    letter-spacing: 0.5px;
}

/* Animaciones */
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.animate__fadeInUp {
    animation-name: fadeInUp;
    animation-duration: 0.5s;
    animation-fill-mode: both;
}

/* Estilos para formulario de Spotify */
.form-text {
    font-size: 0.85rem;
    color: #6c757d;
}

.input-group .btn-outline-secondary {
    border-color: #dee2e6;
}

.input-group .btn-outline-secondary:hover {
    background-color: #e9ecef;
    border-color: #dee2e6;
}

/* Estilo para tarjeta de Spotify */
#spotifyCard {
    border-left: 5px solid #1DB954;
}

/* Responsive */
@media (max-width: 768px) {
    .btn-lg {
        padding: 10px 20px;
        font-size: 14px;
    }
    
    .card-header h5 {
        font-size: 18px;
    }
    
    .stat-card h3 {
        font-size: 24px;
    }
    
    .d-flex.justify-content-end.gap-2 {
        flex-direction: column;
        gap: 10px !important;
    }
    
    .d-flex.justify-content-end.gap-2 button {
        width: 100%;
    }
}
</style>

</div>
</body>
</html>