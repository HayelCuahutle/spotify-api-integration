<?php
require_once 'config/database.php';
require_once 'includes/functions.php';
checkAdminAuth();

// Solo administradores pueden acceder
if (!esAdministrador()) {
    header('Location: dashboard.php');
    exit;
}

$mensaje = '';
$tipo_mensaje = '';

// ============================================
// CONFIGURACIÓN DE MANTENIMIENTO DEL BUSCADOR
// ============================================

// Procesar actualización de configuración de mantenimiento
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['actualizar_mantenimiento'])) {
    try {
        $buscador_mantenimiento = isset($_POST['buscador_mantenimiento']) ? '1' : '0';
        $mantenimiento_titulo = trim($_POST['mantenimiento_titulo']);
        $mantenimiento_mensaje = trim($_POST['mantenimiento_mensaje']);
        $mantenimiento_boton_texto = trim($_POST['mantenimiento_boton_texto']);
        $mantenimiento_boton_url = trim($_POST['mantenimiento_boton_url']);
        
        // Validaciones básicas
        if (empty($mantenimiento_titulo)) {
            throw new Exception("El título no puede estar vacío");
        }
        
        if (empty($mantenimiento_mensaje)) {
            throw new Exception("El mensaje no puede estar vacío");
        }
        
        if (empty($mantenimiento_boton_texto)) {
            throw new Exception("El texto del botón no puede estar vacío");
        }
        
        if (empty($mantenimiento_boton_url)) {
            $mantenimiento_boton_url = '../';
        }
        
        // Actualizar configuraciones
        $configs = [
            'buscador_mantenimiento' => $buscador_mantenimiento,
            'mantenimiento_titulo' => $mantenimiento_titulo,
            'mantenimiento_mensaje' => $mantenimiento_mensaje,
            'mantenimiento_boton_texto' => $mantenimiento_boton_texto,
            'mantenimiento_boton_url' => $mantenimiento_boton_url
        ];
        
        foreach ($configs as $key => $value) {
            $stmt = $pdo->prepare("
                INSERT INTO sistema_config (config_key, config_value) 
                VALUES (?, ?) 
                ON DUPLICATE KEY UPDATE config_value = ?
            ");
            $stmt->execute([$key, $value, $value]);
        }
        
        $_SESSION['mensaje_mantenimiento'] = "✅ Configuración de mantenimiento actualizada correctamente";
        $_SESSION['tipo_mensaje_mantenimiento'] = "success";
        
        // Redirigir para evitar reenvío del formulario
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
        
    } catch (Exception $e) {
        $_SESSION['mensaje_mantenimiento'] = "❌ Error: " . $e->getMessage();
        $_SESSION['tipo_mensaje_mantenimiento'] = "danger";
    }
}

// Obtener configuración actual de mantenimiento
$config_mantenimiento = [];
try {
    $stmt = $pdo->prepare("
        SELECT config_key, config_value 
        FROM sistema_config 
        WHERE config_key IN ('buscador_mantenimiento', 'mantenimiento_titulo', 'mantenimiento_mensaje', 'mantenimiento_boton_texto', 'mantenimiento_boton_url')
    ");
    $stmt->execute();
    $config_mantenimiento = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
} catch (Exception $e) {
    error_log("Error obteniendo configuración de mantenimiento: " . $e->getMessage());
}

// Valores por defecto
$buscador_mantenimiento = $config_mantenimiento['buscador_mantenimiento'] ?? '0';
$mantenimiento_titulo = $config_mantenimiento['mantenimiento_titulo'] ?? '🚧 Sistema en Mantenimiento';
$mantenimiento_mensaje = $config_mantenimiento['mantenimiento_mensaje'] ?? 'El buscador de canciones se encuentra temporalmente desactivado para mantenimiento y mejoras.';
$mantenimiento_boton_texto = $config_mantenimiento['mantenimiento_boton_texto'] ?? 'Volver al Inicio';
$mantenimiento_boton_url = $config_mantenimiento['mantenimiento_boton_url'] ?? '../';

// Mostrar mensajes de mantenimiento si existen
if (isset($_SESSION['mensaje_mantenimiento'])) {
    $mensaje_mantenimiento = $_SESSION['mensaje_mantenimiento'];
    $tipo_mensaje_mantenimiento = $_SESSION['tipo_mensaje_mantenimiento'];
    unset($_SESSION['mensaje_mantenimiento']);
    unset($_SESSION['tipo_mensaje_mantenimiento']);
}

// ============================================
// CONFIGURACIÓN GENERAL DEL SISTEMA
// ============================================

// Obtener configuración actual
$configuraciones = obtenerConfiguraciones($pdo);

// Valores por defecto para geolocalización
$lat_calita = $configuraciones['lat_calita'] ?? '19.2062478';
$lon_calita = $configuraciones['lon_calita'] ?? '-98.2332175';
$distancia_maxima = $configuraciones['distancia_maxima'] ?? '20000';

// Procesar actualización de configuración general
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['actualizar_config'])) {
    try {
        $minutos_limite = (int)$_POST['minutos_limite'];
        $spotify_activo = isset($_POST['spotify_activo']) ? '1' : '0';
        $dj_activo = isset($_POST['dj_activo']) ? '1' : '0';
        $canciones_activas = isset($_POST['canciones_activas']) ? '1' : '0';
        
        // Validaciones de tiempos
        if ($minutos_limite < 0 || $minutos_limite > 60) {
            throw new Exception("El límite de minutos debe estar entre 0 y 60 (1 hora máximo). 0 = Sin límite");
        }
        
        // Validaciones de geolocalización
        $lat_calita = trim($_POST['lat_calita']);
        $lon_calita = trim($_POST['lon_calita']);
        $distancia_maxima = (int)$_POST['distancia_maxima'];
        
        // Validar formato de latitud (-90 a 90)
        if (!is_numeric($lat_calita) || $lat_calita < -90 || $lat_calita > 90) {
            throw new Exception("La latitud debe ser un número entre -90 y 90");
        }
        
        // Validar formato de longitud (-180 a 180)
        if (!is_numeric($lon_calita) || $lon_calita < -180 || $lon_calita > 180) {
            throw new Exception("La longitud debe ser un número entre -180 y 180");
        }
        
        // Validar distancia (100m a 50km)
        if ($distancia_maxima < 100 || $distancia_maxima > 50000) {
            throw new Exception("La distancia máxima debe estar entre 100 y 50000 metros");
        }
        
        // Actualizar cada configuración
        $configs = [
            'minutos_limite' => $minutos_limite,
            'spotify_activo' => $spotify_activo,
            'lat_calita' => $lat_calita,
            'lon_calita' => $lon_calita,
            'distancia_maxima' => $distancia_maxima,
            'dj_activo' => $dj_activo,
            'canciones_activas' => $canciones_activas
        ];
        
        foreach ($configs as $key => $value) {
            $stmt = $pdo->prepare("
                INSERT INTO sistema_config (config_key, config_value) 
                VALUES (?, ?) 
                ON DUPLICATE KEY UPDATE config_value = ?
            ");
            $stmt->execute([$key, $value, $value]);
        }
        
        $mensaje = "✅ Configuración actualizada correctamente";
        $tipo_mensaje = "success";
        
        // Registrar log
        registrarLog('actualizar_configuracion', 
            "minutos_limite: {$minutos_limite}, lat: {$lat_calita}, lon: {$lon_calita}");
        
        // Actualizar array de configuraciones
        $configuraciones = array_merge($configuraciones, $configs);
        
    } catch (Exception $e) {
        $mensaje = "❌ Error: " . $e->getMessage();
        $tipo_mensaje = "danger";
    }
}
?>

<?php include 'includes/header.php'; ?>

<div class="container-fluid p-4">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0">
            <i class="fas fa-cogs me-2"></i>Configuración del Sistema
        </h1>
        <div class="text-muted">
            Solo administradores
        </div>
    </div>

    <?php if ($mensaje): ?>
        <div class="alert alert-<?php echo $tipo_mensaje; ?> alert-dismissible fade show">
            <?php echo htmlspecialchars($mensaje); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- ============================================
    SECCIÓN DE CONFIGURACIÓN DE MANTENIMIENTO DEL BUSCADOR
    ============================================ -->
    <div class="row mt-4">
        <div class="col-12">
            <div class="card border-warning">
                <div class="card-header bg-warning text-dark">
                    <h5 class="mb-0">
                        <i class="fas fa-tools me-2"></i>Configuración de Mantenimiento del Buscador
                    </h5>
                </div>
                <div class="card-body">
                    
                    <?php if (isset($mensaje_mantenimiento)): ?>
                        <div class="alert alert-<?php echo $tipo_mensaje_mantenimiento; ?> alert-dismissible fade show mb-4">
                            <?php echo htmlspecialchars($mensaje_mantenimiento); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    
                    <div class="row">
                        <div class="col-md-8">
                            <p class="text-muted mb-3">
                                Configura la pantalla de mantenimiento que verán los usuarios cuando intenten acceder al buscador.
                                Cuando está activado, los usuarios verán un mensaje personalizado en lugar del buscador normal.
                            </p>
                            
                            <div class="alert alert-info">
                                <strong><i class="fas fa-info-circle me-2"></i>Estado actual:</strong>
                                <?php if ($buscador_mantenimiento == '1'): ?>
                                    <span class="badge bg-danger ms-2">MANTENIMIENTO ACTIVO</span> - Los usuarios ven la pantalla de mantenimiento
                                <?php else: ?>
                                    <span class="badge bg-success ms-2">NORMAL</span> - Los usuarios pueden usar el buscador normalmente
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <hr class="my-4">
                    
                    <!-- Formulario de personalización -->
                    <form method="POST" id="mantenimientoForm">
                        <div class="row">
                            <div class="col-md-12 mb-3">
                                <label class="form-label fw-bold">
                                    <i class="fas fa-heading me-2"></i>
                                    Título de la pantalla
                                </label>
                                <input type="text" 
                                       name="mantenimiento_titulo" 
                                       class="form-control form-control-lg"
                                       value="<?php echo htmlspecialchars($mantenimiento_titulo); ?>"
                                       placeholder="Ej: 🚧 Sistema en Mantenimiento"
                                       required>
                                <div class="form-text">
                                    Título principal que verán los usuarios
                                </div>
                            </div>
                            
                            <div class="col-md-12 mb-3">
                                <label class="form-label fw-bold">
                                    <i class="fas fa-comment-alt me-2"></i>
                                    Mensaje de mantenimiento
                                </label>
                                <textarea 
                                    name="mantenimiento_mensaje" 
                                    class="form-control" 
                                    rows="4"
                                    placeholder="Describe el motivo del mantenimiento, tiempo estimado, etc."
                                    required><?php echo htmlspecialchars($mantenimiento_mensaje); ?></textarea>
                                <div class="form-text">
                                    Mensaje detallado para los usuarios. Puedes usar saltos de línea.
                                </div>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">
                                    <i class="fas fa-button me-2"></i>
                                    Texto del botón principal
                                </label>
                                <input type="text" 
                                       name="mantenimiento_boton_texto" 
                                       class="form-control"
                                       value="<?php echo htmlspecialchars($mantenimiento_boton_texto); ?>"
                                       placeholder="Ej: Volver al Inicio"
                                       required>
                                <div class="form-text">
                                    Texto que aparecerá en el botón principal
                                </div>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">
                                    <i class="fas fa-link me-2"></i>
                                    URL del botón principal
                                </label>
                                <input type="text" 
                                       name="mantenimiento_boton_url" 
                                       class="form-control"
                                       value="<?php echo htmlspecialchars($mantenimiento_boton_url); ?>"
                                       placeholder="Ej: ../ o https://tusitio.com"
                                       required>
                                <div class="form-text">
                                    Enlace al que llevará el botón (página de inicio, contacto, etc.)
                                </div>
                            </div>
                            
                            <div class="col-md-12 mb-4">
                                <div class="alert alert-secondary">
                                    <h6><i class="fas fa-eye me-2"></i>Vista previa:</h6>
                                    <div class="mt-2 p-3 bg-light rounded">
                                        <h5 class="text-warning preview-title"><?php echo htmlspecialchars($mantenimiento_titulo); ?></h5>
                                        <p class="mb-2 preview-message"><?php echo nl2br(htmlspecialchars(substr($mantenimiento_mensaje, 0, 150) . '...')); ?></p>
                                        <a href="<?php echo htmlspecialchars($mantenimiento_boton_url); ?>" class="btn btn-primary btn-sm preview-button">
                                            <i class="fas fa-home me-1"></i><?php echo htmlspecialchars($mantenimiento_boton_texto); ?>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-12">
                                <div class="d-grid gap-2">
                                    <button type="submit" name="actualizar_mantenimiento" class="btn btn-warning btn-lg py-3">
                                        <i class="fas fa-save me-2"></i>Guardar Configuración de Mantenimiento
                                    </button>
                                </div>
                            </div>
                        </div>
                    </form>
                    
                    <!-- Información adicional -->
                    <div class="row mt-4">
                        <div class="col-12">
                            <div class="alert alert-success">
                                <h6><i class="fas fa-lightbulb me-2"></i>Consejos para el mensaje de mantenimiento:</h6>
                                <ul class="mb-0">
                                    <li>Explica claramente el motivo del mantenimiento</li>
                                    <li>Indica un tiempo estimado de duración si es posible</li>
                                    <li>Proporciona alternativas de contacto o información</li>
                                    <li>Mantén un tono amigable y profesional</li>
                                    <li>Incluye información de contacto para emergencias</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>

    <!-- ============================================
    CONFIGURACIÓN GENERAL DEL SISTEMA
    ============================================ -->
    <div class="row mt-4">
        <div class="col-lg-8">
            <!-- Formulario de Configuración General -->
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">
                        <i class="fas fa-sliders-h me-2"></i>Configuración Principal
                    </h5>
                </div>
                <div class="card-body">
                    <form method="POST" id="configForm">
                        <!-- Configuración de Geolocalización -->
                        <div class="mb-4">
                            <h6 class="border-bottom pb-2 mb-3">
                                <i class="fas fa-map-marker-alt me-2 text-danger"></i>
                                Configuración de Geolocalización
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">
                                            <i class="fas fa-latitude me-2"></i>
                                            Latitud
                                        </label>
                                        <input type="text" name="lat_calita" 
                                               class="form-control"
                                               value="<?php echo htmlspecialchars($lat_calita); ?>"
                                               required>
                                        <div class="form-text">
                                            Latitud de la ubicación permitida (ej: 19.2062478)
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">
                                            <i class="fas fa-longitude me-2"></i>
                                            Longitud
                                        </label>
                                        <input type="text" name="lon_calita" 
                                               class="form-control"
                                               value="<?php echo htmlspecialchars($lon_calita); ?>"
                                               required>
                                        <div class="form-text">
                                            Longitud de la ubicación permitida (ej: -98.2332175)
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">
                                            <i class="fas fa-ruler me-2"></i>
                                            Radio permitido (metros)
                                        </label>
                                        <input type="number" name="distancia_maxima" 
                                               class="form-control"
                                               min="100" max="50000" step="100"
                                               value="<?php echo htmlspecialchars($distancia_maxima); ?>"
                                               required>
                                        <div class="form-text">
                                            Radio máximo permitido (20000 = 20km)
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="alert alert-info">
                                <strong><i class="fas fa-info-circle me-2"></i>Ubicación actual:</strong><br>
                                <i class="fas fa-map-pin me-1"></i> Latitud: <?php echo htmlspecialchars($lat_calita); ?><br>
                                <i class="fas fa-map-pin me-1"></i> Longitud: <?php echo htmlspecialchars($lon_calita); ?><br>
                                <i class="fas fa-arrows-alt-h me-1"></i> Radio: <?php echo number_format($distancia_maxima); ?> metros
                                <small class="d-block mt-1">
                                    (<strong>Nota:</strong> Los cambios en la ubicación afectarán inmediatamente a los nuevos usuarios)
                                </small>
                            </div>
                        </div>

                        <!-- Tiempo de espera entre canciones -->
                        <div class="mb-4">
                            <h6 class="border-bottom pb-2 mb-3">
                                <i class="fas fa-clock me-2 text-primary"></i>
                                Configuración de Tiempos
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">
                                            <i class="fas fa-hourglass-half me-2"></i>
                                            Tiempo de espera entre canciones (minutos)
                                        </label>
                                        <input type="number" name="minutos_limite" 
                                               class="form-control form-control-lg"
                                               min="0" max="60" step="1"
                                               value="<?php echo $configuraciones['minutos_limite'] ?? '30'; ?>"
                                               required>
                                        <div class="form-text">
                                            Tiempo que debe esperar un usuario entre solicitudes de canciones.
                                            <strong>0 = Sin límite de tiempo</strong> | 60 = Máximo 1 hora
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Configuraciones del sistema -->
                        <div class="mb-4">
                            <h6 class="border-bottom pb-2 mb-3">
                                <i class="fas fa-toggle-on me-2 text-success"></i>
                                Funcionalidades del Sistema
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-check form-switch mb-3">
                                        <input class="form-check-input" type="checkbox" 
                                               name="canciones_activas" id="canciones_activas"
                                               <?php echo ($configuraciones['canciones_activas'] ?? '1') == '1' ? 'checked' : ''; ?>>
                                        <label class="form-check-label fw-bold" for="canciones_activas">
                                            <i class="fas fa-music me-2 text-primary"></i>
                                            Sistema de canciones activo
                                        </label>
                                        <div class="form-text">
                                            Cuando está desactivado, los usuarios no pueden buscar canciones.
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="form-check form-switch mb-3">
                                        <input class="form-check-input" type="checkbox" 
                                               name="dj_activo" id="dj_activo"
                                               <?php echo ($configuraciones['dj_activo'] ?? '0') == '1' ? 'checked' : ''; ?>>
                                        <label class="form-check-label fw-bold" for="dj_activo">
                                            <i class="fas fa-headphones me-2 text-info"></i>
                                            Modo DJ activo
                                        </label>
                                        <div class="form-text">
                                            Canciones se guardan en cola DJ en lugar del playlist.
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="form-check form-switch mb-3">
                                        <input class="form-check-input" type="checkbox" 
                                               name="spotify_activo" id="spotify_activo"
                                               <?php echo ($configuraciones['spotify_activo'] ?? '1') == '1' ? 'checked' : ''; ?>>
                                        <label class="form-check-label fw-bold" for="spotify_activo">
                                            <i class="fab fa-spotify me-2 text-success"></i>
                                            Spotify activo
                                        </label>
                                        <div class="form-text">
                                            Integración con Spotify para agregar canciones.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Información adicional -->
                        <div class="alert alert-warning">
                            <h6><i class="fas fa-exclamation-triangle me-2"></i>Información importante:</h6>
                            <ul class="mb-0">
                                <li>Los cambios en la geolocalización se aplican inmediatamente</li>
                                <li>Los usuarios que ya están dentro del radio permitido no serán afectados</li>
                                <li>Recomendación: Radio de 20000 metros (20km) para zonas urbanas</li>
                                <li>Para eventos específicos puedes reducir el radio a 100-500 metros</li>
                            </ul>
                        </div>

                        <button type="submit" name="actualizar_config" class="btn btn-primary btn-lg w-100 py-3">
                            <i class="fas fa-save me-2"></i>Guardar Configuración
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Panel lateral con información -->
        <div class="col-lg-4">
            <!-- Configuración actual -->
            <div class="card mb-4">
                <div class="card-header bg-success text-white">
                    <h6 class="mb-0"><i class="fas fa-chart-line me-2"></i>Configuración Actual</h6>
                </div>
                <div class="card-body">
                    <div class="list-group list-group-flush">
                        <div class="list-group-item d-flex justify-content-between align-items-center">
                            <span class="fw-bold">Estado Buscador:</span>
                            <span class="badge <?php echo $buscador_mantenimiento == '1' ? 'bg-danger' : 'bg-success'; ?> rounded-pill">
                                <?php echo $buscador_mantenimiento == '1' ? 'Mantenimiento' : 'Normal'; ?>
                            </span>
                        </div>
                        <div class="list-group-item d-flex justify-content-between align-items-center">
                            <span class="fw-bold">Tiempo de espera:</span>
                            <span class="badge bg-primary rounded-pill">
                                <?php echo $configuraciones['minutos_limite'] ?? '30'; ?> min
                            </span>
                        </div>
                        <div class="list-group-item d-flex justify-content-between align-items-center">
                            <span class="fw-bold">Canciones activas:</span>
                            <span class="badge <?php echo ($configuraciones['canciones_activas'] ?? '1') == '1' ? 'bg-success' : 'bg-danger'; ?> rounded-pill">
                                <?php echo ($configuraciones['canciones_activas'] ?? '1') == '1' ? 'Sí' : 'No'; ?>
                            </span>
                        </div>
                        <div class="list-group-item d-flex justify-content-between align-items-center">
                            <span class="fw-bold">Modo DJ:</span>
                            <span class="badge <?php echo ($configuraciones['dj_activo'] ?? '0') == '1' ? 'bg-success' : 'bg-secondary'; ?> rounded-pill">
                                <?php echo ($configuraciones['dj_activo'] ?? '0') == '1' ? 'Activo' : 'Inactivo'; ?>
                            </span>
                        </div>
                        <div class="list-group-item d-flex justify-content-between align-items-center">
                            <span class="fw-bold">Spotify activo:</span>
                            <span class="badge <?php echo ($configuraciones['spotify_activo'] ?? '1') == '1' ? 'bg-success' : 'bg-danger'; ?> rounded-pill">
                                <?php echo ($configuraciones['spotify_activo'] ?? '1') == '1' ? 'Sí' : 'No'; ?>
                            </span>
                        </div>
                        <div class="list-group-item d-flex justify-content-between align-items-center">
                            <span class="fw-bold">Latitud:</span>
                            <span class="badge bg-secondary rounded-pill">
                                <?php echo htmlspecialchars($lat_calita); ?>
                            </span>
                        </div>
                        <div class="list-group-item d-flex justify-content-between align-items-center">
                            <span class="fw-bold">Longitud:</span>
                            <span class="badge bg-secondary rounded-pill">
                                <?php echo htmlspecialchars($lon_calita); ?>
                            </span>
                        </div>
                        <div class="list-group-item d-flex justify-content-between align-items-center">
                            <span class="fw-bold">Radio permitido:</span>
                            <span class="badge bg-warning text-dark rounded-pill">
                                <?php echo number_format($distancia_maxima); ?> m
                            </span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Mapa de referencia -->
            <div class="card mb-4">
                <div class="card-header bg-info text-white">
                    <h6 class="mb-0"><i class="fas fa-map me-2"></i>Ubicación en Mapa</h6>
                </div>
                <div class="card-body">
                    <div id="mapPreview" style="height: 200px; background-color: #f8f9fa; border-radius: 8px; display: flex; align-items: center; justify-content: center; color: #6c757d;">
                        <div class="text-center">
                            <i class="fas fa-map-marked-alt fa-3x mb-2"></i>
                            <p class="mb-0">Ubicación configurada</p>
                            <small>Lat: <?php echo htmlspecialchars($lat_calita); ?></small><br>
                            <small>Lon: <?php echo htmlspecialchars($lon_calita); ?></small>
                        </div>
                    </div>
                    <div class="mt-2 text-center">
                        <a href="https://www.google.com/maps?q=<?php echo urlencode($lat_calita . ',' . $lon_calita); ?>" 
                           target="_blank" class="btn btn-sm btn-outline-primary">
                            <i class="fas fa-external-link-alt me-1"></i>Ver en Google Maps
                        </a>
                    </div>
                </div>
            </div>

            <!-- Calculadora de distancia -->
            <div class="card mb-4">
                <div class="card-header bg-warning text-dark">
                    <h6 class="mb-0"><i class="fas fa-calculator me-2"></i>Calculadora de Radio</h6>
                </div>
                <div class="card-body">
                    <div class="mb-2">
                        <label class="form-label small">Radio actual:</label>
                        <div class="d-flex justify-content-between">
                            <span><?php echo number_format($distancia_maxima); ?> metros</span>
                            <span><?php echo number_format($distancia_maxima / 1000, 1); ?> km</span>
                        </div>
                        <div class="progress" style="height: 8px;">
                            <div class="progress-bar bg-warning" style="width: <?php echo min(100, ($distancia_maxima / 500) * 100); ?>%"></div>
                        </div>
                    </div>
                    <small class="text-muted">
                        <i class="fas fa-info-circle me-1"></i>
                        Recomendaciones:
                        <ul class="mb-0 mt-1">
                            <li>100-500m: Evento específico</li>
                            <li>1-5km: Restaurante/Bar local</li>
                            <li>10-20km: Ciudad/Área metropolitana</li>
                            <li>50km: Región amplia</li>
                        </ul>
                    </small>
                </div>
            </div>

            <!-- Acciones rápidas -->
            <div class="card">
                <div class="card-header bg-dark text-white">
                    <h6 class="mb-0"><i class="fas fa-bolt me-2"></i>Acciones Rápidas</h6>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        <a href="canciones.php" class="btn btn-outline-primary">
                            <i class="fas fa-music me-2"></i>Gestionar Canciones
                        </a>
                        <a href="dashboard.php" class="btn btn-outline-success">
                            <i class="fas fa-tachometer-alt me-2"></i>Volver al Dashboard
                        </a>
                        <button class="btn btn-outline-info" onclick="probarUbicacion()">
                            <i class="fas fa-location-arrow me-2"></i>Probar Ubicación
                        </button>
                        <button class="btn btn-outline-warning" onclick="mostrarAyuda()">
                            <i class="fas fa-question-circle me-2"></i>Ayuda GPS
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// ============================================
// FUNCIONES PARA MANTENIMIENTO DEL BUSCADOR
// ============================================

// Validación del formulario de mantenimiento
document.getElementById('mantenimientoForm').addEventListener('submit', function(e) {
    const titulo = this.elements['mantenimiento_titulo'].value.trim();
    const mensaje = this.elements['mantenimiento_mensaje'].value.trim();
    const botonTexto = this.elements['mantenimiento_boton_texto'].value.trim();
    const botonUrl = this.elements['mantenimiento_boton_url'].value.trim();
    
    if (!titulo || !mensaje || !botonTexto || !botonUrl) {
        e.preventDefault();
        alert('❌ Por favor completa todos los campos requeridos');
        return false;
    }
    
    if (titulo.length > 100) {
        e.preventDefault();
        alert('❌ El título es demasiado largo (máximo 100 caracteres)');
        return false;
    }
    
    if (mensaje.length > 500) {
        e.preventDefault();
        alert('❌ El mensaje es demasiado largo (máximo 500 caracteres)');
        return false;
    }
    
    const confirmacion = confirm(
        '¿Guardar configuración de mantenimiento?\n\n' +
        'Esta configuración afectará inmediatamente a todos los usuarios.\n' +
        '¿Estás seguro de continuar?'
    );
    
    if (!confirmacion) {
        e.preventDefault();
        return false;
    }
    
    return true;
});

// Vista previa en tiempo real para mantenimiento
const tituloInput = document.querySelector('input[name="mantenimiento_titulo"]');
const mensajeInput = document.querySelector('textarea[name="mantenimiento_mensaje"]');
const botonTextoInput = document.querySelector('input[name="mantenimiento_boton_texto"]');
const botonUrlInput = document.querySelector('input[name="mantenimiento_boton_url"]');

function updatePreview() {
    const previewTitle = document.querySelector('.preview-title');
    const previewMessage = document.querySelector('.preview-message');
    const previewButton = document.querySelector('.preview-button');
    
    if (previewTitle) {
        previewTitle.textContent = tituloInput.value || '🚧 Sistema en Mantenimiento';
    }
    
    if (previewMessage) {
        const mensajeCompleto = mensajeInput.value || '';
        const mensajeCorto = mensajeCompleto.length > 150 ? mensajeCompleto.substring(0, 150) + '...' : mensajeCompleto;
        previewMessage.textContent = mensajeCorto;
    }
    
    if (previewButton) {
        previewButton.textContent = botonTextoInput.value || 'Volver al Inicio';
        previewButton.href = botonUrlInput.value || '../';
    }
}

// Agregar eventos para vista previa en tiempo real
if (tituloInput && mensajeInput && botonTextoInput && botonUrlInput) {
    [tituloInput, mensajeInput, botonTextoInput, botonUrlInput].forEach(input => {
        input.addEventListener('input', updatePreview);
    });
}

// Inicializar vista previa
updatePreview();

// ============================================
// FUNCIONES PARA CONFIGURACIÓN GENERAL
// ============================================

// Función para probar la ubicación
function probarUbicacion() {
    const lat = document.querySelector('input[name="lat_calita"]').value;
    const lon = document.querySelector('input[name="lon_calita"]').value;
    const radio = document.querySelector('input[name="distancia_maxima"]').value;
    
    const url = `https://www.google.com/maps?q=${lat},${lon}&z=15`;
    window.open(url, '_blank');
    
    alert(
        '📍 Ubicación de prueba:\n\n' +
        `Latitud: ${lat}\n` +
        `Longitud: ${lon}\n` +
        `Radio: ${parseInt(radio).toLocaleString()} metros (${(radio/1000).toFixed(1)} km)\n\n` +
        'Se abrirá Google Maps para verificar la ubicación.'
    );
}

// Función para mostrar ayuda GPS
function mostrarAyuda() {
    alert(
        '📡 Ayuda para coordenadas GPS:\n\n' +
        '1. Abre Google Maps\n' +
        '2. Haz clic derecho en la ubicación deseada\n' +
        '3. Selecciona "¿Qué hay aquí?"\n' +
        '4. Copia las coordenadas que aparecen\n' +
        '5. Pega en los campos correspondientes\n\n' +
        'Formato: Decimal (ej: 19.2062478, -98.2332175)'
    );
}

// Validación del formulario general
document.getElementById('configForm').addEventListener('submit', function(e) {
    const lat = document.querySelector('input[name="lat_calita"]').value;
    const lon = document.querySelector('input[name="lon_calita"]').value;
    const radio = document.querySelector('input[name="distancia_maxima"]').value;
    const minutos = document.querySelector('input[name="minutos_limite"]').value;
    
    // Validar latitud (-90 a 90)
    const latNum = parseFloat(lat);
    if (isNaN(latNum) || latNum < -90 || latNum > 90) {
        e.preventDefault();
        alert('❌ La latitud debe ser un número entre -90 y 90');
        return false;
    }
    
    // Validar longitud (-180 a 180)
    const lonNum = parseFloat(lon);
    if (isNaN(lonNum) || lonNum < -180 || lonNum > 180) {
        e.preventDefault();
        alert('❌ La longitud debe ser un número entre -180 y 180');
        return false;
    }
    
    // Validar radio (100m a 50km)
    const radioNum = parseInt(radio);
    if (isNaN(radioNum) || radioNum < 100 || radioNum > 50000) {
        e.preventDefault();
        alert('❌ El radio debe estar entre 100 y 50000 metros');
        return false;
    }
    
    // Validar tiempo de espera
    if (minutos < 0 || minutos > 60) {
        e.preventDefault();
        alert('❌ El tiempo de espera debe estar entre 0 y 60 minutos');
        return false;
    }
    
    // Confirmación final
    const confirmacion = confirm(
        '⚠️ ¿ESTÁS SEGURO DE ACTUALIZAR LA CONFIGURACIÓN?\n\n' +
        'Esto afectará inmediatamente a:\n' +
        '• Nueva verificación de ubicación de usuarios\n' +
        '• Tiempos de espera entre canciones\n' +
        '• Estados del sistema (Canciones, DJ)\n\n' +
        '¿Continuar?'
    );
    
    if (!confirmacion) {
        e.preventDefault();
        return false;
    }
    
    return true;
});

// Previsualización del radio en tiempo real
const distanciaInput = document.querySelector('input[name="distancia_maxima"]');
if (distanciaInput) {
    distanciaInput.addEventListener('input', function(e) {
        const valor = parseInt(e.target.value) || 0;
        const km = (valor / 1000).toFixed(1);
        
        // Actualizar visualización
        const preview = document.querySelector('#mapPreview small:last-child');
        if (preview) {
            preview.textContent = 'Radio: ' + valor.toLocaleString() + 'm (' + km + 'km)';
        }
    });
}
</script>

<?php include 'includes/footer.php'; ?>